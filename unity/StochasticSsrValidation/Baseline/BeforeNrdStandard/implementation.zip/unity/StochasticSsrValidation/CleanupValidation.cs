using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using BepInEx.Configuration;
using FuckTheseFX.Source.StochasticSSR;
using Baseline=FuckTheseFX.Source.StochasticSSR.CleanupBaseline;
using HarmonyLib;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public static partial class StochasticSsrValidation
{
    private static void CleanupSettings()
    {
        string path="cleanup-defaults.cfg";if(File.Exists(path))File.Delete(path);
        var config=new ConfigFile(path,false);var settings=new SsrSettings(config);
        var expected=new Dictionary<string,string> {
            {"Experimental NRD REBLUR specular","True"},{"NRD anti-firefly","False"},
            {"Enabled","False"},{"Use captured CustomAmbient subtraction","True"},{"SSR resolution","R768"},
            {"Normal stabilization","False"},{"Trace normal strength","0.85"},{"Normal stabilization start distance","10"},{"Normal stabilization end distance","100"},{"Normal filter radius","4"},
            {"Maximum iterations","350"},{"Thickness","1"},{"Thickness hit confidence floor","1"},{"Bypass hit normal checks","True"},
            {"Occluder continuation samples","350"},{"Occluder continuation pixels","500"},{"Occluder continuation depth separation","200"},{"Allow continued sky on all receivers","True"},
            {"Fallback strength","0.65"},{"Reconstruction backend","Custom"},{"Minimum receiver smoothness","0.4"},{"Cutoff environment blend","0.25"},{"Water reflection surface colour influence","0.2"},
            {"Limit reflection range","False"},{"Maximum distance","250"},{"Temporal stabilization","True"},{"Rough reflection coverage accumulation","True"},{"History frames","16"},
            {"Rough coverage full-strength smoothness","0.7"},{"Rough coverage fade-out smoothness","0.9"},
            {"Experimental zero-smoothness probe lighting","True"},{"Zero-smoothness probe contribution","0.3"},
            {"Zero-smoothness probe contribution close","0.1"},{"Zero-smoothness probe fade start","5"},{"Zero-smoothness probe fade end","15"},
            {"Capture continuation diagnostics","False"},{"Capture traversal work","False"},{"Debug view","Normal"},{"Freeze ray sequence","False"}
        };
        Check(config.Count==44,"cleanup controls plus distance-faded probe lighting and two NRD controls");
        Check(settings.Read().EdgePixels==0,"screen-edge confidence fade is disabled by default");
        foreach(var pair in expected) {
            var entry=config[new ConfigDefinition("Stochastic SSR",pair.Key)];
            Check(string.Equals(entry.GetSerializedValue(),pair.Value,StringComparison.OrdinalIgnoreCase),"current-configuration default: "+pair.Key);
            entry.BoxedValue=entry.DefaultValue;Check(string.Equals(entry.GetSerializedValue(),pair.Value,StringComparison.OrdinalIgnoreCase),"reset uses approved default: "+pair.Key);
        }
        foreach(float cutoff in new[]{0f,.137f,.5f,.65f,1f}) {
            settings.ReceiverCutoff.Value=cutoff;var o=settings.Read();o.ApplyNativeCutoff(.25f);
            Check(o.Smoothness==cutoff && o.SupportSmoothness==.25f,"continuous receiver cutoff preserves native support: "+cutoff);
        }
        settings.ReceiverCutoff.Value=0;
        foreach(var legacy in new[]{"Native","Cutoff0","Cutoff010","Cutoff025","Cutoff050","Cutoff065","Cutoff075"}) {
            File.WriteAllText(path,"[Stochastic SSR]\nExperimental receiver smoothness cutoff = "+legacy+"\n[Unrelated]\nPreference = untouched\n");
            var migratedConfig=new ConfigFile(path,false);var migrated=new SsrSettings(migratedConfig);new SsrSettings(migratedConfig);migratedConfig.Save();
            float expectedCutoff=legacy=="Native" || legacy=="Cutoff0"?0:float.Parse(legacy.Substring(6),System.Globalization.CultureInfo.InvariantCulture)/100;
            Check(Mathf.Abs(migrated.ReceiverCutoff.Value-expectedCutoff)<1e-6 && !File.ReadAllText(path).Contains("Experimental receiver smoothness cutoff =") && File.ReadAllText(path).Contains("Preference = untouched"),"enum cutoff migration: "+legacy);
        }
        File.WriteAllText(path,"[Stochastic SSR]\nExperimental receiver smoothness cutoff = Cutoff075\nMinimum receiver smoothness = 0.537\nCutoff environment blend = 0.31\n");
        var preferred=new SsrSettings(new ConfigFile(path,false));
        Check(preferred.ReceiverCutoff.Value==.537f && preferred.CutoffEnvironmentBlend.Value==.31f,"new slider preferences take precedence over legacy enum");
        foreach(float savedDistance in new[]{250f,987f,986.8158f}) {
            File.WriteAllText(path,"[Stochastic SSR]\nLimit reflection range = true\nMaximum distance = "+savedDistance.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+"\n");
            var c=new ConfigFile(path,false);var saved=new SsrSettings(c);new SsrSettings(c);
            Check(saved.Distance.Value==savedDistance && saved.Distance.DefaultValue.Equals(250f) && saved.LimitRange.Value,"receiver range preserves explicit numeric preference: "+savedDistance);
        }
        foreach(var resolution in Enum.GetValues(typeof(ReflectionResolution)).Cast<ReflectionResolution>()) {
            var o=settings.Read();o.Resolution=resolution;
            Check(o.TraceDimensions(3839,2159)==new Vector2Int((int)resolution,(int)resolution),"square allocation with rectangular camera: "+resolution);
        }
        foreach(string retiredView in new[]{"ForegroundOcclusion","ReuseProvenance","ReuseRejection","37","38","39","WaterNormalStability"}) {
            File.WriteAllText(path,"[Unrelated]\nPreference = untouched\n[Stochastic SSR]\nDebug view = "+retiredView+"\nWater normal stabilization = true\nWater trace normal strength = 0.65\nNormal stabilization = false\nTrace normal strength = 0.9\nNormal variance filtering = 0.5\nDenoiser backend = Amd\nAMD exact-hit candidate = true\nMissing depth coverage = PushPullFill\nSource colour blend = 0.2\nSampling mode = Native\nAdaptive rays = true\nFallback strength = 0.600939\nWater reflection surface colour influence = 0.1971831\nMaximum iterations = 515\nOccluder continuation samples = 557\n");
            config=new ConfigFile(path,false);settings=new SsrSettings(config);config.Save();string saved=File.ReadAllText(path);
            Check(settings.View.Value==(retiredView=="WaterNormalStability"?ReflectionView.NormalStability:ReflectionView.Normal),"retired debug selection migration: "+retiredView);
            Check(!settings.WaterNormals.Value && settings.WaterTraceStrength.Value==.9f,"new normal keys override legacy preferences");
            Check(settings.FallbackStrength.Value==.600939f && settings.SurfaceColourInfluence.Value==.1971831f,"unrounded saved appearance preferences are preserved");
            Check(settings.Steps.Value==515 && settings.ContinuationSamples.Value==557,"saved traversal budgets stay exact");
            Check(saved.Contains("Preference = untouched") && !saved.Contains("Denoiser backend =") && !saved.Contains("Normal variance filtering =") && !saved.Contains("Sampling mode =") && !saved.Contains("Adaptive rays ="),"retired settings consumed without unrelated preference loss");
            new SsrSettings(config);Check(config.Count==44,"cleanup migration supports repeated binding including disabled NRD controls");
        }
        Check((int)ReflectionView.NormalStability==40 && (int)ReflectionView.DepthHitKind==34 && !Enum.GetNames(typeof(ReflectionView)).Any(n=>n.StartsWith("Reuse") || n=="ForegroundOcclusion"),"surviving debug IDs stable without retired choices");
        File.WriteAllText(path,"[Unrelated]\nPreference = untouched\n[Stochastic SSR]\nExperimental foreground DDA continuation = true\nMaximum iterations = 350\nOccluder continuation samples = 350\nZero-smoothness probe contribution = 0.3016432\nZero-smoothness probe contribution close = 0.1\nZero-smoothness probe fade start = 5\nZero-smoothness probe fade end = 15\n");
        config=new ConfigFile(path,false);settings=new SsrSettings(config);new SsrSettings(config);config.Save();
        Check(!File.ReadAllText(path).Contains("Experimental foreground DDA continuation") && File.ReadAllText(path).Contains("Preference = untouched"),"removed DDA setting is consumed without unrelated preference loss");
        Check(settings.Steps.Value==350 && settings.ContinuationSamples.Value==350 && settings.ZeroSmoothnessProbeStrength.Value==.3016432f && settings.ZeroSmoothnessProbeClose.Value==.1f && settings.ZeroSmoothnessProbeFadeStart.Value==5 && settings.ZeroSmoothnessProbeFadeEnd.Value==15,"DDA removal preserves saved 350 budgets and probe fade preferences");
        var previous=settings.Read();settings.NormalRadius.Value=8;Check(!previous.SameRendering(settings.Read()),"retained normal control invalidates history");
        previous=settings.Read();settings.CaptureContinuation.Value=!previous.CaptureContinuation;Check(previous.SameRendering(settings.Read()),"capture request preserves rendering history");
        previous=settings.Read();settings.CaptureTraversal.Value=!previous.CaptureTraversal;Check(previous.SameRendering(settings.Read()),"traversal diagnostic request preserves rendering history");
        previous=settings.Read();settings.GlobalContinuedSky.Value=!previous.GlobalContinuedSky;Check(!previous.SameRendering(settings.Read()),"global continued-sky toggle invalidates history and reaches runtime options");
    }

    private static Baseline.Options BeforeOptions(Options o)=>new Baseline.Options {
        Mode=Baseline.SsrMode.Stochastic,Direction=Baseline.ReflectionDirection.Ggx,Denoiser=Baseline.ReflectionDenoiser.Custom,
        DepthGapFill=Baseline.ReflectionDepthGapFill.SourceColorBlend,DepthGapSourceBlend=1,RelaxOccluderReturn=true,SkyAfterContinuation=true,
        Reconstruction=(Baseline.ReflectionReconstruction)(int)o.Reconstruction,Resolution=(Baseline.ReflectionResolution)(int)o.Resolution,View=(Baseline.ReflectionView)(int)o.View,
        Steps=o.Steps,Distance=o.Distance,Thickness=o.Thickness,Smoothness=o.Smoothness,HistoryFrames=o.HistoryFrames,EdgePixels=o.EdgePixels,
        FallbackStrength=o.FallbackStrength,SurfaceColourInfluence=o.SurfaceColourInfluence,Temporal=o.Temporal,LimitNativeRange=o.LimitNativeRange,
        Freeze=o.Freeze,UseCapturedContribution=o.UseCapturedContribution,BypassHitNormal=o.BypassHitNormal,WaterNormals=o.WaterNormals,WaterTraceStrength=o.WaterTraceStrength,
        NormalStartDistance=o.NormalStartDistance,NormalEndDistance=o.NormalEndDistance,NormalRadius=o.NormalRadius,ThicknessConfidenceFloor=o.ThicknessConfidenceFloor,
        ContinuationSamples=o.ContinuationSamples,ContinuationPixels=o.ContinuationPixels,ContinuationDepth=o.ContinuationDepth
    };

    private static void CleanupParity()
    {
        var oldDepth=depths;var oldNormal=normals;var oldSpec=specular;var oldScene=scene;
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeCleanup/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeCleanup/Reflection.shader");
        Check(oldCompute!=null && oldReflection!=null,"pre-cleanup Custom baseline is available only to validation");
        File.WriteAllText("cleanup-parity.csv","shape,reconstruction,temporal,normals,frame,raw,records,guides,resolve,history,fill,composition\n");
        var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
        float Raw(float z){var v=projection*new Vector4(0,0,-z,1);return v.z/v.w;}
        try {
            foreach(var shape in new[]{new Vector2Int(128,128),new Vector2Int(96,64)})
            foreach(var reconstruction in Enum.GetValues(typeof(ReflectionReconstruction)).Cast<ReflectionReconstruction>())
            foreach(bool temporal in new[]{false,true})foreach(bool stabilize in new[]{false,true}) {
                using(var cb=new CommandBuffer())using(var before=new Baseline.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
                using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    before.Ensure(width,height,shape.x,shape.y,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,shape.x,shape.y,RenderTextureFormat.ARGBHalf);
                    var o=Options();o.Temporal=temporal;o.WaterNormals=stabilize;o.WaterTraceStrength=.85f;o.NormalRadius=4;
                    o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;o.ThicknessConfidenceFloor=1;
                    o.BypassHitNormal=true;o.FallbackStrength=.600939f;o.SurfaceColourInfluence=.1971831f;o.Freeze=false;o.Reconstruction=reconstruction;
                    for(int frame=0;frame<6;frame++) {
                        // Flat/tilted ground, foreground silhouette, sparse sky and
                        // high-frequency animated detail share the same source signal.
                        depths=Texture(Enumerable.Range(0,width*height).Select(j=>new Color(j%width>width*.8?0:Raw(j%width>width*.45 && j%width<width*.6?2:15+(j/width)*.8f),0,0,0)).ToArray());
                        normals=Texture(Enumerable.Range(0,width*height).Select(j=>{var n=new Vector3(.08f*Mathf.Sin(j%width*2+frame*.6f),.35f+.08f*Mathf.Cos(j/width*2-frame),-.85f).normalized;return new Color(n.x*.5f+.5f,n.y*.5f+.5f,n.z*.5f+.5f,1);}).ToArray());
                        specular=Texture(Enumerable.Range(0,width*height).Select(j=>new Color(.04f,.06f,.08f,j%width<width/2?1:.98f)).ToArray());
                        scene=Texture(Enumerable.Range(0,width*height).Select(j=>new Color(.1f+(j%width)/200f,.2f+(j/width)/200f,.4f,1)).ToArray());
                        Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,BeforeOptions(o),depths,normals,specular);Execute(cb);var beforeColor=Read(camera.targetTexture);
                        Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var afterColor=Read(camera.targetTexture);
                        double[] errors={Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance)),Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record)),Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit)),Error(Read(before.Resolved),Read(after.Resolved)),temporal?Error(Read(before.History),Read(after.History)):0,Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled)),Error(beforeColor,afterColor)};
                        Check(errors.Take(6).All(e=>e==0) && EquivalentComposition(beforeColor,afterColor),"pre-cleanup parity "+shape+" "+reconstruction+" temporal="+temporal+" normals="+stabilize+" frame="+frame+" errors="+string.Join(",",errors));
                        Check(Error(Read(before.TracePipeline.Sample),Read(after.TracePipeline.Sample))==0 && Error(Read(before.TracePipeline.DepthHit),Read(after.TracePipeline.DepthHit))==0,"diagnostic variant retains exact ray/PDF and hit factors");
                        File.AppendAllText("cleanup-parity.csv",shape+","+reconstruction+","+temporal+","+stabilize+","+frame+","+string.Join(",",errors)+"\n");
                    }
                }
            }
        } finally {depths=oldDepth;normals=oldNormal;specular=oldSpec;scene=oldScene;}
    }

    private static void CleanupDepthFill()
    {
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            const int size=32;p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);var o=Options();o.ContinuationDepth=50;o.Temporal=true;
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            var records=Enumerable.Repeat(new Color(0,0,11,0),size*size).ToArray();var costs=Enumerable.Repeat(new Color(3,10,51,9),size*size).ToArray();
            var stop=Enumerable.Repeat(new Color(.25f,.25f,60,5),size*size).ToArray();var guide=Enumerable.Repeat(new Color(0,5,0,0),size*size).ToArray();
            records[0]=new Color(0,0,6,0);records[1]=new Color(0,0,4,-1);records[2]=new Color(0,0,8,0);costs[3]=new Color(3,1000,49,9);costs[4]=new Color(3,10,50,9);stop[5]=new Color(-1,.25f,60,5);
            cb.Blit(Sized(records,size,size),p.TracePipeline.Record);cb.Blit(Sized(costs,size,size),p.TracePipeline.TraceInfo);cb.Blit(Sized(stop,size,size),p.TracePipeline.TraceStop);cb.Blit(Sized(guide,size,size),p.TracePipeline.Hit);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var fill=Read(p.DepthGapFilled);int source=(height/4)*width+width/4;var expected=scene.GetPixels()[source];
            Check(fill.All(v=>v==Color.clear),"failed rays retain zero measured coverage instead of copying the rejected object");
            Check(fill.Take(6).All(v=>v==Color.clear),"source fill protects offscreen/self/budget, sample-only, equal-depth and invalid UV failures");
            Check(Read(p.History).All(v=>v==Color.clear),"source-colour fill stays out of measured temporal history");
        }
    }

    private static void CleanupCoverageParity()
    {
        var oldDepth=depths;var oldNormal=normals;var oldSpec=specular;
        var baselineCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeCleanup/HiZ.compute");
        var baselineShader=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeCleanup/Reflection.shader");
        int hits=0,continued=0,misses=0;
        var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
        using(var capture=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
        try {
            foreach(bool water in new[]{false,true})foreach(int scenario in new[]{0,1,2,3}) {
                var d=oldDepth.GetPixels();var n=oldNormal.GetPixels();var sp=oldSpec.GetPixels();var mask=new Color[d.Length];
                for(int j=0;j<d.Length;j++) {
                    bool floor=sp[j].a>.5f;int x=j%width,y=j/width;
                    var ray=camera.worldToCameraMatrix.MultiplyVector(camera.ScreenPointToRay(new Vector3(x+.5f,y+.5f,0)).direction).normalized;
                    float floorDistance=ray.y<0?-1/ray.y:0;float z=-ray.z*floorDistance;
                    if(floor && water)mask[j]=new Color(z,1,0,0);
                    if(scenario>=1 && x>width*.45f && x<width*.65f && y>height*.15f && y<height*.75f) {
                        var clip=projection*new Vector4(0,0,-2,1);d[j]=new Color(clip.z/clip.w,0,0,0);mask[j]=Color.clear;
                        n[j]=new Color(.5f,.5f,1,1);sp[j]=new Color(.04f,.04f,.04f,1);
                    }
                    if(scenario>=2 && !floor && x<width*.45f) {d[j]=Color.clear;mask[j]=Color.clear;}
                    if(scenario==3 && !floor)n[j]=new Color(.5f,1,.5f,1); // force a rejected reflected wall facing
                }
                depths=Texture(d);normals=Texture(n);specular=Texture(sp);
                using(var cb=new CommandBuffer())using(var before=new Baseline.ConfidenceSsrPipeline(baselineCompute,blend,baselineShader,noise,native,gaussian))
                using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    before.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
                    var o=Options();o.Steps=scenario==3?32:515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
                    o.Thickness=scenario==3?.01f:1;o.ThicknessConfidenceFloor=1;o.BypassHitNormal=scenario!=3;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.Temporal=true;
                    for(int frame=0;frame<3;frame++) {
                        cb.Blit(Texture(mask),WaterReflectionCapture.Get(camera,width,height));Globals(cb);TodGlobals(cb,.2f);
                        before.Render(cb,camera,scene,camera.targetTexture,BeforeOptions(o),depths,normals,specular);Execute(cb);var image=Read(camera.targetTexture);
                        Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                        Check(Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 &&
                            Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 && Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 &&
                            Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo))==0 && Error(Read(before.TracePipeline.TraceStop),Read(after.TracePipeline.TraceStop))==0 &&
                            Error(Read(before.Resolved),Read(after.Resolved))==0 && Error(Read(before.History),Read(after.History))==0 &&
                            Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled))==0 && EquivalentComposition(image,Read(camera.targetTexture)),
                            "water/ground/occluder/sky baseline parity water="+water+" scenario="+scenario+" frame="+frame);
                        var records=Read(after.TracePipeline.Record);hits+=records.Count(v=>v.a==1);misses+=records.Count(v=>v.a<=0);
                        continued+=Read(after.TracePipeline.TraceInfo).Count(v=>v.r>0);
                    }
                }
            }
            Check(hits>100 && misses>100 && continued>100,"coverage parity exercises measured geometry, protected misses and continued rays: hits="+hits+" misses="+misses+" continued="+continued);
        } finally {depths=oldDepth;normals=oldNormal;specular=oldSpec;}
    }

    private static void CleanupDiagnostics()
    {
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            p.Ensure(width,height,64,RenderTextureFormat.ARGBHalf);var o=Options();
            Action<bool> render=diag=>{Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,diag);Execute(cb);};
            render(false);var raw=Read(p.TracePipeline.Radiance);var image=Read(camera.targetTexture);
            Check(p.TracePipeline.Sample==null && p.TracePipeline.DepthHit==null,"ordinary rendering allocates no optional diagnostic outputs");
            render(true);Check(p.TracePipeline.Sample!=null && p.TracePipeline.DepthHit!=null,"GPU fixtures can opt into diagnostic outputs");
            Check(Error(raw,Read(p.TracePipeline.Radiance))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"diagnostic keyword does not change radiance/composition");
            render(false);Check(p.TracePipeline.Sample==null && p.TracePipeline.DepthHit==null,"diagnostics released when inactive");
            o.View=ReflectionView.DepthHitConfidence;render(false);Check(p.TracePipeline.DepthHit!=null,"depth-hit debug view requests diagnostics");
            o.View=ReflectionView.Normal;
            // Simulate a pending reader: preserve outputs without executing their
            // writes. They release on the first frame after the reader completes.
            p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,false,true);Execute(cb);
            Check(p.TracePipeline.Sample!=null && p.TracePipeline.DepthHit!=null,"pending reader retains diagnostic resource ownership");
            render(false);Check(p.TracePipeline.DepthHit==null,"completed reader permits diagnostic release");
            p.Ensure(width,height,96,RenderTextureFormat.ARGBHalf);render(false);Check(p.TracePipeline.Sample==null,"resize does not eagerly recreate diagnostic outputs");
            var capture=(ContinuationCapture)AccessTools.Field(typeof(ConfidenceSsrPipeline),"continuationCapture").GetValue(p);
            o.Temporal=true;o.CaptureContinuation=true;render(false);var detached=p.TracePipeline.Sample;
            Check(detached!=null,"one-shot capture automatically requests ray/hit diagnostics");
            p.Ensure(width,height,64,RenderTextureFormat.ARGBHalf);
            Check(!capture.Pending || detached.IsCreated(),"pending capture keeps resized targets alive");
            AsyncGPUReadback.WaitAllRequests();
            Check(!capture.Pending && detached==null,"readback completion releases retired resize targets");
            var folders=Directory.GetDirectories(Path.Combine(BepInEx.Paths.BepInExRootPath,"FTFX-SSR-Captures"));var folder=folders.OrderBy(x=>x).Last();
            string metadata=File.ReadAllText(Path.Combine(folder,"settings.txt"));
            Check(metadata.Contains("Schema=6") && metadata.Contains("RangeSemantics=CameraToReceiverRadial") && metadata.Contains("SourceBlend=0") && metadata.Contains("DepthGapFill=ReceiverColourFallback") && metadata.Contains("SkyRecoveryScope=Water") && metadata.Contains("RelaxReturn=True") &&
                File.Exists(Path.Combine(folder,"temporal-summary.csv"))==o.Temporal && !File.Exists(Path.Combine(folder,"reuse-summary.csv")),"schema-6 capture records baked behavior without retired outputs");
            // A mode change rearms the one-shot while the original capture
            // checkbox remains enabled; work diagnostics use full float masks.
            o.CaptureTraversal=true;render(false);detached=p.TracePipeline.DepthHit;
            Check(detached!=null && detached.format==RenderTextureFormat.ARGBFloat,"work capture requests exact traversal mask format");
            o.CaptureTraversal=false;o.View=ReflectionView.DepthHitConfidence;render(false);
            Check(!capture.Pending || detached.IsCreated(),"pending traversal readback retains replaced format target");
            AsyncGPUReadback.WaitAllRequests();
            Check(p.TracePipeline.DepthHit.format==RenderTextureFormat.ARGBHalf,"depth-hit view restores its diagnostic format after work capture");
            folders=Directory.GetDirectories(Path.Combine(BepInEx.Paths.BepInExRootPath,"FTFX-SSR-Captures"));
            Check(folders.Any(f=>File.Exists(Path.Combine(f,"traversal-rays.csv")) && File.Exists(Path.Combine(f,"traversal-summary.csv"))),"one-shot work capture saves complete ray and termination summaries");
            o.View=ReflectionView.Normal;
            o.CaptureContinuation=false;render(false);o.CaptureContinuation=true;render(false);detached=p.TracePipeline.Sample;
            p.Dispose();Check(!capture.Pending || detached.IsCreated(),"pending capture keeps disposed targets alive");
            AsyncGPUReadback.WaitAllRequests();Check(!capture.Pending && detached==null,"disposed capture callbacks finish and release targets without saving");
        }
    }

    private static void CleanupCompletedSky()
    {
        var originalDepth=depths;var originalSpec=specular;var originalNormal=normals;
        var d=depths.GetPixels();var sp=specular.GetPixels();
        for(int j=0;j<d.Length;j++)if(sp[j].a<.5f)d[j]=new Color(SystemInfo.usesReversedZBuffer?0:1,0,0,0);
        depths=Texture(d);
        using(var capture=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
        using(var cb=new CommandBuffer())using(var before=new Baseline.SsrPipeline(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeCleanup/HiZ.compute"),blend,noise))
        using(var after=new SsrPipeline(compute,blend,noise))
        try {
            const int size=128;before.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
            var o=Options();o.Steps=515;o.BypassHitNormal=true;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
            Globals(cb);before.Trace(cb,camera,scene,BeforeOptions(o),depths,normals,specular);Execute(cb);
            Globals(cb);after.Trace(cb,camera,scene,o,depths,normals,specular,true);Execute(cb);
            // Exercise the actual producer/finalizer handoff, not only seeded
            // reason-10 inputs: a narrow foreground band hides the ray path.
            var cleanDepth=depths;var gpu=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
            var oneMetre=gpu*new Vector4(0,0,-1,1);var blocked=depths.GetPixels();
            for(int y=height/2+4;y<height/2+10;y++)for(int x=0;x<width;x++)blocked[y*width+x]=new Color(oneMetre.z/oneMetre.w,0,0,0);
            var visibleWater=Read(after.Depth[0]).Select((v,j)=>sp[j].a>=.5f?new Color(v.r,1,0,0):Color.clear).ToArray();
            cb.Blit(Texture(visibleWater),WaterReflectionCapture.Get(camera,width,height));Execute(cb);depths=Texture(blocked);
            var ranged=o;ranged.LimitNativeRange=true;ranged.Distance=250;ranged.Steps=1024;ranged.ContinuationDepth=1000;
            Globals(cb);after.Trace(cb,camera,scene,ranged,depths,normals,specular,true);Execute(cb);
            var recovered=Read(after.Record);var recoveryCost=Read(after.TraceInfo);
            Check(recovered.Where((v,j)=>v.a==2 && ((int)recoveryCost[j].a&64)!=0).Any(),"actual continued foreground traversal recovers TOD sky with receiver range enabled");
            Check(!recovered.Any(v=>v.a<=0 && v.b==7),"continued foreground traversal emits no obsolete hit-range reason");
            depths=cleanDepth;Globals(cb);after.Trace(cb,camera,scene,o,depths,normals,specular,true);Execute(cb);
            var records=Read(after.Record);var guide=Read(after.Hit);var points=Read(after.HitPoint);
            var indices=Enumerable.Range(0,records.Length).Where(j=>records[j].a==2 && guide[j].r>0).Take(12).ToArray();
            Check(indices.Length==12,"completed-sky protection fixture has nonzero visible far-plane ray candidates");
            records=Enumerable.Repeat(Color.clear,records.Length).ToArray();var costs=new Color[records.Length];var water=new Color[width*height];
            for(int j=0;j<indices.Length;j++) {
                int index=indices[j],x=index%size,y=index/size;
                int px=(int)((x+.5f)*width/size),py=(int)((y+.5f)*height/size);
                water[py*width+px]=new Color(guide[index].g,1,0,0);
                records[index]=new Color(0,0,10,0);costs[index]=new Color(1,1,1,1);
                if(j>=2 && j<=6)records[index]=new Color(0,0,new[]{6,4,8,9,11}[j-2],0);
                if(j==7)water[py*width+px]=Color.clear;
                if(j==8)costs[index]=new Color(558,1,1,1);
                if(j==9)costs[index]=new Color(1,501,1,1);
                if(j==10)costs[index]=new Color(1,1,51,1);
                if(j==11)costs[index]=new Color(1,1,1,9);
                guide[index].r=0;
            }
            cb.Blit(Texture(water),WaterReflectionCapture.Get(camera,width,height));
            void Seed(RenderTexture record,RenderTexture hit,RenderTexture point,RenderTexture info,RenderTexture radiance) {
                cb.Blit(Sized(records,size,size),record);cb.Blit(Sized(guide,size,size),hit);cb.Blit(Sized(points,size,size),point);
                cb.Blit(Sized(costs,size,size),info);cb.Blit(Texture2D.blackTexture,radiance);
            }
            Seed(before.Record,before.Hit,before.HitPoint,before.TraceInfo,before.Radiance);Seed(after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance);
            void Finalize(object pipeline,Type type,RenderTexture record,RenderTexture hit,RenderTexture point,RenderTexture info,RenderTexture radiance,RenderTexture depth) {
                var shader=(ComputeShader)AccessTools.Field(type,"compute").GetValue(pipeline);int k=shader.FindKernel("FinalizeContinuedSky");
                cb.SetComputeTextureParam(shader,k,"_WaterSurface",WaterReflectionCapture.Get(camera,width,height));cb.SetComputeTextureParam(shader,k,"_WaterNormal",Texture2D.blackTexture);
                cb.SetComputeTextureParam(shader,k,"_Normals",normals);cb.SetComputeTextureParam(shader,k,"_HiZ0",depth);
                cb.SetComputeTextureParam(shader,k,"_RecordOutput",record);cb.SetComputeTextureParam(shader,k,"_HitOutput",hit);cb.SetComputeTextureParam(shader,k,"_PointOutput",point);
                cb.SetComputeTextureParam(shader,k,"_TraceInfo",info);cb.SetComputeTextureParam(shader,k,"_RadianceOutput",radiance);cb.DispatchCompute(shader,k,size/8,size/8,1);
            }
            cb.SetComputeVectorParam((ComputeShader)AccessTools.Field(typeof(SsrPipeline),"compute").GetValue(after),"_Clip",new Vector4(camera.nearClipPlane,camera.farClipPlane,after.Depth.Count-1,1));
            cb.SetComputeVectorParam((ComputeShader)AccessTools.Field(typeof(SsrPipeline),"compute").GetValue(after),"_Trace",new Vector4(250,o.Thickness,o.Smoothness,o.Steps));
            Finalize(before,typeof(Baseline.SsrPipeline),before.Record,before.Hit,before.HitPoint,before.TraceInfo,before.Radiance,before.Depth[0]);
            Finalize(after,typeof(SsrPipeline),after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance,after.Depth[0]);Execute(cb);
            var result=Read(after.Record);
            Check(Error(Read(before.Record),result)==0 && Error(Read(before.Radiance),Read(after.Radiance))==0 && Error(Read(before.Hit),Read(after.Hit))==0,"baked completed-continuation sky matches the frozen kernel exactly");
            Check(indices.Take(2).All(j=>result[j].a==2 && ((int)Read(after.TraceInfo)[j].a&64)!=0),"completed bounded visible-water continuation recovers confirmed sky");
            Check(indices.Skip(2).All(j=>result[j]==records[j]),"sky recovery protects exits/self/budget/unresolved-depth/dry and every continuation allowance");
            foreach(float smoothness in new[]{.8f,.9f,1f}) {
                points[indices[7]].a=smoothness;
                Seed(after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance);
                cb.SetComputeIntParam((ComputeShader)AccessTools.Field(typeof(SsrPipeline),"compute").GetValue(after),"_GlobalContinuedSky",1);
                Finalize(after,typeof(SsrPipeline),after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance,after.Depth[0]);Execute(cb);
                result=Read(after.Record);
                Check(result[indices[7]].a==2,"global recovery accepts untagged receiver at smoothness "+smoothness);
                Check(indices.Skip(2).Where(j=>j!=indices[7]).All(j=>result[j]==records[j]),"global recovery preserves all protected miss and budget conditions");
            }
            Seed(after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance);cb.SetComputeIntParam((ComputeShader)AccessTools.Field(typeof(SsrPipeline),"compute").GetValue(after),"_GlobalContinuedSky",0);
            Finalize(after,typeof(SsrPipeline),after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance,after.Depth[0]);Execute(cb);
            Check(Read(after.Record)[indices[7]].a==0,"global recovery toggles back to water-only live");
            var fadedRecords=Read(after.Record);
            Seed(after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance);
            cb.SetComputeFloatParam((ComputeShader)AccessTools.Field(typeof(SsrPipeline),"compute").GetValue(after),"_EdgePixels",0);
            Finalize(after,typeof(SsrPipeline),after.Record,after.Hit,after.HitPoint,after.TraceInfo,after.Radiance,after.Depth[0]);Execute(cb);
            Check(Error(fadedRecords,Read(after.Record))==0,"zero edge fade preserves continued-sky classification and protected misses");
            Check(indices.Take(2).All(j=>Read(after.Hit)[j].r==1),"zero edge fade keeps full continued-sky confidence");
        } finally {depths=originalDepth;specular=originalSpec;normals=originalNormal;}
    }
}

