using System;
using System.Linq;
using HarmonyLib;
using FuckTheseFX.Source.StochasticSSR;
using UnityEngine;
using UnityEngine.Rendering;

public static partial class StochasticSsrValidation
{
    private static void CoverageDisplayContracts()
    {
        var savedDepth=depths;var savedNormal=normals;var savedSpec=specular;
        try {
            var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
            var clip=projection*new Vector4(0,0,-5,1);
            depths=Texture(Enumerable.Repeat(new Color(clip.z/clip.w,0,0,0),width*height).ToArray());
            normals=Texture(Enumerable.Repeat(new Color(.5f,.5f,1,1),width*height).ToArray());
            specular=Texture(Enumerable.Repeat(new Color(.24f,.24f,.24f,.6f),width*height).ToArray());
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                const int size=128,mid=64;p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
                var o=Options();Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                cb.Blit(Solid(new Color(1,5,0,0)),p.TracePipeline.Hit);
                cb.Blit(Solid(new Color(0,0,-5,.6f)),p.TracePipeline.HitPoint);
                cb.Blit(Solid(new Color(0,0,8,0)),p.TracePipeline.Record);Execute(cb);
                var properties=(MaterialPropertyBlock)AccessTools.Field(typeof(ConfidenceSsrPipeline),"properties").GetValue(p);
                var draw=AccessTools.Method(typeof(ConfidenceSsrPipeline),"Draw");
                var signal=new Color[size*size];int center=mid*size+mid;signal[center]=new Color(.8f,.4f,.2f,1);
                properties.SetTexture("_Signal",Sized(signal,size,size));
                properties.SetVector("_CoverageFilter",new Vector4(1,.7f,.95f,.25f));properties.SetFloat("_CoverageFilterHistory",0);
                Func<Color[]> filter=()=>{draw.Invoke(p,new object[]{cb,(RenderTargetIdentifier)scene,(RenderTargetIdentifier)p.DepthGapFilled,ConfidenceSsrPipeline.Pass.CoverageDisplay});Execute(cb);return Read(p.DepthGapFilled);};
                var measured=Read(p.Resolved);var result=filter();
                Check(Math.Abs(result[center].a-.25f)<.001 && Math.Abs(result[center+1].a-.125f)<.001,"3x3 filter averages an isolated hit with compatible zero observations");
                Check(Math.Abs(result.Sum(v=>v.a)-1)<.001 && Math.Abs(result.Sum(v=>v.r)-.8f)<.002,"bounded display filtering preserves sparse premultiplied energy on a uniform receiver");
                Check(Error(measured,Read(p.Resolved))==0 && Read(p.TracePipeline.Record).All(v=>v.b==8 && v.a==0),"display donors never become raw trace hits");
                properties.SetFloat("_CoverageFilterHistory",1);
                properties.SetTexture("_TemporalStats",Sized(signal.Select(v=>{float l=v.r*.2126f+v.g*.7152f+v.b*.0722f;return new Color(8,l,l*l,0);}).ToArray(),size,size));
                Check(Error(filter(),signal)<.001,"stable temporal specks and sharp colour detail are preserved without variance");
                properties.SetFloat("_CoverageFilterHistory",0);
                properties.SetVector("_CoverageFilter",new Vector4(1,.5f,.5f,.25f));
                Check(Math.Abs(filter()[center].a-.8125f)<.001,"configurable smooth-surface strength and equal fade thresholds produce a finite hard transition");
                properties.SetVector("_CoverageFilter",new Vector4(1,.5f,.7f,0));
                Check(Math.Abs(filter()[center].a-.625f)<.003,"configurable smoothness fade scales the display filter");
                properties.SetVector("_CoverageFilter",new Vector4(1,.7f,.95f,0));
                cb.Blit(Solid(new Color(0,0,-5,1)),p.TracePipeline.HitPoint);Execute(cb);
                Check(Error(filter(),signal)<.001,"zero smooth-surface strength protects mirror receivers above the fade");
                cb.Blit(Solid(new Color(0,0,-5,.6f)),p.TracePipeline.HitPoint);Execute(cb);
                signal=new Color[size*size];signal[center-1]=new Color(1,0,0,1);properties.SetTexture("_Signal",Sized(signal,size,size));
                properties.SetTexture("_WaterCoverage",Texture(Enumerable.Range(0,width*height).Select(j=>j%width<width/2?new Color(5,1,0,0):Color.clear).ToArray()));properties.SetFloat("_WaterAvailable",1);
                Check(filter()[center].a==0,"coverage display filter rejects water-to-land donors even on an identical plane");
                properties.SetFloat("_WaterAvailable",0);
                cb.Blit(Sized(Enumerable.Range(0,size*size).Select(j=>new Color(1,5,j%size<mid?0:1,0)).ToArray(),size,size),p.TracePipeline.Hit);Execute(cb);
                Check(filter()[center].a==0,"coverage display filter rejects opposing receiver shading normals");
                cb.Blit(Sized(Enumerable.Range(0,size*size).Select(j=>new Color(1,j%size<mid?5:10,0,0)).ToArray(),size,size),p.TracePipeline.Hit);Execute(cb);
                Check(filter()[center-1].a>=.25f && filter()[center].a==0,"coverage display filter rejects depth-plane discontinuities");
                cb.Blit(Solid(new Color(1,5,0,0)),p.TracePipeline.Hit);
                cb.Blit(Sized(Enumerable.Range(0,size*size).Select(j=>new Color(0,0,8,j%2+1)).ToArray(),size,size),p.TracePipeline.Record);Execute(cb);
                Check(filter()[center].a>0,"geometry and sky are observations of the same receiver, not spatial boundary labels");
                properties.SetVector("_CoverageFilter",new Vector4(0,.7f,.95f,.25f));
                Check(Error(filter(),signal)<.001,"zero display-filter strength is exact signal bypass");
                var changed=o;changed.CoverageFilter=true;Check(!o.SameRendering(changed),"display filter toggle participates in rendering-state invalidation");
                changed=o;changed.CoverageFilterSmoothStrength=.4f;Check(!o.SameRendering(changed),"smooth display-filter strength participates in rendering-state invalidation");
                cb.Blit(Sized(signal,size,size),p.TracePipeline.Radiance);
                cb.Blit(Solid(new Color(0,0,0,1)),p.TracePipeline.Record);
                o.Temporal=true;o.CoverageTemporal=true;o.CoverageFullSmoothness=.7f;o.CoverageEndSmoothness=.9f;
                o.CoverageFilter=true;o.CoverageFilterStrength=1;o.CoverageFilterFullSmoothness=.7f;o.CoverageFilterEndSmoothness=.95f;o.CoverageFilterSmoothStrength=.25f;
                p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                Check(Error(Read(p.History),Read(p.Temporal))==0 && Error(Read(p.DepthGapFilled),Read(p.Temporal))>.001,"production display filter stays out of stored temporal history");
                o.CoverageFilter=false;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                Check(Error(Read(p.DepthGapFilled),Read(p.Temporal))==0,"production A/B off uses the unfiltered temporal estimate");
            }
        } finally {depths=savedDepth;normals=savedNormal;specular=savedSpec;}
    }
    private static void CoverageTemporalContracts()
    {
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            const int size=128;p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
            var roughSpec=Texture(Enumerable.Repeat(new Color(.24f,.24f,.24f,.6f),width*height).ToArray());
            var o=Options();o.Temporal=true;o.CoverageTemporal=true;o.HistoryFrames=8;o.CoverageFullSmoothness=.7f;o.CoverageEndSmoothness=.9f;
            Globals(cb);cb.SetGlobalTexture("_CameraGBufferTexture1",roughSpec);
            p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,roughSpec,true);Execute(cb);
            Globals(cb);cb.SetGlobalTexture("_CameraGBufferTexture1",roughSpec);
            p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,roughSpec,true);Execute(cb);
            var guide=Read(p.HistoryGuide);var points=Read(p.HistoryPoint);var records=Read(p.TracePipeline.Record);
            var raw=Read(p.TracePipeline.Radiance);var current=Read(p.Resolved);
            var geometry=Enumerable.Range(0,current.Length).Where(j=>current[j].a>.1f && records[j].a==1).ToArray();
            Check(geometry.Length>50,"rough coverage fixture contains accepted geometry");
            var alignedMotion=Texture(Enumerable.Range(0,width*height).Select(j=>{
                int x=j%width,y=j/width;float u=(x+.5f)/width,v=(y+.5f)/height;
                return new Color(u-((int)(u*size)+.5f)/size,v-((int)(v*size)+.5f)/size,0,0);
            }).ToArray());
            Action globals=()=>{Globals(cb);cb.SetGlobalTexture("_CameraGBufferTexture1",roughSpec);cb.SetGlobalTexture("_CameraMotionVectorsTexture",alignedMotion);};
            Action zeroHistory=()=>{cb.Blit(Solid(Color.clear),p.History);cb.Blit(Solid(Color.clear),p.HistoryAnchor);cb.Blit(Solid(new Color(7,0,0,0)),p.HistoryStats);};
            o.CoverageFullSmoothness=.2f;o.CoverageEndSmoothness=.4f;zeroHistory();
            globals();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Error(Read(p.Temporal),Read(p.Resolved))<.00001,"configured fade-out preserves the original temporal path above its threshold");
            o.CoverageFullSmoothness=.5f;o.CoverageEndSmoothness=.7f;zeroHistory();
            globals();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            var faded=Read(p.Temporal);float actualSmoothness=points[geometry[0]].a;
            float t=Mathf.Clamp01((actualSmoothness-.5f)/.2f),strength=1-t*t*(3-2*t);
            Check(geometry.All(j=>Math.Abs(faded[j].a-current[j].a*(1-7f/8*strength))<.001f),"configured smoothness interval controls partial coverage accumulation strength");
            o.CoverageFullSmoothness=.7f;o.CoverageEndSmoothness=.7f;
            // Seven preceding misses are real zero observations, not absent history.
            zeroHistory();
            globals();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            var average=Read(p.Temporal);var stats=Read(p.TemporalStats);var anchors=Read(p.HistoryAnchor);
            Check(geometry.All(j=>Math.Abs(average[j].a-current[j].a/8)<.001f),"seven zero observations attenuate a first rough hit to one-eighth coverage");
            Check(geometry.All(j=>Math.Abs(average[j].r-current[j].r/8)<.002f),"coverage averaging attenuates premultiplied radiance by the same weight");
            Check(geometry.All(j=>Math.Abs(stats[j].r-8)<.001f),"zero observations count toward bounded statistical history");
            Check(geometry.All(j=>float.IsFinite(average[j].a)),"equal fade thresholds produce a finite hard cutoff");
            Check(Error(records,Read(p.TracePipeline.Record))==0,"statistical coverage does not alter raw source authority");
            var missRecords=records.Select(v=>new Color(0,0,8,0)).ToArray();
            Action miss=()=>{globals();cb.Blit(Texture2D.blackTexture,p.TracePipeline.Radiance);cb.Blit(Sized(missRecords,size,size),p.TracePipeline.Record);p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);};
            miss();var decayed=Read(p.Temporal);var retained=geometry.Where(j=>decayed[j].a>0).ToArray();
            Check(retained.Length>50,"visible retained sources survive a current stochastic miss");
            Check(retained.All(j=>Math.Abs(decayed[j].a-average[j].a*7/8)<.001f),"current misses decay rough coverage instead of holding bright history");
            var missingAnchors=Read(p.HistoryAnchor);Check(retained.All(j=>Math.Abs(missingAnchors[j].a-1)<.001f),"missing observation retains validated source class without an expiry counter");
            var plane=Read(p.HistoryPlane);var material=Read(p.HistoryMaterial);
            Action restore=()=>{PrepareFrozenTrace(cb,p);globals();cb.Blit(Sized(average,size,size),p.History);cb.Blit(Sized(anchors,size,size),p.HistoryAnchor);
                cb.Blit(Sized(stats,size,size),p.HistoryStats);cb.Blit(Sized(guide,size,size),p.HistoryGuide);
                cb.Blit(Sized(points,size,size),p.HistoryPoint);cb.Blit(Sized(plane,size,size),p.HistoryPlane);cb.Blit(Sized(material,size,size),p.HistoryMaterial);};
            restore();cb.Blit(Sized(anchors.Select(v=>v.a>0?new Color(v.r,v.g,v.b,2):v).ToArray(),size,size),p.HistoryAnchor);
            cb.Blit(Sized(raw,size,size),p.TracePipeline.Radiance);cb.Blit(Sized(records,size,size),p.TracePipeline.Record);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var differentClass=Read(p.Temporal);
            Check(geometry.All(j=>Math.Abs(differentClass[j].a-current[j].a/8)<.001f),"geometry discards retained sky radiance while preserving compatible receiver count");
            restore();cb.Blit(Sized(anchors.Select(v=>v.a>0?new Color(v.r,v.g,-1000,v.a):v).ToArray(),size,size),p.HistoryAnchor);miss();
            var rejectedSource=Read(p.Temporal);Check(geometry.All(j=>rejectedSource[j].a==0),"a retained geometry source must still match current visible depth");
            var rejectedStats=Read(p.TemporalStats);
            Check(geometry.All(j=>rejectedStats[j].r==8 && rejectedStats[j].g==0 && rejectedStats[j].b==0),"source rejection clears radiance moments together without cold-starting receiver count");
            restore();cb.Blit(Sized(guide.Select(v=>new Color(v.r,v.g+10,v.b,v.a)).ToArray(),size,size),p.HistoryGuide);miss();
            Check(Read(p.Temporal).All(v=>v.a==0),"coverage accumulation rejects receiver disocclusion");
            restore();cb.SetGlobalTexture("_CameraMotionVectorsTexture",Texture(Enumerable.Repeat(new Color(2,2,0,0),width*height).ToArray()));
            cb.Blit(Texture2D.blackTexture,p.TracePipeline.Radiance);cb.Blit(Sized(missRecords,size,size),p.TracePipeline.Record);p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(p.Temporal).All(v=>v.a==0) && Read(p.TemporalStats).All(v=>v.a==4),"coverage accumulation rejects out-of-bounds motion-vector reprojection");
            restore();cb.SetGlobalTexture("_CameraMotionVectorsTexture",Texture(alignedMotion.GetPixels().Select(v=>new Color(v.r+.3f/size,v.g,0,0)).ToArray()));
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(p.Temporal).Count(v=>v.a>0)>50 && Read(p.TemporalStats).All(v=>v.r<=8.001f),"fractional receiver motion retains bounded statistical coverage through the four-tap gather");
            restore();for(int frame=0;frame<10;frame++)miss();
            var late=Read(p.Temporal);
            Check(retained.All(j=>Math.Abs(late[j].a-average[j].a*Math.Pow(7.0/8,10))<.001),"visible missing sources decay continuously beyond History frames without abrupt expiry");
            Check(Read(p.TemporalStats).Where((v,j)=>geometry.Contains(j)).All(v=>v.r==8),"long miss sequences retain bounded receiver observation counts");
            restore();cb.Blit(Sized(raw,size,size),p.TracePipeline.Radiance);cb.Blit(Sized(records,size,size),p.TracePipeline.Record);
            o.CoverageTemporal=false;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(p.HistoryAnchor==null && p.TemporalAnchor==null,"A/B off releases statistical source-anchor buffers");
            var changed=o;changed.CoverageTemporal=true;Check(!o.SameRendering(changed),"coverage toggle participates in rendering-state invalidation");
            changed=o;changed.CoverageFullSmoothness=.45f;Check(!o.SameRendering(changed),"full-strength threshold participates in rendering-state invalidation");
            changed=o;changed.CoverageEndSmoothness=.8f;Check(!o.SameRendering(changed),"fade-out threshold participates in rendering-state invalidation");
            o.CoverageTemporal=true;o.Temporal=false;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(p.HistoryAnchor==null && p.TemporalAnchor==null,"temporal off allocates no source-anchor buffers");
        }
    }
    private static void TemporalStabilityContracts()
    {
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            const int size=128;p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
            var o=Options();o.Temporal=true;
            Action render=()=>{Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);};
            render();
            var initial=Read(p.TemporalStats);Check(initial.Any(v=>v.r==1) && initial.All(v=>v.r<=1),"cold history starts with one measured sample");
            for(int frame=0;frame<8;frame++)render();
            var warm=Read(p.TemporalStats);Check(warm.Count(v=>v.r>4)>100 && warm.All(v=>v.r<=8.001f),"stationary effective history grows and stays bounded");
            var guide=Read(p.HistoryGuide);var material=Read(p.HistoryMaterial);var point=Read(p.HistoryPoint);var record=Read(p.TracePipeline.Record);
            var history=Read(p.History);var plane=Read(p.HistoryPlane);var statistics=Read(p.HistoryStats);
            Action restore=()=>{
                PrepareFrozenTrace(cb,p);Globals(cb);cb.Blit(Sized(guide,size,size),p.HistoryGuide);cb.Blit(Sized(material,size,size),p.HistoryMaterial);
                cb.Blit(Sized(point,size,size),p.HistoryPoint);
                cb.Blit(Sized(history,size,size),p.History);cb.Blit(Sized(plane,size,size),p.HistoryPlane);
                cb.Blit(Sized(statistics,size,size),p.HistoryStats);
            };
            // Fractional motion over the existing planar receiver: history must
            // not snap to the deliberately invalid nearest texel.
            var damaged=guide.ToArray();for(int j=0;j<damaged.Length;j++)if(j%size%2==0)damaged[j].g+=10;
            restore();cb.Blit(Sized(damaged,size,size),p.HistoryGuide);
            cb.SetGlobalTexture("_CameraMotionVectorsTexture",Texture(Enumerable.Repeat(new Color(.3f/size,0,0,0),width*height).ToArray()));
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            var gathered=Read(p.TemporalStats);
            Check(Enumerable.Range(0,gathered.Length).Count(j=>j%size%2==0 && gathered[j].r>1)>50,"four-tap temporal gather recovers support beside rejected nearest texels");
            // Actual disocclusion is still a rejection even with nearby taps.
            restore();cb.Blit(Sized(guide.Select(v=>new Color(v.r,v.g+10,v.b,v.a)).ToArray(),size,size),p.HistoryGuide);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(p.TemporalStats).All(v=>v.r<=1),"four-tap gather cannot bypass a receiver disocclusion");
            restore();cb.SetGlobalTexture("_CameraMotionVectorsTexture",Texture(Enumerable.Repeat(new Color(2,2,0,0),width*height).ToArray()));
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(p.TemporalStats).Where(v=>v.r>0).All(v=>(int)v.a==4),"out-of-bounds animated receiver motion records rejection");
            render();
            AccessTools.Field(typeof(ConfidenceSsrPipeline),"lastFrame").SetValue(p,Time.frameCount);
            AccessTools.Field(typeof(ConfidenceSsrPipeline),"lastTime").SetValue(p,Time.realtimeSinceStartup-.1f);
            render();Check(p.UsedHistory,"100ms interval alone preserves history");
            AccessTools.Field(typeof(ConfidenceSsrPipeline),"lastTime").SetValue(p,Time.realtimeSinceStartup-.6f);
            render();Check(!p.UsedHistory && p.LastResetReason.Contains("time-gap"),"600ms interval resets and reports time-gap");
            Check(Read(p.TemporalStats).All(v=>v.r<=1),"reset frame cannot reuse stale temporal moments");
            render();Check(p.UsedHistory,"history resumes immediately after a timing reset");
        }

    }
}
