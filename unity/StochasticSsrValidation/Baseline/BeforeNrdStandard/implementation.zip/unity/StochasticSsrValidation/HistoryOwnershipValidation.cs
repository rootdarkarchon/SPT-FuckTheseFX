using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HarmonyLib;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using CopyBaseline=FuckTheseFX.Source.StochasticSSR.HistoryCopyBaseline;

public static partial class StochasticSsrValidation
{
    // Frozen-signal tests deliberately edit history independently of current
    // inputs. Reclaim the writer before those validation-only edits, then refill
    // its unchanged raw metadata. Production Render does this before tracing.
    private static void PrepareFrozenTrace(CommandBuffer cb,ConfidenceSsrPipeline p) {
        var hit=Read(p.TracePipeline.Hit);var point=Read(p.TracePipeline.HitPoint);var record=Read(p.TracePipeline.Record);
        p.PrepareTraceHistory();int w=p.TracePipeline.Hit.width,h=p.TracePipeline.Hit.height;
        cb.Blit(Sized(hit,w,h),p.TracePipeline.Hit);cb.Blit(Sized(point,w,h),p.TracePipeline.HitPoint);cb.Blit(Sized(record,w,h),p.TracePipeline.Record);
        Execute(cb);
    }
    private static bool ExactPixels(Color[] a,Color[] b) {
        if(a.Length!=b.Length)return false;
        for(int i=0;i<a.Length;i++)for(int c=0;c<4;c++)
            if(BitConverter.SingleToInt32Bits(a[i][c])!=BitConverter.SingleToInt32Bits(b[i][c]))return false;
        return true;
    }
    private static bool ExactPlane(Color[] a,Color[] b) {
        if(a.Length!=b.Length)return false;
        for(int i=0;i<a.Length;i++)foreach(int c in new[]{0,1,3})
            if(BitConverter.SingleToInt32Bits(a[i][c])!=BitConverter.SingleToInt32Bits(b[i][c]))return false;
        return true;
    }
    private static bool ExactClassification(Color[] records,Color[] planes) {
        return records.Length==planes.Length && Enumerable.Range(0,records.Length).All(i=>
            BitConverter.SingleToInt32Bits(records[i].a)==BitConverter.SingleToInt32Bits(planes[i].b));
    }
    private static void HistoryOwnershipContracts() {
        var shader=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeHistoryOwnership/Reflection.shader");
        var savedSpec=specular;
        var rows=new List<string>{"reconstruction,coverage,frame,resource,bit_exact"};
        try {
            specular=Texture(specular.GetPixels().Select((v,i)=>new Color(v.r,v.g,v.b,new[]{.2f,.6f,.98f,1f}[i%4])).ToArray());
            foreach(var reconstruction in new[]{ReflectionReconstruction.Custom,ReflectionReconstruction.NativeGaussian})
            foreach(bool coverage in new[]{false,true}) {
                using(var cb=new CommandBuffer())
                using(var before=new CopyBaseline.ConfidenceSsrPipeline(compute,blend,shader,noise,native,gaussian))
                using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    var o=Options();o.Smoothness=0;o.Freeze=false;o.Temporal=true;o.CoverageTemporal=coverage;
                    o.CoverageFullSmoothness=.5f;o.CoverageEndSmoothness=.9f;o.Reconstruction=reconstruction;
                    o.CoverageFilter=true;o.CoverageFilterStrength=.8f;o.CoverageFilterFullSmoothness=.5f;o.CoverageFilterEndSmoothness=.9f;o.CoverageFilterSmoothStrength=.25f;
                    for(int frame=0;frame<26;frame++) {
                        int size=frame>=12 && frame<15?256:128;
                        before.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
                        if(frame==8){before.ResetHistory();after.ResetHistory();}
                        o.Temporal=frame!=16 && frame!=17;o.CoverageTemporal=coverage && frame!=19;
                        o.HistoryFrames=frame==21?1:8;
                        var motion=Texture(Enumerable.Repeat(new Color(frame==5?2:frame%3==1?.3f/size:0,0,0,0),width*height).ToArray());
                        Action globals=()=>{Globals(cb);TodGlobals(cb,.2f);cb.SetGlobalTexture("_CameraMotionVectorsTexture",motion);};
                        globals();before.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                        var output=Read(camera.targetTexture);
                        var expected=new Dictionary<string,Color[]>();
                        Action<string,RenderTexture> capture=(name,t)=>{if(t!=null)expected[name]=Read(t);};
                        capture("raw",before.TracePipeline.Radiance);capture("guide",before.TracePipeline.Hit);capture("point",before.TracePipeline.HitPoint);capture("record",before.TracePipeline.Record);
                        capture("resolved",before.Resolved);capture("temporal",before.Temporal);capture("stats",before.TemporalStats);capture("display",before.DepthGapFilled);
                        capture("history",before.History);capture("history-guide",before.HistoryGuide);capture("history-point",before.HistoryPoint);capture("history-record",before.HistoryRecord);
                        capture("history-stats",before.HistoryStats);capture("history-plane",before.HistoryPlane);capture("history-material",before.HistoryMaterial);capture("anchor",before.TemporalAnchor);capture("history-anchor",before.HistoryAnchor);
                        globals();after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                        var actualOutput=Read(camera.targetTexture);
                        var actual=new Dictionary<string,RenderTexture>{{"raw",after.TracePipeline.Radiance},{"guide",after.TracePipeline.Hit},{"point",after.TracePipeline.HitPoint},{"record",after.TracePipeline.Record},
                            {"resolved",after.Resolved},{"temporal",after.Temporal},{"stats",after.TemporalStats},{"display",after.DepthGapFilled},{"history",after.History},{"history-guide",after.HistoryGuide},
                            {"history-point",after.HistoryPoint},{"history-stats",after.HistoryStats},{"history-plane",after.HistoryPlane},{"history-material",after.HistoryMaterial},{"anchor",after.TemporalAnchor},{"history-anchor",after.HistoryAnchor}};
                        foreach(var pair in expected) {
                            Check(pair.Key=="history-record"?ExactClassification(pair.Value,Read(after.HistoryPlane)):pair.Key=="history-plane"?ExactPlane(pair.Value,Read(after.HistoryPlane)):ExactPixels(pair.Value,Read(actual[pair.Key])),"history ownership bit exact "+pair.Key+" "+reconstruction+" coverage="+coverage+" frame="+frame+" max="+(pair.Key=="history-record" || pair.Key=="history-plane"?0:Error(pair.Value,Read(actual[pair.Key]))));
                            rows.Add(reconstruction+","+coverage+","+frame+","+pair.Key+",True");
                        }
                        Check(ExactPixels(output,actualOutput),"history ownership exact composition "+reconstruction+" coverage="+coverage+" frame="+frame+" max="+Error(output,actualOutput));
                        Check(before.UsedHistory==after.UsedHistory && before.LastResetReason==after.LastResetReason && before.TracePipeline.LastSamplePhase==after.TracePipeline.LastSamplePhase,"history ownership reset and sample phase parity "+frame);
                        if(o.Temporal) {
                            Check(ReferenceEquals(after.Temporal,after.History) && ReferenceEquals(after.TemporalStats,after.HistoryStats) && ReferenceEquals(after.TracePipeline.Hit,after.HistoryGuide) &&
                                ReferenceEquals(after.TracePipeline.HitPoint,after.HistoryPoint),"four history pairs transfer ownership "+frame);
                            Check(after.HistoryGuide.enableRandomWrite && after.HistoryPoint.enableRandomWrite,"rotated trace allocations retain UAV capability "+frame);
                            if(after.HistoryAnchor!=null)Check(ReferenceEquals(after.TemporalAnchor,after.HistoryAnchor),"coverage anchor transfers ownership "+frame);
                        }
                    }
                    // Several frames can be recorded before command execution.
                    for(int i=0;i<4;i++){Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);}
                    Execute(cb);var batched=Read(camera.targetTexture);
                    for(int i=0;i<4;i++){Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);}
                    Execute(cb);Check(ExactPixels(batched,Read(camera.targetTexture)) && ExactPixels(Read(before.History),Read(after.History)),"batched command buffers retain exact history ownership parity");
                }
            }
        } finally {specular=savedSpec;File.WriteAllLines("history-ownership-parity.csv",rows);}
    }
}
