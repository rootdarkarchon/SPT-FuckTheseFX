using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HarmonyLib;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using CopyBaseline=FuckTheseFX.Source.StochasticSSR.HistoryOwnershipBaseline;

public static partial class StochasticSsrValidation
{
    private static void HistoryReadbackContracts() {
        string savedRoot=BepInEx.Paths.BepInExRootPath;
        var shader=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeHistoryPacking/Reflection.shader");
        var folders=new List<string>();
        try {
            foreach(bool old in new[]{true,false}) {
                string root=Path.GetFullPath("Capture-test/HistoryReadback-"+(old?"before":"after")+"-"+DateTime.UtcNow.Ticks);
                AccessTools.Property(typeof(BepInEx.Paths),"BepInExRootPath").SetValue(null,root);
                using(var cb=new CommandBuffer())using(var before=new CopyBaseline.ConfidenceSsrPipeline(compute,blend,shader,noise,native,gaussian))
                using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    var o=Options();o.Temporal=true;o.CoverageTemporal=true;o.CoverageFullSmoothness=.7f;o.CoverageEndSmoothness=.95f;o.Freeze=false;
                    before.Ensure(width,height,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,64,RenderTextureFormat.ARGBHalf);
                    Action render=()=>{Globals(cb);TodGlobals(cb,.2f);if(old)before.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);else after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);};
                    for(int i=0;i<3;i++)render();
                    // Explicit reset invalidates reuse, not the previous record's
                    // diagnostic contents. Preserve those exact contents too.
                    if(old)before.ResetHistory();else after.ResetHistory();
                    var previous=Read(old?before.HistoryRecord:after.TracePipeline.Record);
                    o.CaptureContinuation=true;render();
                    var capture=(ContinuationCapture)AccessTools.Field(old?typeof(CopyBaseline.ConfidenceSsrPipeline):typeof(ConfidenceSsrPipeline),"continuationCapture").GetValue(old?(object)before:after);
                    var retired=old?before.HistoryGuide:after.HistoryGuide;
                    for(int i=0;i<3;i++)render();
                    if(old)before.Ensure(width,height,96,RenderTextureFormat.ARGBHalf);else after.Ensure(width,height,96,RenderTextureFormat.ARGBHalf);
                    Check(!capture.Pending || retired.IsCreated(),"pending history readback retains resized allocation "+old);
                    o.Temporal=false;render();o.Temporal=true;render();
                    AsyncGPUReadback.WaitAllRequests();Check(!capture.Pending,"history readback completes through rotation resize and toggles "+old);
                    string folder=Directory.GetDirectories(Path.Combine(root,"FTFX-SSR-Captures")).Single();folders.Add(folder);
                    var expectedTexture=new Texture2D(64,64,TextureFormat.RGBAFloat,false,true);
                    byte[] encoded;
                    try {expectedTexture.SetPixels(previous);expectedTexture.Apply();encoded=expectedTexture.EncodeToEXR(Texture2D.EXRFlags.OutputAsFloat|Texture2D.EXRFlags.CompressZIP);}
                    finally {UnityEngine.Object.DestroyImmediate(expectedTexture);}
                    File.WriteAllBytes(Path.Combine(folder,"expected-previous-record.exr"),encoded);
                    Check(encoded.SequenceEqual(File.ReadAllBytes(Path.Combine(folder,"previous-measured-record.exr"))),"full previous raw record survives reset and queued overwrite "+old);
                    if(!old){o.CaptureContinuation=false;render();Check(AccessTools.Field(typeof(ConfidenceSsrPipeline),"previousRecordCapture").GetValue(after)==null,"ordinary rendering releases diagnostic-only previous record storage");}
                }
            }
            foreach(string file in Directory.GetFiles(folders[0],"*.exr")) {
                string name=Path.GetFileName(file);var a=ReplayHistoryTexture(file);var b=ReplayHistoryTexture(Path.Combine(folders[1],name));
                Check(name=="previous-measured-plane.exr"?ExactPlane(a,b):ExactPixels(a,b),"capture pixels exact across packing and subsequent overwrite: "+name);
            }
        } finally {AccessTools.Property(typeof(BepInEx.Paths),"BepInExRootPath").SetValue(null,savedRoot);}
    }
    private static Color[] ReplayHistoryTexture(string file) {
        string asset="Assets/HistoryReadback/"+Path.GetFileName(Path.GetDirectoryName(file))+"-"+Guid.NewGuid().ToString("N")+".exr";
        Directory.CreateDirectory(Path.GetDirectoryName(asset));File.Copy(file,asset);AssetDatabase.ImportAsset(asset,ImportAssetOptions.ForceSynchronousImport);
        var importer=(TextureImporter)AssetImporter.GetAtPath(asset);importer.sRGBTexture=false;importer.isReadable=true;importer.mipmapEnabled=false;importer.npotScale=TextureImporterNPOTScale.None;
        importer.textureCompression=TextureImporterCompression.Uncompressed;importer.maxTextureSize=8192;
        importer.SetPlatformTextureSettings(new TextureImporterPlatformSettings{name="Standalone",overridden=true,maxTextureSize=8192,format=TextureImporterFormat.RGBAFloat});importer.SaveAndReimport();
        return AssetDatabase.LoadAssetAtPath<Texture2D>(asset).GetPixels();
    }
    private static void HistoryPackingContracts() {
        var shader=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeHistoryOwnership/Reflection.shader");
        var savedSpec=specular;
        var rows=new List<string>{"reconstruction,coverage,frame,resource,bit_exact"};
        try {
            specular=Texture(specular.GetPixels().Select((v,i)=>new Color(v.r,v.g,v.b,new[]{.2f,.6f,.98f,1f}[i%4])).ToArray());
            foreach(var reconstruction in new[]{ReflectionReconstruction.Custom,ReflectionReconstruction.NativeGaussian})
            foreach(bool coverage in new[]{false,true}) {
                using(var cb=new CommandBuffer())
                using(var before=new CopyBaseline.ConfidenceSsrPipeline(compute,blend,shader,noise,native,gaussian))
                using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    var o=Options();o.Smoothness=0;o.Freeze=false;o.Temporal=true;o.CoverageTemporal=coverage;
                    o.CoverageFullSmoothness=.5f;o.CoverageEndSmoothness=.9f;o.Reconstruction=reconstruction;
                    o.CoverageFilter=true;o.CoverageFilterStrength=.8f;o.CoverageFilterFullSmoothness=.5f;o.CoverageFilterEndSmoothness=.9f;o.CoverageFilterSmoothStrength=.25f;
                    for(int frame=0;frame<26;frame++) {
                        int size=frame>=12 && frame<15?256:128;
                        before.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
                        if(frame==8){before.ResetHistory();after.ResetHistory();}
                        o.Temporal=frame!=16 && frame!=17;o.CoverageTemporal=coverage && frame!=19;
                        o.HistoryFrames=frame==21?1:8;
                        var motion=Texture(Enumerable.Repeat(new Color(frame==5?2:frame%3==1?.3f/size:0,0,0,0),width*height).ToArray());
                        Action globals=()=>{Globals(cb);TodGlobals(cb,.2f);cb.SetGlobalTexture("_CameraMotionVectorsTexture",motion);};
                        globals();before.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                        var output=Read(camera.targetTexture);
                        var expected=new Dictionary<string,Color[]>();
                        Action<string,RenderTexture> capture=(name,t)=>{if(t!=null)expected[name]=Read(t);};
                        capture("raw",before.TracePipeline.Radiance);capture("guide",before.TracePipeline.Hit);capture("point",before.TracePipeline.HitPoint);capture("record",before.TracePipeline.Record);
                        capture("resolved",before.Resolved);capture("temporal",before.Temporal);capture("stats",before.TemporalStats);capture("display",before.DepthGapFilled);
                        capture("history",before.History);capture("history-guide",before.HistoryGuide);capture("history-point",before.HistoryPoint);capture("history-record",before.HistoryRecord);
                        capture("history-stats",before.HistoryStats);capture("history-plane",before.HistoryPlane);capture("history-material",before.HistoryMaterial);capture("anchor",before.TemporalAnchor);capture("history-anchor",before.HistoryAnchor);
                        globals();after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                        var actualOutput=Read(camera.targetTexture);
                        var actual=new Dictionary<string,RenderTexture>{{"raw",after.TracePipeline.Radiance},{"guide",after.TracePipeline.Hit},{"point",after.TracePipeline.HitPoint},{"record",after.TracePipeline.Record},
                            {"resolved",after.Resolved},{"temporal",after.Temporal},{"stats",after.TemporalStats},{"display",after.DepthGapFilled},{"history",after.History},{"history-guide",after.HistoryGuide},
                            {"history-point",after.HistoryPoint},{"history-stats",after.HistoryStats},{"history-plane",after.HistoryPlane},{"history-material",after.HistoryMaterial},{"anchor",after.TemporalAnchor},{"history-anchor",after.HistoryAnchor}};
                        foreach(var pair in expected) {
                            Check(pair.Key=="history-record"?ExactClassification(pair.Value,Read(after.HistoryPlane)):pair.Key=="history-plane"?ExactPlane(pair.Value,Read(after.HistoryPlane)):ExactPixels(pair.Value,Read(actual[pair.Key])),"history packing bit exact "+pair.Key+" "+reconstruction+" coverage="+coverage+" frame="+frame+" max="+(pair.Key=="history-record" || pair.Key=="history-plane"?0:Error(pair.Value,Read(actual[pair.Key]))));
                            rows.Add(reconstruction+","+coverage+","+frame+","+pair.Key+",True");
                        }
                        Check(ExactPixels(output,actualOutput),"history packing exact composition "+reconstruction+" coverage="+coverage+" frame="+frame+" max="+Error(output,actualOutput));
                        Check(before.UsedHistory==after.UsedHistory && before.LastResetReason==after.LastResetReason && before.TracePipeline.LastSamplePhase==after.TracePipeline.LastSamplePhase,"history packing reset and sample phase parity "+frame);
                        if(o.Temporal) {
                            Check(ReferenceEquals(after.Temporal,after.History) && ReferenceEquals(after.TemporalStats,after.HistoryStats) && ReferenceEquals(after.TracePipeline.Hit,after.HistoryGuide) &&
                                ReferenceEquals(after.TracePipeline.HitPoint,after.HistoryPoint),"four history pairs transfer ownership "+frame);
                            Check(after.HistoryGuide.enableRandomWrite && after.HistoryPoint.enableRandomWrite,"rotated trace allocations retain UAV capability "+frame);
                            if(after.HistoryAnchor!=null)Check(ReferenceEquals(after.TemporalAnchor,after.HistoryAnchor),"coverage anchor transfers ownership "+frame);
                        }
                    }
                    // Several frames can be recorded before command execution.
                    for(int i=0;i<4;i++){Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);}
                    Execute(cb);var batched=Read(camera.targetTexture);
                    for(int i=0;i<4;i++){Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);}
                    Execute(cb);Check(ExactPixels(batched,Read(camera.targetTexture)) && ExactPixels(Read(before.History),Read(after.History)),"batched command buffers retain exact history packing parity");
                }
            }
        } finally {specular=savedSpec;File.WriteAllLines("history-packing-parity.csv",rows);}
    }
}
