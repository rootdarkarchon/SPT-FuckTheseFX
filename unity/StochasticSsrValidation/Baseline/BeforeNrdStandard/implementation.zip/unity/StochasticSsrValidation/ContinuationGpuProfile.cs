using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using CustomAmbientResearch;
using Baseline=FuckTheseFX.Source.StochasticSSR.ContinuationOptimizationBaseline;

public static partial class StochasticSsrValidation
{
    private static Texture2D ReplayTexture(string folder,string name)
    {
        string destination="Assets/Replay/"+Path.GetFileName(folder)+"/"+name+".exr";
        Directory.CreateDirectory(Path.GetDirectoryName(destination));File.Copy(Path.Combine(folder,name+".exr"),destination,true);
        AssetDatabase.ImportAsset(destination,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
        var importer=(TextureImporter)AssetImporter.GetAtPath(destination);
        importer.sRGBTexture=false;importer.isReadable=true;importer.mipmapEnabled=false;importer.npotScale=TextureImporterNPOTScale.None;
        importer.textureCompression=TextureImporterCompression.Uncompressed;importer.maxTextureSize=8192;
        importer.SetPlatformTextureSettings(new TextureImporterPlatformSettings{name="Standalone",overridden=true,maxTextureSize=8192,format=TextureImporterFormat.RGBAFloat});
        importer.SaveAndReimport();return AssetDatabase.LoadAssetAtPath<Texture2D>(destination);
    }
    private static Matrix4x4 ReplayMatrix(string line)
    {
        var values=line.Substring(line.IndexOf('=')+1).Split(',').Select(v=>float.Parse(v,CultureInfo.InvariantCulture)).ToArray();
        var m=new Matrix4x4();for(int i=0;i<16;i++)m[i]=values[i];return m;
    }
    private static Texture2D SetupCapturedReplay(string folder)
    {
        var settings=File.ReadAllLines(Path.Combine(folder,"settings.txt"));
        var projection=ReplayMatrix(settings.First(v=>v.StartsWith("Projection=")));
        var world=ReplayMatrix(settings.First(v=>v.StartsWith("CameraToWorld=")));
        camera.nearClipPlane=projection.m23/(1+projection.m22);camera.farClipPlane=projection.m23/projection.m22;
        camera.fieldOfView=2*Mathf.Atan(1/projection.m11)*Mathf.Rad2Deg;camera.aspect=projection.m11/projection.m00;
        camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world.inverse;
        scene=ReplayTexture(folder,"scene-source");normals=ReplayTexture(folder,"gbuffer2");specular=ReplayTexture(folder,"gbuffer1");
        Check(scene.width==width && scene.height==height,"capture-derived camera extent matches fixture");
        var eye=ReplayTexture(folder,"trace-depth");var pixels=eye.GetPixels();var raw=new Color[width*height];
        var gpu=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
        Check(Enumerable.Range(0,16).All(i=>Mathf.Abs(gpu[i]-projection[i])<2e-6f),"capture-derived projection convention matches DX11");
        for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
            float z=pixels[y*eye.width+x].r;var clip=gpu*new Vector4(0,0,-z,1);raw[y*width+x]=new Color(clip.z/clip.w,0,0,0);
        }
        depths=Texture(raw);return ReplayTexture(folder,"water");
    }
    private static void ProfileContinuationCandidates()
    {
        bool replayOnly=File.Exists("continuation-replay-only.txt");
        perStage=false;completionOutput=null;
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeContinuationOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeContinuationOptimization/Reflection.shader");
        var rows=new List<string>{"dataset,candidate,region,trial,phase,sample,gpu_ms"};
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        var originalWorld=camera.worldToCameraMatrix;float originalNear=camera.nearClipPlane,originalFar=camera.farClipPlane,originalFov=camera.fieldOfView;
        var datasets=new[]{"floor-wall","captured-water","captured-ground"};
        try {
            AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
            foreach(string dataset in datasets) {
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                camera.nearClipPlane=originalNear;camera.farClipPlane=originalFar;camera.fieldOfView=originalFov;
                camera.ResetProjectionMatrix();camera.worldToCameraMatrix=originalWorld;Fixture();
                Texture2D mask=null;
                if(dataset!="floor-wall") {
                    string folder=Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",dataset=="captured-water"?"20261001-102353-500":"20261001-102702-951");
                    mask=SetupCapturedReplay(folder);
                }
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer())using(var baseline=new Baseline.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian)) {
                    Check(AmbientReflectionCapture.Begin(cb,camera,true),"candidate profile has captured native subtraction");cb.ClearRandomWriteTargets();
                    cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));
                    cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    var o=Options();o.Freeze=true;o.Temporal=false;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalStartDistance=10;o.NormalEndDistance=100;o.NormalRadius=4;
                    o.BypassHitNormal=true;o.UseCapturedContribution=true;o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
                    o.Thickness=1;o.ThicknessConfidenceFloor=1;o.FallbackStrength=.600939f;o.SurfaceColourInfluence=.1971831f;
                    baseline.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);baseline.PrepareRaster(camera,1,width,height);baseline.TracePipeline.Raster.FinalizeRaster(camera);
                    var oldOptions=CandidateOptions(o);
                    var variants=new Dictionary<string,ConfidenceSsrPipeline> {
                        {"composition",new ConfidenceSsrPipeline(oldCompute,blend,AssetDatabase.LoadAssetAtPath<Shader>("Assets/ReceiverProjection.shader"),noise,native,gaussian)},
                        {"traversal-state",new ConfidenceSsrPipeline(compute,blend,oldReflection,noise,native,gaussian)},
                        {"fallback-final-mip",new ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian)},
                        {"group16x8",new ConfidenceSsrPipeline(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/Trace16x8.compute"),blend,oldReflection,noise,native,gaussian)},
                        {"group16x16",new ConfidenceSsrPipeline(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/Trace16x16.compute"),blend,oldReflection,noise,native,gaussian)},
                        {"combined",new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)}
                    };
                    try {
                        foreach(var variant in variants) {
                            variant.Value.ReceiverFallback.DirectFinalMip=variant.Key=="fallback-final-mip" || variant.Key=="combined";
                            variant.Value.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);variant.Value.PrepareRaster(camera,1,width,height);variant.Value.TracePipeline.Raster.FinalizeRaster(camera);
                        }
                        Globals(cb);TodGlobals(cb,.2f);baseline.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular);Execute(cb);
                        var image=Read(camera.targetTexture);var record=Read(baseline.TracePipeline.Record);var raw=Read(baseline.TracePipeline.Radiance);var stop=Read(baseline.TracePipeline.TraceStop);var cost=Read(baseline.TracePipeline.TraceInfo);
                        foreach(var variant in variants) {
                            Globals(cb);TodGlobals(cb,.2f);variant.Value.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                            Check(Error(record,Read(variant.Value.TracePipeline.Record))==0 && Error(raw,Read(variant.Value.TracePipeline.Radiance))==0 && Error(stop,Read(variant.Value.TracePipeline.TraceStop))==0 &&
                                Error(cost,Read(variant.Value.TracePipeline.TraceInfo))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"R1024 fixed-input candidate parity "+dataset+"/"+variant.Key);
                        }
                        var diagnostic=variants["combined"];
                        Globals(cb);diagnostic.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                        string output="traversal-"+dataset;Directory.CreateDirectory(output);
                        ContinuationCapture.SaveTraversal(output,Read(diagnostic.TracePipeline.Sample),Read(diagnostic.TracePipeline.DepthHit),Read(diagnostic.TracePipeline.Record),Read(diagnostic.TracePipeline.TraceInfo),1024);
                        if(!replayOnly)foreach(string region in new[]{"outer-SSR","depth-normal-trace-sky"})for(int trial=0;trial<3;trial++) {
                            var ordered=trial%2==0?variants.ToArray():variants.Reverse().ToArray();
                            foreach(var variant in ordered) {
                                for(int warm=0;warm<24;warm++) {
                                    Globals(cb);TodGlobals(cb,.2f);baseline.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular);
                                    Globals(cb);TodGlobals(cb,.2f);variant.Value.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                                }
                                Execute(cb);GpuBarrier();
                                for(int first=0;first<24;first+=4) {
                                    for(int sample=first;sample<first+4;sample++)for(int phase=0;phase<3;phase++) {
                                        bool candidate=phase==1;int frame=trial*10000+sample*3+phase;
                                        Globals(cb);TodGlobals(cb,.2f);var ticket=timer.Reserve(frame,candidate?2:1,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"candidate A/B/A reservation");timer.Event(cb,1,ticket);
                                        if(region=="outer-SSR") {
                                            if(candidate)variant.Value.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                                            else baseline.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular);
                                        } else {
                                            const int completionStage=400;timer.DeepMark(cb,completionStage);
                                            if(candidate)variant.Value.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular);
                                            else baseline.TracePipeline.Trace(cb,camera,scene,oldOptions,depths,normals,specular);
                                            timer.DeepMark(cb,completionStage,true,true,candidate?variant.Value.TracePipeline.Radiance:baseline.TracePipeline.Radiance);
                                        }
                                        timer.Event(cb,2,ticket);
                                    }
                                    Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                                    var buffer=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;while((count=timer.Read(buffer))>0)results.AddRange(buffer.Take(count));
                                    Check(results.Count(r=>r.Stage==0)==12 && results.All(r=>r.Flags==0) && timer.Pending==0,"candidate A/B/A queries complete without disjoint/missing intervals");
                                    if(region!="outer-SSR")Check(results.Count(r=>r.Stage==400)==12,"combined-front-end completion intervals are present");
                                    foreach(var r in results.Where(r=>r.Stage==0)) {
                                        int sample=(r.Frame%10000)/3,phase=r.Frame%3;
                                        // Frame encoding uses trial*10000, which is not divisible by 3.
                                        phase=(r.Frame%10000)%3;
                                        rows.Add(dataset+","+variant.Key+","+region+","+trial+","+phase+","+sample+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                                    }
                                }
                            }
                        }
                    } finally {foreach(var variant in variants.Values)variant.Dispose();}
                    AmbientReflectionCapture.Dispose();if(!replayOnly)File.WriteAllLines("continuation-candidate-gpu.csv",rows);
                }
            }
        } finally {AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;
            camera.nearClipPlane=originalNear;camera.farClipPlane=originalFar;camera.fieldOfView=originalFov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=originalWorld;Fixture();}
        if(replayOnly){File.WriteAllText("continuation-replay-method.txt","Functional captured-input parity and traversal diagnostics only. No GPU timestamps or performance comparisons collected.\n");return;}
        File.WriteAllLines("continuation-candidate-gpu.csv",rows);
        File.WriteAllText("continuation-candidate-method.txt","RTX4090 DX11 Unity execution. R1024 / 2560x1440. Current budgets and appearance options; temporal off, sample phase frozen, late raster. Independently tested composition, final fallback mip, group layouts, combined build. Three warmed A/B/A trials, first four samples discarded, 20 retained per phase/trial. Queries enclose the entire SSR pipeline with no internal completion probes. Separate depth+normal+trace+sky region has one completion probe at the end. Readback/fences are after measured batches. Capture-derived inputs are imported EXRs from older scene captures and eye depth re-encoded through their projection; they are not a live Tarkov benchmark or an exact replay of prior performance captures. Whole-frame/presentation/other-camera work is unavailable in this editor fixture.\n");
    }
}
