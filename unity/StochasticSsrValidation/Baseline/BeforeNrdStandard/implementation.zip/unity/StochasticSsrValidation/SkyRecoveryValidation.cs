using System;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;

public static partial class StochasticSsrValidation
{
    private static Texture2D SkyReplayTexture(string folder,string name)
    {
        string path=Path.Combine("SkyReplayRaw",Path.GetFileName(folder),name+".rgba32f");
        using(var reader=new BinaryReader(File.OpenRead(path))) {
            int w=reader.ReadInt32(),h=reader.ReadInt32();
            var t=new Texture2D(w,h,TextureFormat.RGBAFloat,false,true){filterMode=FilterMode.Point};
            t.LoadRawTextureData(reader.ReadBytes(checked(w*h*16)));t.Apply();owned.Add(t);return t;
        }
    }
    private static Matrix4x4 SkyReplayMatrix(string line)
    {
        var values=line.Substring(line.IndexOf('=')+1).Split(',').Select(v=>float.Parse(v,CultureInfo.InvariantCulture)).ToArray();
        var m=new Matrix4x4();for(int i=0;i<16;i++)m[i]=values[i];return m;
    }
    private static void SkyRecoveryReplayContracts()
    {
        if(!File.Exists("sky-recovery-replay.txt"))return;
        string captureRoot=Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures");
        if(!new[]{"20261002-213832-066","20261002-215552-280"}.All(c=>File.Exists(Path.Combine(captureRoot,c,"COMPLETE.txt")))) {
            Debug.Log("Optional sky recovery capture replay skipped: original puddle captures unavailable.");return;
        }
        int ow=width,oh=height;var oldDepth=depths;var oldScene=scene;var oldSpec=specular;var oldNormal=normals;var oldOcclusion=materialOcclusion;
        var target=camera.targetTexture;var world=camera.worldToCameraMatrix;var projection=camera.projectionMatrix;
        float near=camera.nearClipPlane,far=camera.farClipPlane,fov=camera.fieldOfView,aspect=camera.aspect;
        var rows=new System.Collections.Generic.List<string>{"capture,depth_allowance,global_sky,geometry,sky,continued_sky,depth_limit_misses,mean_skipped_cells,max_skipped_cells"};
        int extraSky=0;
        try {
            foreach(string capture in new[]{"20261002-213832-066","20261002-215552-280"}) {
                string folder=Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",capture);
                Check(File.Exists(Path.Combine(folder,"COMPLETE.txt")),"complete puddle capture available: "+capture);
                var settings=File.ReadAllLines(Path.Combine(folder,"settings.txt"));
                var p=SkyReplayMatrix(settings.First(v=>v.StartsWith("RasterProjection=")));
                var c2w=SkyReplayMatrix(settings.First(v=>v.StartsWith("CameraToWorld=")));
                scene=SkyReplayTexture(folder,"scene-source");normals=SkyReplayTexture(folder,"gbuffer2");specular=SkyReplayTexture(folder,"gbuffer1");
                materialOcclusion=SkyReplayTexture(folder,"gbuffer0");var eye=SkyReplayTexture(folder,"trace-depth");
                // GPU projection conversion loses precision in its tiny depth
                // coefficient. The recorded background depth preserves the
                // actual far clip more accurately than dividing GPU coefficients.
                var z=eye.GetPixels();
                width=scene.width;height=scene.height;camera.nearClipPlane=p.m23/(1+p.m22);camera.farClipPlane=z.Max(v=>v.r);
                camera.fieldOfView=2*Mathf.Atan(1/p.m11)*Mathf.Rad2Deg;camera.aspect=p.m11/p.m00;
                var cameraProjection=p;cameraProjection.SetRow(2,p.GetRow(3)-2*p.GetRow(2));camera.projectionMatrix=cameraProjection;camera.worldToCameraMatrix=c2w.inverse;
                var gpu=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);var raw=new Color[z.Length];
                Check(camera.farClipPlane>1000 && Enumerable.Range(0,16).All(j=>Mathf.Abs(gpu[j]-p[j])<2e-6f),"capture retains far-plane background and recorded raster projection: "+capture);
                for(int j=0;j<z.Length;j++){var clip=gpu*new Vector4(0,0,-z[j].r,1);raw[j]=new Color(clip.z/clip.w,0,0,0);}
                depths=Texture(raw);
                var output=new RenderTexture(width,height,0,RenderTextureFormat.ARGBHalf);output.Create();camera.targetTexture=output;
                try {using(var cb=new CommandBuffer())using(var pipeline=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    pipeline.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);
                    var o=Options();o.Smoothness=0;o.Steps=512;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.BypassHitNormal=true;
                    o.ContinuationSamples=557;o.ContinuationPixels=500;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.FallbackStrength=.6525822f;
                    o.Temporal=false;o.Freeze=true;o.UseCapturedContribution=false;
                    foreach(float allowance in new[]{50f,100f,200f}) {
                        Color[] waterOnly=null,oldCost=null;
                        foreach(bool global in new[]{false,true}) {
                            o.ContinuationDepth=allowance;o.GlobalContinuedSky=global;
                            Globals(cb);TodGlobals(cb,.2f);pipeline.Render(cb,camera,scene,output,o,depths,normals,specular,true);Execute(cb);
                            var records=Read(pipeline.TracePipeline.Record);var cost=Read(pipeline.TracePipeline.TraceInfo);
                            Check(Error(Read(pipeline.Resolved),Read(pipeline.DepthGapFilled))==0,"capture display never fills rejected-object colour: "+capture+" depth="+allowance+" global="+global);
                            Check(records.Select((r,j)=>r.a==2 && ((int)cost[j].a&64)!=0 && (cost[j].r>557 || cost[j].g>500 || cost[j].b>allowance || ((int)cost[j].a&8)!=0)).All(v=>!v),"captured sky recovery stays within all budgets");
                            if(!global){waterOnly=records;oldCost=cost;}
                            else {
                                int additions=0;
                                for(int j=0;j<records.Length;j++) {
                                    if(waterOnly[j].a==1) {if(records[j]!=waterOnly[j])throw new Exception("global sky altered geometry");}
                                    else if(records[j]!=waterOnly[j]) {
                                        if(waterOnly[j].a!=0 || waterOnly[j].b!=10 || records[j].a!=2 || ((int)cost[j].a&64)==0)throw new Exception("global sky recovered a protected miss");
                                        additions++;
                                    }
                                }
                                Check(Error(cost.Select(v=>new Color(v.r,v.g,v.b,0)).ToArray(),oldCost.Select(v=>new Color(v.r,v.g,v.b,0)).ToArray())==0,"global scope does not add traversal work");
                                Check(true,"capture scope changes only completed sky classification: "+additions);extraSky+=additions;
                            }
                            rows.Add(capture+","+allowance+","+global+","+records.Count(r=>r.a==1)+","+records.Count(r=>r.a==2)+","+records.Select((r,j)=>r.a==2 && ((int)cost[j].a&64)!=0).Count(v=>v)+","+records.Count(r=>r.a<=0 && r.b==11)+","+cost.Average(v=>(double)v.r).ToString("R",CultureInfo.InvariantCulture)+","+cost.Max(v=>v.r));
                        }
                    }
                }} finally {camera.targetTexture=target;output.Release();UnityEngine.Object.DestroyImmediate(output);}
            }
            File.WriteAllLines("sky-recovery-replay.csv",rows);
            Check(extraSky>0,"global scope recovers additional continued sky on real untagged puddle inputs");
        } finally {
            width=ow;height=oh;depths=oldDepth;scene=oldScene;specular=oldSpec;normals=oldNormal;materialOcclusion=oldOcclusion;camera.targetTexture=target;
            camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.aspect=aspect;camera.projectionMatrix=projection;camera.worldToCameraMatrix=world;
        }
    }
}
