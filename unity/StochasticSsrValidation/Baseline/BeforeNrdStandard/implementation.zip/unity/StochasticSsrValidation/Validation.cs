using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using FuckTheseFX.Source.StochasticSSR;
using HarmonyLib;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.PostProcessing;
namespace EFT.CameraControl { public class CameraManager { public static CameraManager Instance; public Camera Camera; } }
namespace FuckTheseFX { internal static class Plugin { internal const string Guid="com.rootdarkarchon.fuckthesefx"; internal static BepInEx.Logging.ManualLogSource MyLog=new BepInEx.Logging.ManualLogSource("SSR validation"); } }
public static partial class StochasticSsrValidation
{
    private static readonly List<string> checks=new List<string>();
    private static readonly List<UnityEngine.Object> owned=new List<UnityEngine.Object>();
    private static Camera camera;
    private static Texture2D depths,normals,specular,scene,noise,materialOcclusion,whiteGBuffer;
    private static Shader native,blend,reflection;
    private static ComputeShader compute,gaussian;
    private static AssetBundle game;
    private static Type rendererType;
    private static int[] passes;
    private static int width=192,height=128;
    private static RenderTexture nativeRecords;
    private static void Check(bool value,string text) { if(!value)throw new Exception(text);checks.Add(text);Debug.Log("PASS "+text); }
    private static void Execute(CommandBuffer cb) { Graphics.ExecuteCommandBuffer(cb);cb.Clear(); }
    private static Options Options()=>new Options {Mode=SsrMode.Stochastic,Steps=128,Distance=500,Thickness=.2f,Smoothness=.5f,HistoryFrames=8,EdgePixels=16,FallbackStrength=1,Freeze=true,NormalStartDistance=10,NormalEndDistance=100,NormalRadius=8};
    static partial void Profile();
    public static void Run()
    {
        try {
            AccessTools.Property(typeof(Paths),"BepInExConfigPath").SetValue(null,Path.GetFullPath("BepInEx-test.cfg"));
            AccessTools.Property(typeof(Paths),"ConfigPath").SetValue(null,Directory.GetCurrentDirectory());
            AccessTools.Property(typeof(Paths),"BepInExRootPath").SetValue(null,Path.GetFullPath("Capture-test"));
            compute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/HiZ.compute");blend=AssetDatabase.LoadAssetAtPath<Shader>("Assets/Support.shader");reflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/Reflection.shader");
            Check(!ShaderUtil.GetComputeShaderMessages(compute).Any(m=>m.severity.ToString()=="Error"),"Hi-Z compiles");
            foreach(var message in ShaderUtil.GetShaderMessages(reflection))Debug.Log(message.message+" line "+message.line);
            Check(!ShaderUtil.GetShaderMessages(reflection).Any(m=>m.severity.ToString()=="Error"),"reflection shader compiles");
            noise=new Texture2D(128,128,TextureFormat.RG16,false,true){filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Repeat};owned.Add(noise);
            noise.LoadRawTextureData(File.ReadAllBytes("Assets/AMD/BlueNoise.bytes"));noise.Apply();
            game=AssetBundle.LoadFromFile(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"EscapeFromTarkov_Data/StreamingAssets/Windows/shaders"));
            native=game.LoadAllAssets<Shader>().Single(s=>s.name=="Hidden/PostProcessing/ScreenSpaceReflections");
            gaussian=game.LoadAllAssets<ComputeShader>().First(c=>c.name.IndexOf("Gaussian",StringComparison.OrdinalIgnoreCase)>=0);
            var go=new GameObject("SSR contract fixture");owned.Add(go);camera=go.AddComponent<Camera>();camera.enabled=false;
            camera.renderingPath=RenderingPath.DeferredShading;camera.allowHDR=true;camera.nearClipPlane=.1f;camera.farClipPlane=500;camera.fieldOfView=65;
            rendererType=AccessTools.TypeByName("UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer");
            var bootstrapFactory=new PropertySheetFactory();var bootstrapContext=Context(bootstrapFactory);
            bootstrapContext.command.Dispose();bootstrapFactory.Release();
            Fixture();HistoryOwnershipContracts();HistoryPackingContracts();HistoryReadbackContracts();ContinuationOptimizationContracts();TraceOptimizationContracts();PerformanceContracts();CleanupSettings();CleanupParity();CleanupCoverageParity();CleanupCompletedSky();CleanupDepthFill();CleanupDiagnostics();NativeReconstructionContracts();GenericNormalContracts();
            AmbientCaptureContracts();NativeRemovalParity();ReceiverCutoffContracts();ZeroSmoothnessProbeContracts();ReceiverRangeContracts();ReceiverFallbackParity();SharedReflectionResponse();RecedingPlaneCoverage();ContinuousUpsamplingContracts();SignalContracts();HitNormalBypassContracts();TemporalContracts();TemporalStabilityContracts();CoverageTemporalContracts();CoverageDisplayContracts();ReplacementContracts();SkyContracts();BoundaryExitContracts();TodParity();Routing();JitterContracts();SkyRecoveryReplayContracts();Profile();
            Check(BuildPipeline.BuildAssetBundles("Output",new[]{new AssetBundleBuild {assetBundleName="stochasticssr",assetNames=new[]{"Assets/HiZ.compute","Assets/Support.shader","Assets/Reflection.shader","Assets/WaterCapture.shader","Assets/AMD/BlueNoise.bytes"}}},BuildAssetBundleOptions.ForceRebuildAssetBundle|BuildAssetBundleOptions.ChunkBasedCompression,BuildTarget.StandaloneWindows64)!=null,"release bundle build");
            Check(!ShaderUtil.GetShaderMessages(reflection).Any(m=>m.severity.ToString()=="Error"),"all executed reflection passes compile");
            Check(!ShaderUtil.GetComputeShaderMessages(compute).Any(m=>m.severity.ToString()=="Error"),"all trace diagnostic/raster variants compile");
            var release=AssetBundle.LoadFromFile(Path.GetFullPath("Output/stochasticssr"));try {Check(release.GetAllAssetNames().OrderBy(x=>x).SequenceEqual(new[]{"assets/amd/bluenoise.bytes","assets/hiz.compute","assets/reflection.shader","assets/support.shader","assets/watercapture.shader"}),"bundle contains only reflection-pipeline assets");}finally{release.Unload(false);}
            File.WriteAllLines("validation.txt",checks);
        } catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);throw;}
        finally {foreach(var o in owned)if(o!=null)UnityEngine.Object.DestroyImmediate(o);if(game!=null)game.Unload(true);}
    }
    private static void CaptureNative(CommandBuffer __0,RenderTargetIdentifier __2,int __4,bool __runOriginal)
    { if(__runOriginal && __4==0 && nativeRecords!=null)__0.CopyTexture(__2,nativeRecords); }
    private static void Save(RenderTexture rt,string name)
    {
        var t=new Texture2D(rt.width,rt.height,TextureFormat.RGBAFloat,false,true);t.SetPixels(Read(rt));t.Apply();
        File.WriteAllBytes("Frozen/"+name+".exr",t.EncodeToEXR(Texture2D.EXRFlags.OutputAsFloat));UnityEngine.Object.DestroyImmediate(t);
    }
    private static Texture2D Solid(Color c){var t=new Texture2D(1,1,TextureFormat.RGBAFloat,false,true);t.SetPixel(0,0,c);t.Apply();owned.Add(t);return t;}
    private static void SignalContracts()
    {
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            foreach(bool temporal in new[]{false,true})foreach(bool spatial in new[]{false}) {
                o.Temporal=temporal;
                cb.Blit(Solid(new Color(100,50,20,1)),p.TracePipeline.Radiance);
                cb.Blit(Texture2D.blackTexture,p.TracePipeline.Record);cb.Blit(Texture2D.blackTexture,p.TracePipeline.Hit);
                cb.Blit(scene,p.TracePipeline.NativeResult);
                p.Reconstruct(cb,camera,p.TracePipeline.NativeResult,camera.targetTexture,o);Execute(cb);
                var result=Read(camera.targetTexture);
                o.View=ReflectionView.EnvironmentRemovedScene;p.Reconstruct(cb,camera,p.TracePipeline.NativeResult,camera.targetTexture,o);Execute(cb);
                var baseline=Read(camera.targetTexture);
                o.View=ReflectionView.EnvironmentFallback;p.Reconstruct(cb,camera,p.TracePipeline.NativeResult,camera.targetTexture,o);Execute(cb);
                var fallback=Read(camera.targetTexture);
                Check(fallback.All(v=>v.r==0 && v.g==0 && v.b==0),"retired probe fallback is zero with filters "+temporal+"/"+spatial);
                o.View=ReflectionView.ReceiverColourFallback;p.Reconstruct(cb,camera,p.TracePipeline.NativeResult,camera.targetTexture,o);Execute(cb);var receiver=Read(camera.targetTexture);
                Check(receiver.Any(v=>v.r>0),"uncovered pixels have receiver-colour fallback with filters "+temporal+"/"+spatial);
                Check(result.Select((v,i)=>Math.Abs(v.r-baseline[i].r-receiver[i].r)).Max()<.003,"all misses add separate receiver fallback once with filters "+temporal+"/"+spatial);
                o.View=ReflectionView.Normal;
                Check(Read(p.Resolved).All(v=>v==Color.clear),"invalid bright RGB cannot enter reflection history "+temporal+"/"+spatial);
            }
            o=Options();o.Temporal=true;
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(p.UsedHistory,"stable frame uses confidence history");
            // Move camera abruptly and ensure history is invalidated before reconstruction.
            camera.transform.position=Vector3.right*3;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(!p.UsedHistory,"camera cut rejects history");camera.transform.position=Vector3.zero;
            p.History.Release();p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(p.History.IsCreated() && !p.UsedHistory,"lost history target recovers on temporal activation");
            foreach(ReflectionView view in Enum.GetValues(typeof(ReflectionView))) {
                o.View=view;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(Read(camera.targetTexture).All(v=>!float.IsNaN(v.r) && !float.IsInfinity(v.r)),"finite debug view "+view);
            }
        }
    }
    private static Texture2D Sized(Color[] pixels,int w,int h) {
        var t=new Texture2D(w,h,TextureFormat.RGBAFloat,false,true){filterMode=FilterMode.Point};t.SetPixels(pixels);t.Apply();owned.Add(t);return t;
    }
    private static void ReplacementContracts()
    {
        var cube=new Cubemap(1,TextureFormat.RGBAFloat,false);owned.Add(cube);
        foreach(CubemapFace face in Enum.GetValues(typeof(CubemapFace)))if((int)face>=0 && (int)face<6)cube.SetPixel(face,0,0,new Color(.2f,.3f,.4f,1));cube.Apply();
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            var records=Read(p.TracePipeline.Record);var guides=Read(p.TracePipeline.Hit);
            var raw=Solid(new Color(.7f,.8f,.9f,1));
            foreach(float ao in new[]{0f,.2f,.6f,1f})foreach(float stencil in new[]{0f,.7f})foreach(float actor in new[]{0f,1f}) {
                Globals(cb);cb.SetGlobalTexture("_MyGlobalReflectionProbe",cube);cb.SetGlobalTexture("_CameraGBufferTexture0",Texture(Enumerable.Repeat(new Color(0,0,0,ao),width*height).ToArray()));
                cb.SetGlobalTexture("_StencilShadow",Solid(new Color(0,0,0,stencil)));cb.SetGlobalTexture("_CameraMotionVectorsDepth",Solid(new Color(actor,0,0,0)));
                cb.Blit(raw,p.TracePipeline.Radiance);
                foreach(float coverage in new[]{0f,.25f,.5f,1f}) {
                    cb.Blit(Sized(guides.Select((v,j)=>new Color(records[j].a==1?coverage:0,v.g,v.b,v.a)).ToArray(),128,128),p.TracePipeline.Hit);
                    o.View=ReflectionView.Normal;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var output=Read(camera.targetTexture);
                    o.View=ReflectionView.Confidence;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var finalConfidence=Read(camera.targetTexture);
                    o.View=ReflectionView.ReceiverColourFallback;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var fallback=Read(camera.targetTexture);
                    float maxError=0;int tested=0;string worst="";
                    var ns=normals.GetPixels();var sp=specular.GetPixels();var ds=depths.GetPixels();var src=scene.GetPixels();
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
                        int i=y*width+x,j=Math.Min((int)((y+.5f)*128/height),127)*128+Math.Min((int)((x+.5f)*128/width),127);
                        if(records[j].a!=1 || sp[i].a<.5f)continue;
                        var pos=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false).inverse*new Vector4((x+.5f)/width*2-1,(y+.5f)/height*2-1,ds[i].r,1);
                        float accepted=finalConfidence[i].r;
                        // Independent CPU EFT environment weighting on the same receiver.
                        var n=new Vector3(ns[i].r*2-1,ns[i].g*2-1,ns[i].b*2-1).normalized;
                        var v=camera.ScreenPointToRay(new Vector3(x+.5f,y+.5f)).direction.normalized;
                        float f=Mathf.Pow(1-Mathf.Abs(Vector3.Dot(n,-v)),5),r=1-sp[i].a;
                        var fresnel=Color.LerpUnclamped(sp[i],Color.white*Mathf.Clamp01(Math.Max(sp[i].r,Math.Max(sp[i].g,sp[i].b))+sp[i].a),f);
                        float weight=1-.28f*Math.Max(r*r,.002f)*r;
                        float bottom=Mathf.Clamp01(Vector3.Reflect(v,n).y+1);
                        var removed=weight*fresnel*new Color(.2f,.3f,.4f,0)*bottom*ao*(1-stencil);
                        float q=sp[i].a*sp[i].a*sp[i].a,rr=1-q;
                        var addedFresnel=Color.LerpUnclamped(sp[i],Color.white*Mathf.Clamp01(Math.Max(sp[i].r,Math.Max(sp[i].g,sp[i].b))+q),f);
                        float addedWeight=1-.28f*Math.Max(rr*rr,.002f)*rr;
                        var expected=new Color(Math.Max(0,src[i].r-removed.r),Math.Max(0,src[i].g-removed.g),Math.Max(0,src[i].b-removed.b),src[i].a)+accepted*addedWeight*addedFresnel*new Color(.7f,.8f,.9f,0);
                        expected+=fallback[i];
                        float err=Math.Max(Math.Abs(expected.r-output[i].r),Math.Max(Math.Abs(expected.g-output[i].g),Math.Abs(expected.b-output[i].b)));if(err>maxError){maxError=err;worst=" at "+x+","+y+" expected "+expected+" got "+output[i]+" weight "+weight+" c "+accepted;}tested++;
                    }
                    Check(tested>100 && maxError<.004,"native removal plus geometry and uncovered receiver fallback, c="+coverage+" ao="+ao+" stencil="+stencil+" actor="+actor+" error="+maxError+worst);
                }
            }
            // Invalid samples contain intense colours, but cannot contaminate a valid neighbor.
            Globals(cb);o=Options();
            var injectedRaw=records.Select((v,j)=>j%2==0?new Color(.7f,.8f,.9f,1):new Color(100,50,20,1)).ToArray();
            cb.Blit(Sized(injectedRaw,128,128),p.TracePipeline.Radiance);
            cb.Blit(Sized(guides.Select((v,j)=>new Color(j%2==0?1:0,5,0,1)).ToArray(),128,128),p.TracePipeline.Hit);
            cb.Blit(Solid(new Color(0,0,-8,.9f)),p.TracePipeline.HitPoint);cb.Blit(Solid(new Color(.5f,.5f,0,1)),p.TracePipeline.Record);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
        }
    }
    private static void SkyContracts()
    {
        var oldDepth=depths;var oldSpec=specular;var oldNormals=normals;
        // Remove the wall: upper background is depth-clear, lower floor unchanged.
        var d=depths.GetPixels();var s=specular.GetPixels();
        for(int i=0;i<d.Length;i++)if(s[i].a<.5f)d[i]=new Color(SystemInfo.usesReversedZBuffer?0:1,0,0,0);
        depths=Texture(d);
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();
            o.Distance=250;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            var records=Read(p.TracePipeline.Record);
            Check(records.Any(v=>v.a==2),"completed in-frustum far-plane rays identify visible background");
            Check(records.Any(v=>v.a==2 && v.b>camera.farClipPlane+1),"runtime unlimited range accepts oblique sky beyond far-clip ray length");
            var unlimited=records;
            o.EdgePixels=0;
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(Error(records,Read(p.TracePipeline.Record))==0,"disabling edge fade preserves direct-sky and miss classification");
            Check(Read(p.TracePipeline.Hit).Where((v,j)=>records[j].a==2).All(v=>v.r==1),"zero edge fade keeps full direct-sky confidence to the viewport edge");
            o.EdgePixels=16;
            o.LimitNativeRange=true;o.Distance=250;
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            var limited=Read(p.TracePipeline.Record);
            Check(unlimited.Where((v,j)=>v.a==2).Count()==limited.Count(v=>v.a==2),"receiver eligibility limit preserves confirmed sky on near receivers");
            Check(limited.Any(v=>v.a==2 && v.b>camera.farClipPlane+1),"confirmed sky can extend beyond receiver distance limit");
            o.LimitNativeRange=false;o.Distance=250;
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(records.Any(v=>v.a==0),"offscreen or unresolved sky-scene rays remain unknown");
            cb.SetGlobalVector("TOD_kRadius",Vector4.zero);p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(p.Resolved).Where((v,j)=>records[j].a==2).All(v=>v==Color.clear),"missing TOD inputs add no reflection for background candidates");
            Globals(cb);TodGlobals(cb,.5f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(Read(p.Resolved).Where((v,j)=>records[j].a==2).Any(v=>v.a>0 && v.r>0),"proven background selects current TOD radiance with explicit confidence");
            Check(Read(p.Resolved).Where((v,j)=>records[j].a<=0).All(v=>v==Color.clear),"available TOD does not turn unknown or invalid rays into sky");
            o.LimitNativeRange=true;o.Distance=250;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(Read(p.TracePipeline.Record).Where((v,j)=>unlimited[j].a==2).All(v=>v.a==2),"eligible nearby receivers retain sky beyond 250m receiver limit");
            Check(Read(p.Resolved).Where((v,j)=>unlimited[j].a==2).Any(v=>v.a>0 && v.r>0),"eligible nearby receivers resolve TOD with receiver limit enabled");
            depths=oldDepth;o.LimitNativeRange=false;o.Distance=250;
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var wall=Read(p.TracePipeline.Record);
            o.LimitNativeRange=true;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(Error(wall,Read(p.TracePipeline.Record))==0,"nearby receivers preserve reflected wall records with receiver limit");
            depths=Texture(d);
            o.LimitNativeRange=false;o.Distance=250;o.Steps=1;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            Check(Read(p.TracePipeline.Record).All(v=>v.a!=2),"exhausted traversal is not sky");
            Check(Read(p.TracePipeline.Record).Any(v=>v.a==0 && v.b==8),"termination records identify iteration exhaustion");
        }
        depths=oldDepth;specular=oldSpec;normals=oldNormals;
    }
    private static void TodGlobals(CommandBuffer cb,float fogginess)
    {
        cb.SetGlobalVector("TOD_SunSkyColor",new Vector4(.7f,.8f,1,0));cb.SetGlobalVector("TOD_MoonSkyColor",new Vector4(.01f,.02f,.04f,0));
        cb.SetGlobalVector("TOD_GroundColor",new Vector4(.04f,.03f,.02f,0));cb.SetGlobalVector("TOD_MoonHaloColor",new Vector4(.01f,.02f,.03f,0));
        cb.SetGlobalVector("TOD_LocalSunDirection",new Vector4(0,.8f,.6f,0));cb.SetGlobalVector("TOD_LocalMoonDirection",new Vector4(0,-.8f,-.6f,0));
        cb.SetGlobalVector("TOD_kBetaMie",new Vector4(.1f,1.25f,-1,0));cb.SetGlobalVector("TOD_kSun",new Vector4(.1f,.2f,.3f,.01f));
        cb.SetGlobalVector("TOD_k4PI",new Vector4(.1f,.2f,.3f,.02f));cb.SetGlobalVector("TOD_kRadius",new Vector4(1,1,1.025f,1.025f*1.025f));
        cb.SetGlobalVector("TOD_kScale",new Vector4(40,.25f,160,.0001f));cb.SetGlobalFloat("TOD_Contrast",1.1f);
        cb.SetGlobalFloat("TOD_ScatteringBrightness",1.2f);cb.SetGlobalFloat("TOD_Fogginess",fogginess);cb.SetGlobalFloat("TOD_MoonHaloPower",8);
        cb.SetGlobalMatrix("TOD_World2Sky",Matrix4x4.identity);
    }
    private static void TodParity()
    {
        var factory=new PropertySheetFactory();var nativeSheet=factory.Get(native);var audit=factory.Get(AssetDatabase.LoadAssetAtPath<Shader>("Assets/TodAudit.shader"));
        var target=new RenderTexture(1,1,0,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear);target.Create();owned.Add(target);
        using(var cb=new CommandBuffer()) {
            foreach(float fog in new[]{.1f,.8f})foreach(float weather in new[]{0f,.8f})foreach(float y in new[]{-.2f,0f,.4f,.9f}) {
                var dir=new Vector3(.1f,y,1).normalized;const float distance=100;
                float density=-Mathf.Log(1-fog)/distance;
                var inv=Matrix4x4.zero;inv.SetColumn(3,new Vector4(dir.x*distance,dir.y*distance,dir.z*distance,1));
                nativeSheet.properties.SetMatrix("_InverseProjectionMatrix",inv);nativeSheet.properties.SetMatrix("_InverseViewMatrix",Matrix4x4.identity);
                TodGlobals(cb,weather);cb.SetGlobalVector("_Density",new Vector4(0,0,density,0));cb.SetGlobalVector("_WorldSpaceCameraPos",Vector4.zero);
                cb.SetGlobalTexture("_Test",Solid(new Color(.5f,.5f,0,1)));cb.SetGlobalTexture("_CameraDepthTexture",Solid(new Color(.5f,0,0,0)));cb.SetGlobalTexture("_StencilShadow",Texture2D.blackTexture);
                RuntimeUtilities.BlitFullscreenTriangle(cb,Texture2D.blackTexture,target,nativeSheet,1);Execute(cb);var expected=Read(target)[0];
                audit.properties.SetVector("_AuditDirection",dir);audit.properties.SetFloat("_AuditFog",fog);
                RuntimeUtilities.BlitFullscreenTriangle(cb,Texture2D.blackTexture,target,audit,0);Execute(cb);var actual=Read(target)[0]*(fog*.5f);
                Check(Math.Max(Math.Abs(actual.r-expected.r),Math.Max(Math.Abs(actual.g-expected.g),Math.Abs(actual.b-expected.b)))<.00002f,"TOD extracted scattering matches installed native resolve y="+y+" fog="+fog+" weather="+weather);
            }
        }
        factory.Release();
    }

    private static void TemporalContracts()
    {
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();o.Temporal=true;
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            var baseGuide=Read(p.TracePipeline.Hit);var basePoint=Read(p.TracePipeline.HitPoint);var baseRecord=Read(p.TracePipeline.Record);
            var baseMaterial=Read(p.HistoryMaterial);var basePlane=Read(p.HistoryPlane);
            foreach(string rejection in new[]{"depth","normal","smoothness","F0","classification","hit-disocclusion","motion-bounds"}) {
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                PrepareFrozenTrace(cb,p);
                cb.Blit(Solid(new Color(10,4,2,1)),p.History);
                var guide=baseGuide.ToArray();var points=basePoint.ToArray();var records=baseRecord.ToArray();var material=baseMaterial.ToArray();var plane=basePlane.ToArray();
                for(int j=0;j<guide.Length;j++) {
                    if(rejection=="depth")guide[j].g+=10;
                    if(rejection=="normal"){guide[j].b=0;guide[j].a=-1;}
                    if(rejection=="smoothness")points[j].a=0;
                    if(rejection=="F0")material[j].r=1;
                    if(rejection=="classification")plane[j].b=2;
                    if(rejection=="hit-disocclusion")points[j].b=-100;
                }
                cb.Blit(Sized(guide,128,128),p.HistoryGuide);cb.Blit(Sized(points,128,128),p.HistoryPoint);
                cb.Blit(Sized(plane,128,128),p.HistoryPlane);cb.Blit(Sized(material,128,128),p.HistoryMaterial);
                if(rejection=="motion-bounds")cb.SetGlobalTexture("_CameraMotionVectorsTexture",Texture(Enumerable.Repeat(new Color(2,2,0,0),width*height).ToArray()));
                p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                Check(Error(Read(p.Resolved),Read(p.Temporal))<.00001,"rejected history equals fresh confidence signal: "+rejection);
            }
        }
    }

    private static void ExportViews(ConfidenceSsrPipeline p,CommandBuffer cb,Options o,string key)
    {
        foreach(ReflectionView view in Enum.GetValues(typeof(ReflectionView))) {
            o.View=view;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);Save(camera.targetTexture,key+"-"+view);
        }
    }
    private static void Routing()
    {
        bool optic=false;var o=Options();o.Temporal=true;o.Resolution=ReflectionResolution.R256;
        using(var hooks=new SsrHooks(rendererType,compute,blend,reflection,noise){Settings=()=>o,IsMainCamera=c=>!optic && c==camera,Error=s=>{throw new Exception(s);}}) {
            SsrHooks.Active=hooks;var factory=new PropertySheetFactory();var renderer=CreateRenderer(out var effect);var context=Context(factory);var harmony=new Harmony("ssr.contract.routing");
            var blit=AccessTools.Method(typeof(RuntimeUtilities),"BlitFullscreenTriangle",new[]{typeof(CommandBuffer),typeof(RenderTargetIdentifier),typeof(RenderTargetIdentifier),typeof(PropertySheet),typeof(int),typeof(bool),typeof(Rect?)});
            harmony.Patch(blit,postfix:new HarmonyMethod(typeof(StochasticSsrValidation),nameof(Count)));
            harmony.Patch(AccessTools.Method(rendererType,"Render"),prefix:new HarmonyMethod(typeof(SsrHooks),nameof(SsrHooks.Before)),finalizer:new HarmonyMethod(typeof(SsrHooks),nameof(SsrHooks.After)));
            try {
                // Use matching render-texture formats/filtering for the alias
                // comparison, including when trace resolution exceeds camera size.
                var aliasSource=new RenderTexture(camera.targetTexture.descriptor);aliasSource.Create();owned.Add(aliasSource);
                context.source=aliasSource;
                passes=new int[4];Globals(context.command);context.command.Blit(scene,aliasSource);renderer.Render(context);ExecuteRaster(context.command,hooks);
                Check(passes.SequenceEqual(new[]{0,1,1,0}),"custom renderer uses only native forced-miss resolve/temporal passes, no native trace or composite");var custom=Read(camera.targetTexture);
                // Compare identical history/sample states: changing aliasing must
                // be the only difference, not a second temporal update.
                hooks.Suspend();context.source=camera.targetTexture;Globals(context.command);context.command.Blit(scene,camera.targetTexture);renderer.Render(context);ExecuteRaster(context.command,hooks);
                double aliasError=Error(custom,Read(camera.targetTexture));
                Check(aliasError<.002,"aliased source and destination preserve output (max error "+aliasError+")");context.source=scene;
                o.Mode=SsrMode.Native;passes=new int[4];Globals(context.command);renderer.Render(context);ExecuteRaster(context.command,hooks);
                Check(passes.SequenceEqual(new[]{1,1,1,1}),"disabled executes all native passes");var nativeOutput=Read(camera.targetTexture);
                AccessTools.Method(rendererType,"ResetHistory").Invoke(renderer,null);o.Mode=SsrMode.Stochastic;optic=true;passes=new int[4];Globals(context.command);renderer.Render(context);ExecuteRaster(context.command,hooks);
                Check(passes.SequenceEqual(new[]{1,1,1,1}) && Error(nativeOutput,Read(camera.targetTexture))<.002,"optics retain native renderer and output");
                optic=false;o.Temporal=false;o.Steps=32;
                foreach(var choice in new float?[]{null,.657f,0,null}) {
                    o.ReceiverCutoff=choice;Globals(context.command);
                    Check(!SsrHooks.Before(renderer,context,out var cutoffState) && cutoffState!=null,"receiver-cutoff comparison stays on custom hook: "+choice);
                    ExecuteRaster(context.command,hooks);
                    var effective=(Options)AccessTools.Field(typeof(ConfidenceSsrPipeline),"previous").GetValue(cutoffState.Pipeline);
                    float expected=choice??.5f;
                    Check(effective.Smoothness==expected && (!choice.HasValue?!effective.SupportSmoothness.HasValue:effective.SupportSmoothness==.5f),"actual hook inherits/restores native support while overriding receiver cutoff: "+choice);
                }
                foreach(ReflectionResolution resolution in Enum.GetValues(typeof(ReflectionResolution))) {
                    var old=o;o.Resolution=resolution;
                    if(old.Resolution!=resolution)Check(!o.SameRendering(old),"resolution change invalidates history: "+resolution);
                    foreach(int preset in new[]{0,7}) {
                        effect.preset.value=(ScreenSpaceReflectionPreset)preset;effect.resolution.value=(ScreenSpaceReflectionResolution)(preset==0?0:2);
                        Globals(context.command);
                        Check(!SsrHooks.Before(renderer,context,out var state) && state!=null,"custom resolution overrides native routing: "+resolution+" preset="+preset);
                        ExecuteRaster(context.command,hooks);
                        var pipeline=state.Pipeline;
                        Check(pipeline.TracePipeline.Radiance.width==(int)resolution && pipeline.Resolved.width==(int)resolution && pipeline.ReceiverFallback.Radiance.width==(int)resolution,"all reflection buffers use selected resolution: "+resolution+" preset="+preset);
                        Check(Read(camera.targetTexture).All(v=>!float.IsNaN(v.r) && !float.IsInfinity(v.r)),"finite composite at selected resolution: "+resolution);
                        if(preset==7 && (resolution==ReflectionResolution.R768 || resolution==ReflectionResolution.R1536)) {
                            Globals(context.command);pipeline.ReceiverFallback.Render(context.command,Solid(new Color(.3f,.4f,.5f,1)),0,false);ExecuteRaster(context.command,hooks);
                            var mips=(System.Collections.Generic.List<RenderTexture>)AccessTools.Field(typeof(NativeReceiverFallback),"mips").GetValue(pipeline.ReceiverFallback);
                            var tail=mips.Last();var values=ReadMip(pipeline.ReceiverFallback.Radiance,pipeline.ReceiverFallback.MipCount);
                            Check(tail.width==12 && values.All(v=>v.r>0 && v.g>0 && v.b>0),"non-power-of-two fallback fills the final partial compute tile: "+resolution);
                        }
                    }
                }
                o.Resolution=ReflectionResolution.R256;
                Globals(context.command);
                Check(!SsrHooks.Before(renderer,context,out var rectangular),"square allocation uses custom routing");ExecuteRaster(context.command,hooks);
                var fitted=o.TraceDimensions(context.width,context.height);
                Check(rectangular.Pipeline.Resolved.width==fitted.x && rectangular.Pipeline.Resolved.height==fitted.y,"hook preserves square trace dimensions");

                o.Resolution=ReflectionResolution.R256;o.Temporal=true;effect.preset.value=(ScreenSpaceReflectionPreset)7;hooks.Suspend();passes=new int[4];Globals(context.command);renderer.Render(context);ExecuteRaster(context.command,hooks);
                Check(passes.SequenceEqual(new[]{0,1,1,0}),"suspend and re-enable recreate custom and receiver fallback resources");
            } finally {harmony.UnpatchSelf();renderer.Release();context.command.Dispose();factory.Release();}
        }
    }
    private static PostProcessEffectRenderer CreateRenderer(out ScreenSpaceReflections effect)
    {
        var renderer=(PostProcessEffectRenderer)Activator.CreateInstance(rendererType);
        effect=ScriptableObject.CreateInstance<ScreenSpaceReflections>();owned.Add(effect);
        effect.preset.value=(ScreenSpaceReflectionPreset)7;effect.resolution.value=(ScreenSpaceReflectionResolution)1;
        effect.maximumIterationCount.value=128;effect.cutOffThreshold.value=.5f;
        AccessTools.Method(rendererType,"SetSettings").Invoke(renderer,new object[]{effect});return renderer;
    }
    private static void ExecuteRaster(CommandBuffer cb,SsrHooks hooks)
    {
        var pipelines=(System.Collections.Generic.Dictionary<Camera,ConfidenceSsrPipeline>)AccessTools.Field(typeof(SsrHooks),"cameras").GetValue(hooks);
        foreach(var pair in pipelines)pair.Value.TracePipeline.Raster.FinalizeRaster(pair.Key);
        Execute(cb);
        foreach(var pair in pipelines)pair.Value.TracePipeline.Raster.Commit();
    }
    private static PostProcessRenderContext Context(PropertySheetFactory factory)
    {
        var resources=ScriptableObject.CreateInstance<PostProcessResources>();owned.Add(resources);
        resources.shaders=new PostProcessResources.Shaders {screenSpaceReflections=native,copy=game.LoadAllAssets<Shader>().Single(s=>s.name=="Hidden/PostProcessing/Copy")};
        resources.computeShaders=new PostProcessResources.ComputeShaders {gaussianDownsample=gaussian};resources.blueNoise256=new[]{noise};
        AccessTools.Field(typeof(RuntimeUtilities),"s_Resources").SetValue(null,resources);
        var context=new PostProcessRenderContext {camera=camera,command=new CommandBuffer(),source=scene,destination=camera.targetTexture};
        AccessTools.Property(typeof(PostProcessRenderContext),"resources").SetValue(context,resources);
        AccessTools.Property(typeof(PostProcessRenderContext),"propertySheets").SetValue(context,factory);
        AccessTools.Property(typeof(PostProcessRenderContext),"sourceFormat").SetValue(context,RenderTextureFormat.ARGBHalf);return context;
    }
    private static void Count(int __4,bool __runOriginal) {if(__runOriginal && __4>=0 && __4<4)passes[__4]++;}
    private static Texture2D Texture(Color[] data) {var t=new Texture2D(width,height,TextureFormat.RGBAFloat,false,true){filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp};t.SetPixels(data);t.Apply();owned.Add(t);return t;}
    private static Color[] Read(RenderTexture t) {var r=AsyncGPUReadback.Request(t,0,TextureFormat.RGBAFloat);r.WaitForCompletion();if(r.hasError)throw new Exception("Readback failed");return r.GetData<Color>().ToArray();}
    private static double Error(Color[] a,Color[] b) => a.Select((v,i)=>Math.Max(Math.Max(Math.Abs(v.r-b[i].r),Math.Abs(v.g-b[i].g)),Math.Max(Math.Abs(v.b-b[i].b),Math.Abs(v.a-b[i].a)))).Max();
    private static void Fixture()
    {
        camera.aspect=(float)width/height;camera.targetTexture=new RenderTexture(width,height,0,RenderTextureFormat.ARGBHalf,RenderTextureReadWrite.Linear);camera.targetTexture.Create();owned.Add(camera.targetTexture);
        var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);var d=new Color[width*height];var n=new Color[d.Length];var s=new Color[d.Length];var colors=new Color[d.Length];
        for(int y=0;y<height;y++)for(int x=0;x<width;x++)
        {
            int i=y*width+x;var ray=camera.worldToCameraMatrix.MultiplyVector(camera.ScreenPointToRay(new Vector3(x+.5f,y+.5f,0)).direction).normalized;
            float wall=-8/ray.z,floor=ray.y<-.00001f?-1/ray.y:float.MaxValue;bool isFloor=floor<wall;var p=ray*(isFloor?floor:wall);
            var clip=projection*new Vector4(p.x,p.y,p.z,1);d[i]=new Color(clip.z/clip.w,0,0,0);
            var normal=camera.cameraToWorldMatrix.MultiplyVector(isFloor?Vector3.up:Vector3.forward);n[i]=new Color(normal.x*.5f+.5f,normal.y*.5f+.5f,normal.z*.5f+.5f,1);
            s[i]=new Color(.2f,.15f,.1f,isFloor?.98f:.4f);colors[i]=isFloor?new Color(.2f,.25f,.3f,.7f):(p.x<0?new Color(2,.2f,.1f,.7f):new Color(.1f,.4f,2,.7f));
        }
        depths=Texture(d);normals=Texture(n);specular=Texture(s);scene=Texture(colors);
    }
    private static void HitNormalBypassContracts()
    {
        var originalNormals=normals;
        try {
            var ns=normals.GetPixels();var sp=specular.GetPixels();
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();
                o.Steps=256;
                foreach(var sourceNormal in new[]{Vector3.up,Vector3.right}) {
                    normals=Texture(ns.Select((v,i)=>sp[i].a<.5f?new Color(sourceNormal.x*.5f+.5f,sourceNormal.y*.5f+.5f,sourceNormal.z*.5f+.5f,1):v).ToArray());
                    o.BypassHitNormal=false;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var before=Read(p.TracePipeline.Record);var beforeConfidence=Read(p.TracePipeline.Hit);
                    o.BypassHitNormal=true;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var after=Read(p.TracePipeline.Record);var afterConfidence=Read(p.TracePipeline.Hit);
                    var rejected=Enumerable.Range(0,before.Length).Where(j=>before[j].a==-1 && before[j].b==5).ToArray();
                    Check(rejected.Length>10 && rejected.All(j=>after[j].a==1),"bypass recovers bounded geometry rejected by source normal "+sourceNormal);
                    Check(before.Select((v,j)=>v.a==-1 && v.b==5 || v==after[j]).All(v=>v),"bypass preserves hit UVs and every other trace termination "+sourceNormal);
                    var accepted=Enumerable.Range(0,before.Length).Where(j=>before[j].a==1).ToArray();
                    Check(accepted.All(j=>afterConfidence[j].r>=beforeConfidence[j].r),"bypass never reduces accepted hit confidence "+sourceNormal);
                    if(sourceNormal==Vector3.right)Check(accepted.Any(j=>afterConfidence[j].r>beforeConfidence[j].r+.05f),"bypass removes grazing confidence reduction on accepted hits");
                    o.BypassHitNormal=false;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(Error(before,Read(p.TracePipeline.Record))==0 && Error(beforeConfidence,Read(p.TracePipeline.Hit))==0,"live bypass off restores previous trace exactly "+sourceNormal);
                }
                o.Temporal=true;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(p.UsedHistory,"bypass comparison has accumulated history");
                foreach(bool bypass in new[]{true,false}) {
                    o.BypassHitNormal=bypass;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(!p.UsedHistory,"live bypass change clears old reflection history: "+bypass);
                }
            }
        }finally{normals=originalNormals;}
    }
    private static void Globals(CommandBuffer cb)
    {
        cb.SetGlobalTexture("_CameraDepthTexture",depths);cb.SetGlobalTexture("_CameraGBufferTexture2",normals);cb.SetGlobalTexture("_CameraGBufferTexture1",specular);
        if(whiteGBuffer==null || whiteGBuffer.width!=width || whiteGBuffer.height!=height)whiteGBuffer=Texture(Enumerable.Repeat(Color.white,width*height).ToArray());
        cb.SetGlobalTexture("_CameraGBufferTexture0",materialOcclusion != null ? materialOcclusion : whiteGBuffer);cb.SetGlobalTexture("_StencilShadow",Texture2D.blackTexture);cb.SetGlobalTexture("_CameraMotionVectorsTexture",Texture2D.blackTexture);
        cb.SetGlobalFloat("_SSRFactor",1);cb.SetGlobalFloat("_ReflectionBottomShade",1);cb.SetGlobalVector("_WorldSpaceCameraPos",camera.transform.position);
        cb.SetGlobalVector("_ProjectionParams",new Vector4(1,camera.nearClipPlane,camera.farClipPlane,1/camera.farClipPlane));
        cb.SetGlobalVector("_ScreenParams",new Vector4(width,height,1+1f/width,1+1f/height));cb.SetGlobalVector("_Time",Vector4.zero);
        float f=camera.farClipPlane,n=camera.nearClipPlane;cb.SetGlobalVector("_ZBufferParams",SystemInfo.usesReversedZBuffer?new Vector4(f/n-1,1,(f/n-1)/f,1/f):new Vector4(1-f/n,f/n,(1-f/n)/f,1/n));
    }
}
