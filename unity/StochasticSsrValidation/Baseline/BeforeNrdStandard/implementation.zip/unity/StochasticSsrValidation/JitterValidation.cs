using System;
using System.Linq;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;

public static partial class StochasticSsrValidation
{
    private static void JitterContracts()
    {
        var go=new GameObject("late raster camera");owned.Add(go);var c=go.AddComponent<Camera>();c.enabled=false;
        c.nearClipPlane=.1f;c.farClipPlane=500;c.fieldOfView=65;c.renderingPath=RenderingPath.DeferredShading;c.allowHDR=true;
        c.transform.position=new Vector3(0,2,-5);
        const int w=768,h=432;
        RenderTexture Target(RenderTextureFormat format,int depth=0) {
            var rt=new RenderTexture(w,h,depth,format,RenderTextureReadWrite.Linear){filterMode=FilterMode.Point};rt.Create();owned.Add(rt);return rt;
        }
        var raw=Target(RenderTextureFormat.RFloat,24);var n=Target(RenderTextureFormat.ARGBFloat);var spec=Target(RenderTextureFormat.ARGBFloat);
        var output=Target(RenderTextureFormat.ARGBHalf);var source=Target(RenderTextureFormat.ARGBHalf);
        Graphics.Blit(scene,source);c.targetTexture=output;c.aspect=w/(float)h;
        var probe=new RenderTexture(1,1,0,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear);probe.Create();owned.Add(probe);
        var stable=c.projectionMatrix;
        var mat=new Material(Shader.Find("Hidden/FTFX/Test/JitterRaster"));owned.Add(mat);
        mat.SetInt("_DepthTest",(int)(SystemInfo.usesReversedZBuffer?CompareFunction.GreaterEqual:CompareFunction.LessEqual));
        var mesh=new Mesh();owned.Add(mesh);
        mesh.vertices=new[]{new Vector3(-100,0,5),new Vector3(100,0,5),new Vector3(100,0,150),new Vector3(-100,0,150),
            new Vector3(-100,0,80),new Vector3(100,0,80),new Vector3(100,30,80),new Vector3(-100,30,80)};
        mesh.normals=new[]{Vector3.up,Vector3.up,Vector3.up,Vector3.up,Vector3.back,Vector3.back,Vector3.back,Vector3.back};
        mesh.triangles=new[]{0,1,2,0,2,3,4,5,6,4,6,7};
        using(var raster=new SsrRasterState()) {
            raster.Enable(c);raster.Record(c,1,w,h);
            var jittered=stable;jittered.m02+=1f/w;jittered.m12-=.75f/h;
            c.nonJitteredProjectionMatrix=stable;c.projectionMatrix=jittered;c.Render();
            Check(raster.Current.Ready && raster.Current.Projection==GL.GetGPUProjectionMatrix(jittered,false),"onPreRender captures final raster matrix after early command recording");
            Check(raster.Current.Early!=raster.Current.Projection,"late raster snapshot distinguishes recorded and rendered projection");
            Check(!raster.Current.History,"first raster render cannot reuse uninitialized history");
            raster.Record(c,2,w,h);raster.FinalizeRaster(c);Check(!raster.Current.History,"AA mode switch invalidates raster history");
        }
        c.projectionMatrix=stable;c.nonJitteredProjectionMatrix=stable;
        double oldDifference=0;int cases=0;
        foreach(var resolution in new[]{ReflectionResolution.R512,ReflectionResolution.R1024}) {
            var o=Options();o.Resolution=resolution;o.Freeze=true;
            o.BypassHitNormal=true;o.Temporal=true;o.Steps=64;
            var d=o.TraceDimensions(w,h);
            using(var late=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))
            using(var reference=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))
            using(var old=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))
            using(var cb=new CommandBuffer())using(var draw=new CommandBuffer()) {
                late.Ensure(w,h,d.x,d.y,RenderTextureFormat.ARGBHalf);reference.Ensure(w,h,d.x,d.y,RenderTextureFormat.ARGBHalf);old.Ensure(w,h,d.x,d.y,RenderTextureFormat.ARGBHalf);
                for(int frame=0;frame<6;frame++) {
                    var rasterProjection=stable;
                    rasterProjection.m02+=new[]{-.75f,.25f,.75f,-.25f,.5f,-.5f}[frame]*2/w;
                    rasterProjection.m12+=new[]{.5f,-.75f,.25f,.75f,-.5f,-.25f}[frame]*2/h;
                    c.projectionMatrix=rasterProjection;c.nonJitteredProjectionMatrix=stable;
                    mat.SetMatrix("_RasterVP",GL.GetGPUProjectionMatrix(rasterProjection,true)*c.worldToCameraMatrix);
                    draw.SetViewProjectionMatrices(c.worldToCameraMatrix,rasterProjection);
                    draw.SetRenderTarget(new RenderTargetIdentifier[]{raw,n,spec},raw.depthBuffer);
                    draw.ClearRenderTarget(true,true,Color.clear,SystemInfo.usesReversedZBuffer?0:1);
                    draw.DrawMesh(mesh,Matrix4x4.identity,mat,0,0);Execute(draw);
                    if(frame==0){var rasterDepth=Read(raw);Debug.Log("Jitter depth nonzero="+rasterDepth.Count(v=>v.r>0)+" min="+rasterDepth.Min(v=>v.r)+" max="+rasterDepth.Max(v=>v.r));}
                    Action<CommandBuffer> inputs=commands=> {
                        Globals(commands);commands.SetGlobalTexture("_CameraGBufferTexture2",n);commands.SetGlobalTexture("_CameraGBufferTexture1",spec);
                        commands.SetGlobalTexture("_CameraMotionVectorsTexture",Texture2D.blackTexture);
                        commands.SetGlobalTexture("_CameraDepthTexture",raw);commands.SetGlobalTexture("_CameraGBufferTexture0",source);
                        commands.SetGlobalVector("_WorldSpaceCameraPos",c.transform.position);
                        commands.SetGlobalVector("_ProjectionParams",new Vector4(1,c.nearClipPlane,c.farClipPlane,1/c.farClipPlane));
                    };
                    c.projectionMatrix=stable;late.PrepareRaster(c,1,w,h);
                    inputs(cb);late.Render(cb,c,source,output,o,raw,n,spec);
                    c.projectionMatrix=rasterProjection;late.TracePipeline.Raster.FinalizeRaster(c);Execute(cb);late.TracePipeline.Raster.Commit();
                    reference.PrepareRaster(c,1,w,h);reference.TracePipeline.Raster.FinalizeRaster(c);
                    inputs(cb);reference.Render(cb,c,source,output,o,raw,n,spec);Execute(cb);reference.TracePipeline.Raster.Commit();
                    var a=Read(late.TracePipeline.Record);var b=Read(reference.TracePipeline.Record);
                    Check(Error(a,b)<.00001,"late-bound jitter trace equals correctly recorded reference: "+resolution+" frame="+frame);
                    Check(Error(Read(late.TracePipeline.HitPoint),Read(reference.TracePipeline.HitPoint))<.00001,"late-bound reflected hit positions align: "+resolution+" frame="+frame);
                    Check(Error(Read(late.TemporalStats),Read(reference.TemporalStats))<.0001,"late raster history matches reference: "+resolution+" frame="+frame);
                    var gpu=GL.GetGPUProjectionMatrix(rasterProjection,false);var baseGpu=GL.GetGPUProjectionMatrix(stable,false);
                    var point=new Vector4(.7f,-2,-30,1);var rc=gpu*point;var sc=baseGpu*point;
                    var actual=new Vector2(rc.x/rc.w-sc.x/sc.w,rc.y/rc.w-sc.y/sc.w)*.5f;
                    Check((actual-SsrRasterState.JitterUV(gpu,baseGpu)).magnitude<1e-6,"jitter compensation sign and UV orientation agree with GPU projection");
                    Vector2 UV(Matrix4x4 m,Vector4 p) {var clip=m*p;return new Vector2(clip.x/clip.w,clip.y/clip.w)*.5f+Vector2.one*.5f;}
                    var state=late.TracePipeline.Raster.Current;
                    foreach(bool moving in new[]{false,true}) {
                        var previousPoint=point;if(moving)previousPoint.x-=.3f;
                        var uv=UV(gpu,point);var motion=UV(baseGpu,point)-UV(baseGpu,previousPoint);
                        mat.SetBuffer("_SsrRasterState",late.TracePipeline.Raster.Buffer);mat.SetFloat("_SsrLateRaster",1);
                        mat.SetVector("_TestUV",new Vector4(uv.x,uv.y,motion.x,motion.y));
                        Graphics.Blit(Texture2D.blackTexture,probe,mat,1);
                        var result=Read(probe)[0];var expected=UV(state.PreviousProjection,previousPoint);
                        Check((new Vector2(result.r,result.g)-expected).magnitude<1e-6,"GPU history UV maps to previous raster for static/moving geometry: "+moving);
                    }
                    if(frame==0) {
                        c.projectionMatrix=stable;inputs(cb);old.Render(cb,c,source,output,o,raw,n,spec);Execute(cb);
                        oldDifference+=Error(Read(old.TracePipeline.HitPoint),Read(reference.TracePipeline.HitPoint));
                    }
                    cases++;
                }
                var stats=Read(late.TemporalStats);var records=Read(late.TracePipeline.Record);
                Debug.Log("Jitter fixture "+resolution+" measured="+records.Count(v=>v.a>0)+" accumulated="+stats.Count(v=>v.r>1.5f)+" reset="+late.LastResetReason);
                Check(stats.Any(v=>v.r>1.5f),"jittered static geometry accumulates history at "+resolution);
            }
        }
        Check(oldDifference>.0001,"regression reproduces pre-jitter projection error instead of a vacuous unchanged fixture");
        checks.Add("PASS: jittered raster regression covers "+cases+" frames at square R512/R1024 with a rectangular camera");
        using(var restore=new CommandBuffer()){Globals(restore);restore.SetViewProjectionMatrices(camera.worldToCameraMatrix,camera.projectionMatrix);Execute(restore);}
    }
}
