using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using HarmonyLib;

public static partial class StochasticSsrValidation
{
    private static RenderTexture CheckerTarget(int size) {
        var t=new RenderTexture(size,size,0,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear){enableRandomWrite=true,filterMode=FilterMode.Point};
        t.Create();return t;
    }
    private static Texture2D CheckerTexture(Color[] values,int w,int h) {
        var t=new Texture2D(w,h,TextureFormat.RGBAFloat,false,true);t.SetPixels(values);t.Apply();return t;
    }
    private static void CheckerExport(string path,Color[] values,int w,int h) {
        var t=CheckerTexture(values,w,h);
        File.WriteAllBytes(path+".exr",t.EncodeToEXR(Texture2D.EXRFlags.OutputAsFloat|Texture2D.EXRFlags.CompressZIP));UnityEngine.Object.DestroyImmediate(t);
    }
    private static Options CheckerOptions() {
        var o=Options();o.Freeze=true;o.Temporal=false;o.WaterNormals=true;o.WaterTraceStrength=.85f;
        o.NormalStartDistance=10;o.NormalEndDistance=100;o.NormalRadius=4;o.BypassHitNormal=true;o.UseCapturedContribution=true;
        o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;
        o.ThicknessConfidenceFloor=1;o.FallbackStrength=.600939f;o.SurfaceColourInfluence=.1971831f;return o;
    }
    private static void CheckerCompose(CommandBuffer cb,ConfidenceSsrPipeline p,RenderTexture measured,RenderTexture filled,RenderTexture guide,RenderTexture point) {
        var properties=(MaterialPropertyBlock)AccessTools.Field(typeof(ConfidenceSsrPipeline),"properties").GetValue(p);
        properties.SetTexture("_Signal",filled);properties.SetTexture("_UnfilledSignal",measured);
        // Composition receives current-input receiver guides only. It cannot
        // consult withheld hit confidence, positions or classifications.
        properties.SetTexture("_Guide",guide);properties.SetTexture("_Point",point);
        foreach(string unused in new[]{"_Raw","_Record","_TraceInfo","_TraceStop","_DepthHit"})properties.SetTexture(unused,Texture2D.blackTexture);
        AccessTools.Method(typeof(ConfidenceSsrPipeline),"Draw").Invoke(p,new object[]{cb,new RenderTargetIdentifier(scene),new RenderTargetIdentifier(camera.targetTexture),ConfidenceSsrPipeline.Pass.ComposeNormal});
    }
    private static void CheckerEvaluate(string dataset,ConfidenceSsrPipeline p,Texture2D water,Options o,int size) {
        var shader=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/CheckerboardReconstruction.compute"));
        Check(shader!=null && !ShaderUtil.GetComputeShaderMessages(shader).Any(v=>v.severity.ToString()=="Error"),"checkerboard reconstruction compiles");
        var targets=Enumerable.Range(0,8).Select(i=>CheckerTarget(size)).ToArray();
        var mm=targets[0];var mf=targets[1];var mk=targets[2];var guide=targets[3];var point=targets[4];var em=targets[5];var ef=targets[6];var provenance=targets[7];
        string folder=Path.Combine("ReducedRateOutput",dataset);Directory.CreateDirectory(folder);
        using(var cb=new CommandBuffer())try {
            Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
            var refMeasured=Read(p.Resolved);var refFilled=Read(p.DepthGapFilled);var refRecord=Read(p.TracePipeline.Record);var refCost=Read(p.TracePipeline.TraceInfo);
            CheckerExport(Path.Combine(folder,"reference-measured"),refMeasured,size,size);CheckerExport(Path.Combine(folder,"reference-filled"),refFilled,size,size);
            CheckerExport(Path.Combine(folder,"reference-record"),refRecord,size,size);CheckerExport(Path.Combine(folder,"reference-continuation"),refCost,size,size);
            CheckerExport(Path.Combine(folder,"reference-composed"),Read(camera.targetTexture),width,height);
            int mask=shader.FindKernel("Mask"),reconstruct=shader.FindKernel("Reconstruct");
            cb.SetComputeVectorParam(shader,"_Size",new Vector4(width,height,size,size));cb.SetComputeMatrixParam(shader,"_InverseProjection",GL.GetGPUProjectionMatrix(camera.projectionMatrix,false).inverse);
            cb.SetComputeVectorParam(shader,"_Eligibility",new Vector4(camera.nearClipPlane,camera.farClipPlane,o.Smoothness,0));
            cb.SetComputeIntParam(shader,"_WaterAvailable",water!=null?1:0);
            foreach(int kernel in new[]{mask,reconstruct}) {
                cb.SetComputeTextureParam(shader,kernel,"_Depth",p.TracePipeline.Depth[0]);cb.SetComputeTextureParam(shader,kernel,"_Normals",normals);cb.SetComputeTextureParam(shader,kernel,"_Specular",specular);
            }
            cb.SetComputeTextureParam(shader,reconstruct,"_Water",water!=null?water:Texture2D.blackTexture);
            foreach(var pair in new[]{Tuple.Create("_MaskedMeasured",mm),Tuple.Create("_MaskedFilled",mf),Tuple.Create("_MaskedKind",mk),Tuple.Create("_ReceiverGuide",guide),Tuple.Create("_ReceiverPoint",point)})cb.SetComputeTextureParam(shader,mask,pair.Item1,pair.Item2);
            foreach(var pair in new[]{Tuple.Create("_RetainedMeasured",mm),Tuple.Create("_RetainedFilled",mf),Tuple.Create("_RetainedKind",mk),Tuple.Create("_EstimatedMeasured",em),Tuple.Create("_EstimatedFilled",ef),Tuple.Create("_Provenance",provenance)})cb.SetComputeTextureParam(shader,reconstruct,pair.Item1,pair.Item2);
            for(int phase=0;phase<2;phase++) {
                cb.SetComputeIntParam(shader,"_Phase",phase);
                cb.SetComputeTextureParam(shader,mask,"_ReferenceMeasured",p.Resolved);cb.SetComputeTextureParam(shader,mask,"_ReferenceFilled",p.DepthGapFilled);cb.SetComputeTextureParam(shader,mask,"_ReferenceRecord",p.TracePipeline.Record);
                cb.DispatchCompute(shader,mask,(size+7)/8,(size+7)/8,1);cb.DispatchCompute(shader,reconstruct,(size+7)/8,(size+7)/8,1);Execute(cb);
                if(phase==0) {
                    Globals(cb);TodGlobals(cb,.2f);CheckerCompose(cb,p,p.Resolved,p.DepthGapFilled,guide,point);Execute(cb);
                    var withInputGuides=Read(camera.targetTexture);
                    // Reference was exported before changing the property block;
                    // compare an ordinary recompose with the same current guides.
                    p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                    Check(EquivalentComposition(withInputGuides,Read(camera.targetTexture)),"current-input-only guides preserve full-rate composition: "+dataset);
                }
                var measured=Read(em);var filled=Read(ef);var types=Read(provenance);
                Check(Enumerable.Range(0,measured.Length).Where(i=>((i%size+i/size+phase)&1)==0).All(i=>measured[i]==refMeasured[i] && filled[i]==refFilled[i] && types[i].r==1),"retained trace signals are exactly unchanged: "+dataset+" phase "+phase);
                Check(measured.All(c=>Enumerable.Range(0,4).All(k=>!float.IsNaN(c[k]) && !float.IsInfinity(c[k])) && c.a>=0 && c.a<=1.00001f),"estimated premultiplied signals have finite coverage: "+dataset+" phase "+phase);
                Check(types.Where((c,i)=>((i%size+i/size+phase)&1)!=0).All(c=>c.r==0 || (c.r==2 && c.g==0)),"withheld provenance never fabricates hit class or continuation: "+dataset+" phase "+phase);
                CheckerExport(Path.Combine(folder,"phase-"+phase+"-measured"),measured,size,size);CheckerExport(Path.Combine(folder,"phase-"+phase+"-filled"),filled,size,size);CheckerExport(Path.Combine(folder,"phase-"+phase+"-provenance"),types,size,size);
                Globals(cb);TodGlobals(cb,.2f);CheckerCompose(cb,p,em,ef,guide,point);Execute(cb);CheckerExport(Path.Combine(folder,"phase-"+phase+"-composed"),Read(camera.targetTexture),width,height);
                // Adversarially corrupt every withheld signal and class. The
                // exact result must survive; hit/continuation buffers aren't
                // even part of either reconstruction kernel's input contract.
                var poisonM=CheckerTexture(refMeasured.Select((v,i)=>((i%size+i/size+phase)&1)==0?v:new Color(8192,-2048,4096,.9375f)).ToArray(),size,size);
                var poisonF=CheckerTexture(refFilled.Select((v,i)=>((i%size+i/size+phase)&1)==0?v:new Color(-1024,16384,256,.0625f)).ToArray(),size,size);
                var poisonR=CheckerTexture(refRecord.Select((v,i)=>((i%size+i/size+phase)&1)==0?v:new Color(777,888,999,2)).ToArray(),size,size);
                cb.SetComputeTextureParam(shader,mask,"_ReferenceMeasured",poisonM);cb.SetComputeTextureParam(shader,mask,"_ReferenceFilled",poisonF);cb.SetComputeTextureParam(shader,mask,"_ReferenceRecord",poisonR);
                cb.DispatchCompute(shader,mask,(size+7)/8,(size+7)/8,1);cb.DispatchCompute(shader,reconstruct,(size+7)/8,(size+7)/8,1);Execute(cb);
                Check(Error(measured,Read(em))==0 && Error(filled,Read(ef))==0 && Error(types,Read(provenance))==0,"poisoned withheld RGB/coverage/class cannot leak: "+dataset+" phase "+phase);
                foreach(var t in new[]{poisonM,poisonF,poisonR})UnityEngine.Object.DestroyImmediate(t);
            }
            CheckerExport(Path.Combine(folder,"receiver-guide"),Read(guide),size,size);CheckerExport(Path.Combine(folder,"receiver-point"),Read(point),size,size);
            var receiverWater=new Color[size*size];var waterPixels=water!=null?water.GetPixels():null;var eye=Read(p.TracePipeline.Depth[0]);
            for(int y=0;y<size;y++)for(int x=0;x<size;x++) {
                int cx=Math.Min((int)((x+.5)*width/size),width-1),cy=Math.Min((int)((y+.5)*height/size),height-1),i=cy*width+cx;
                float z=eye[i].r;float wz=waterPixels!=null?waterPixels[i].r:0;
                receiverWater[y*size+x]=new Color(wz>0 && Mathf.Abs(z-wz)<=Mathf.Max(.005f,z*.0001f)?1:0,0,0,1);
            }
            CheckerExport(Path.Combine(folder,"receiver-water"),receiverWater,size,size);
            File.WriteAllText(Path.Combine(folder,"settings.txt"),"Current-frame only; full-rate withholding is NOT a performance test.\nTrace="+size+" square\nCamera="+width+"x"+height+"\nPhase=checkerboard original coordinates, independent of ray sampling\nTemporal=False\nSteps=515\nContinuation=557 samples / 500 camera pixels / 50 metres\nNormal=85%,10-100m,4 camera pixels\nFallbackDirectFinalMip=True\nNo withheld ray metadata bound to reconstruction or composition\n");
        } finally {foreach(var t in targets){t.Release();UnityEngine.Object.DestroyImmediate(t);}UnityEngine.Object.DestroyImmediate(shader);}
    }
    static partial void RunReducedRateFeasibility() {
        perStage=false;completionOutput=null;
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        var world=camera.worldToCameraMatrix;float near=camera.nearClipPlane,far=camera.farClipPlane,fov=camera.fieldOfView;
        try {
            foreach(string dataset in new[]{"floor-wall","captured-water","captured-ground"}) {
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world;Fixture();
                Texture2D mask=dataset=="floor-wall"?null:SetupCapturedReplay(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",dataset=="captured-water"?"20261001-102353-500":"20261001-102702-951"));
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    Check(AmbientReflectionCapture.Begin(cb,camera,true),"checkerboard captured subtraction available");cb.ClearRandomWriteTargets();cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    p.ReceiverFallback.DirectFinalMip=true;p.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);
                    CheckerEvaluate(dataset,p,mask,CheckerOptions(),1024);
                    // Same inputs, original sample phase, traversal allowances,
                    // fallback and material response. Quality comparison only.
                    p.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);
                    Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,CheckerOptions(),depths,normals,specular);Execute(cb);
                    CheckerExport(Path.Combine("ReducedRateOutput",dataset,"r768-filled"),Read(p.DepthGapFilled),768,768);
                    CheckerExport(Path.Combine("ReducedRateOutput",dataset,"r768-composed"),Read(camera.targetTexture),width,height);
                }
                AmbientReflectionCapture.Dispose();GC.Collect();
            }
            CheckerAnimatedFeasibility();
        } finally {AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world;Fixture();}
    }
    private static void CheckerAnimatedFeasibility() {
        int ow=width,oh=height;var world=camera.worldToCameraMatrix;var projection=camera.projectionMatrix;
        try {
            width=321;height=185;camera.nearClipPlane=.1f;camera.farClipPlane=500;camera.fieldOfView=65;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=Matrix4x4.identity;Fixture();
            var originalDepth=depths.GetPixels();var originalNormal=normals.GetPixels();var originalSpecular=specular.GetPixels();var originalColour=scene.GetPixels();
            var gpu=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
            using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                p.ReceiverFallback.DirectFinalMip=true;p.Ensure(width,height,256,RenderTextureFormat.ARGBHalf);
                for(int frame=0;frame<8;frame++) {
                    var d=(Color[])originalDepth.Clone();var n=(Color[])originalNormal.Clone();var s=(Color[])originalSpecular.Clone();var c=(Color[])originalColour.Clone();var wm=new Color[d.Length];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
                        int i=y*width+x;bool floor=n[i].g>.95f;
                        bool weapon=x>width/3+frame*5 && x<width/2+frame*5 && y>height/6 && y<height*2/3;
                        bool foliage=x>width*2/3 && y>height/5 && y<height*3/4 && ((x+frame*2)%11)<3;
                        if(weapon || foliage) {
                            float z=weapon?2:4;var clip=gpu*new Vector4(0,0,-z,1);d[i]=new Color(clip.z/clip.w,0,0,0);n[i]=new Color(.5f,.5f,1,1);
                            s[i]=new Color(.04f,.06f,.08f,weapon?.3f:.4f);c[i]=weapon?new Color(.15f,.2f,.3f,1):new Color(.1f,.6f,.1f,1);
                        } else if(floor) {
                            var normal=new Vector3(Mathf.Sin(x*.7f+frame)*.07f,1,Mathf.Cos(y*.6f+frame)*.07f).normalized;
                            n[i]=new Color(normal.x*.5f+.5f,normal.y*.5f+.5f,normal.z*.5f+.5f,1);s[i].a=1;
                            float z=gpu.m23/(d[i].r+gpu.m22);if(x<width*3/5)wm[i]=new Color(z,1,0,0);
                        }
                    }
                    depths=Texture(d);normals=Texture(n);specular=Texture(s);scene=Texture(c);var mask=Texture(wm);
                    Check(AmbientReflectionCapture.Begin(cb,camera,true),"animated checkerboard subtraction available");cb.ClearRandomWriteTargets();cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));cb.Blit(mask,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);
                    CheckerEvaluate("animated-frame-"+frame,p,mask,CheckerOptions(),256);p.TracePipeline.Raster.Commit();
                }
            }
        } finally {AmbientReflectionCapture.Dispose();camera.worldToCameraMatrix=world;camera.projectionMatrix=projection;width=ow;height=oh;Fixture();}
    }
}

