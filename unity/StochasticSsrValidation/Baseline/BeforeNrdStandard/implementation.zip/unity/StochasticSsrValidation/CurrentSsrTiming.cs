using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using CustomAmbientResearch;

public static partial class StochasticSsrValidation
{
    private static void CutoffExport(string path,Color[] pixels,int w,int h) {
        var t=new Texture2D(w,h,TextureFormat.RGBAFloat,false,true);t.SetPixels(pixels);t.Apply();
        File.WriteAllBytes(path+".exr",t.EncodeToEXR(Texture2D.EXRFlags.OutputAsFloat|Texture2D.EXRFlags.CompressZIP));UnityEngine.Object.DestroyImmediate(t);
    }
    private static Options CutoffOptions(float cutoff) {
        var o=Options();o.Smoothness=cutoff;o.SupportSmoothness=0;o.Distance=0;o.LimitNativeRange=false;o.Freeze=true;o.Temporal=false;
        o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalStartDistance=10;o.NormalEndDistance=100;o.NormalRadius=4;
        o.BypassHitNormal=true;o.UseCapturedContribution=true;o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
        o.Thickness=1;o.ThicknessConfidenceFloor=1;o.FallbackStrength=.600939f;o.SurfaceColourInfluence=.1971831f;return o;
    }
    private static void ProfileSmoothnessSweep() {
        float[] cutoffs={0,.1f,.25f,.5f,.65f,.75f};
        var rows=new List<string>{"dataset,cutoff,region,trial,sample,gpu_ms"};
        var workRows=new List<string>{"dataset,cutoff,eligible,iterations,after_first_continuation,mip0_visits,retained_geometry_rough_sources"};
        var world=camera.worldToCameraMatrix;float near=camera.nearClipPlane,far=camera.farClipPlane,fov=camera.fieldOfView;
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        ulong probes=timer.CompletionProbes,failures=timer.CompletionFailures;
        perStage=false;completionOutput=null;
        try {
            foreach(string dataset in new[]{"floor-wall","captured-water","captured-ground"}) {
                camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world;Fixture();
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                Texture2D mask=null;
                if(dataset!="floor-wall")mask=SetupCapturedReplay(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",dataset=="captured-water"?"20261001-102353-500":"20261001-102702-951"));
                string output="CutoffOutput/"+dataset;Directory.CreateDirectory(output);
                var sp=specular.GetPixels();var source=scene.GetPixels();
                CutoffExport(output+"/scene",source,width,height);CutoffExport(output+"/specular",sp,width,height);
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    Check(AmbientReflectionCapture.Begin(cb,camera,true),"cutoff sweep captured subtraction "+dataset);cb.ClearRandomWriteTargets();
                    cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));
                    cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    p.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);
                    CutoffExport(output+"/water",mask!=null?mask.GetPixels():Enumerable.Repeat(Color.clear,width*height).ToArray(),width,height);
                    Color[] removedScene=null;
                    Color[] baselineRaw=null,baselineRecord=null,baselineCost=null,baselineNormal=null,baselineFallback=null;
                    var receiverSmoothness=Enumerable.Range(0,1024*1024).Select(j=>sp[Math.Min((int)((j/1024+.5f)*height/1024),height-1)*width+Math.Min((int)((j%1024+.5f)*width/1024),width-1)].a).ToArray();
                    foreach(float cutoff in cutoffs) {
                        var o=CutoffOptions(cutoff);Globals(cb);TodGlobals(cb,.2f);
                        p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                        var work=Read(p.TracePipeline.Sample);var topology=Read(p.TracePipeline.DepthHit);var records=Read(p.TracePipeline.Record);var cost=Read(p.TracePipeline.TraceInfo);var raw=Read(p.TracePipeline.Radiance);
                        int roughSources=Enumerable.Range(0,records.Length).Count(j=>records[j].a==1 && sp[(int)records[j].g*width+(int)records[j].r].a<cutoff);
                        workRows.Add(dataset+","+cutoff.ToString("R",CultureInfo.InvariantCulture)+","+work.Sum(v=>(long)v.a)+","+work.Sum(v=>(long)v.r)+","+work.Sum(v=>(long)v.g)+","+topology.Sum(v=>(long)v.r)+","+roughSources);
                        Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                        Check(p.TracePipeline.Sample==null && p.TracePipeline.DepthHit==null,"cutoff ordinary render releases optional diagnostics "+dataset+"/"+cutoff);
                        var image=Read(camera.targetTexture);var normal=Read(p.TracePipeline.WaterNormal);var fallback=Read(p.ReceiverFallback.Radiance);
                        if(cutoff==0) {
                            baselineRaw=raw;baselineRecord=records;baselineCost=cost;baselineNormal=normal;baselineFallback=fallback;
                            CutoffExport(output+"/record",records,1024,1024);CutoffExport(output+"/continuation",cost,1024,1024);CutoffExport(output+"/guide",Read(p.TracePipeline.Hit),1024,1024);
                            CutoffExport(output+"/depth",Read(p.TracePipeline.Depth[0]),width,height);
                            var environmentView=o;environmentView.View=ReflectionView.EnvironmentRemovedScene;Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,environmentView,depths,normals,specular);Execute(cb);removedScene=Read(camera.targetTexture);
                            // Explicitly verify Native and opt-in zero use identical rendering.
                            var ordinary=o;ordinary.SupportSmoothness=null;Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,ordinary,depths,normals,specular);Execute(cb);
                            Check(Error(image,Read(camera.targetTexture))==0,"opt-in zero matches ordinary native-zero rendering "+dataset);
                        } else {
                            Check(Enumerable.Range(0,raw.Length).All(j=>receiverSmoothness[j]<cutoff || (raw[j].Equals(baselineRaw[j]) && records[j].Equals(baselineRecord[j]) && cost[j].Equals(baselineCost[j]))),"cutoff retains independent rays, source hits and continuation exactly "+dataset+"/"+cutoff);
                            Check(Error(normal,baselineNormal)==0 && Error(fallback,baselineFallback)==0,"cutoff leaves normal donors and native fallback unchanged "+dataset+"/"+cutoff);
                            Check(image.Select((v,j)=>sp[j].a>=cutoff || Math.Max(Math.Abs(v.r-removedScene[j].r),Math.Max(Math.Abs(v.g-removedScene[j].g),Math.Abs(v.b-removedScene[j].b)))<.003*(1+Math.Max(source[j].r,Math.Max(source[j].g,source[j].b)))).All(v=>v),"excluded receivers match environment-removed source scene "+dataset+"/"+cutoff);
                            if(dataset=="floor-wall" && cutoff>=.5f)Check(roughSources>100,"smooth receivers still reflect rough wall sources "+cutoff);
                        }
                        CutoffExport(output+"/cutoff-"+cutoff.ToString("F2",CultureInfo.InvariantCulture),image,width,height);
                    }
                    File.WriteAllLines("cutoff-work.csv",workRows);
                    foreach(string region in new[]{"outer-SSR","depth-normal-trace-sky"})for(int trial=0;trial<3;trial++) {
                        for(int warm=0;warm<32;warm++)foreach(float cutoff in cutoffs){Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,CutoffOptions(cutoff),depths,normals,specular);}
                        Execute(cb);GpuBarrier();
                        for(int first=0;first<24;first+=4) {
                            for(int sample=first;sample<first+4;sample++)foreach(int i in (sample+trial)%2==0?Enumerable.Range(0,6):Enumerable.Range(0,6).Reverse()) {
                                var o=CutoffOptions(cutoffs[i]);Globals(cb);TodGlobals(cb,.2f);
                                var ticket=timer.Reserve(trial*1000+sample,i+1,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"cutoff timestamp reservation");timer.Event(cb,1,ticket);
                                if(region=="outer-SSR")p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                                else {timer.DeepMark(cb,400);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular);timer.DeepMark(cb,400,true,true,p.TracePipeline.Radiance);}
                                timer.Event(cb,2,ticket);
                            }
                            Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                            var buffer=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;while((count=timer.Read(buffer))>0)results.AddRange(buffer.Take(count));
                            Check(results.Count(r=>r.Stage==0)==24 && results.All(r=>r.Flags==0) && timer.Pending==0,"cutoff queries complete without missing/disjoint observations");
                            foreach(var r in results.Where(r=>r.Stage==(region=="outer-SSR"?0:400)))rows.Add(dataset+","+cutoffs[r.Window-1].ToString("R",CultureInfo.InvariantCulture)+","+region+","+trial+","+(r.Frame%1000)+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                            File.WriteAllLines("cutoff-gpu.csv",rows);
                        }
                    }
                }
                AmbientReflectionCapture.Dispose();
            }
            Check(timer.CompletionProbes>probes && timer.CompletionFailures==failures && timer.Dropped==0 && timer.Pending==0,"cutoff sweep no failed completion probes or dropped/pending queries");
            File.WriteAllText("cutoff-method.txt",SystemInfo.graphicsDeviceName+"; DX11; R1024 square, camera 2560x1440, six minimum receiver smoothness cutoffs 0/.1/.25/.5/.65/.75. Support/native cutoff fixed at zero for normal preparation and receiver fallback. Sample phase 0, temporal off, all other options fixed to current timing baseline. Three trials per dataset/region; 32 six-cutoff warmup cycles and 24 alternating observations per cutoff; discard first four samples/trial. Total SSR has no internal completion probes. Separate combined-front region has one probe. Diagnostics, export and readbacks are outside timing. Fixture TOD/constant captured subtraction are preliminary, not live raid acceptance. Completion probes="+(timer.CompletionProbes-probes)+"; failures="+(timer.CompletionFailures-failures)+".\n");
        } finally {perStage=false;completionOutput=null;AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world;Fixture();}
    }
    private static void ProfileReceiverRangeWork()
    {
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        var world=camera.worldToCameraMatrix;float near=camera.nearClipPlane,far=camera.farClipPlane,fov=camera.fieldOfView;
        var rows=new List<string>{"dataset,receiver_range_m,eligible,iterations,post_continuation,mip0_visits,excluded_far_receivers,near_receiver_distant_source_hits,geometry,sky"};
        try {
            foreach(string dataset in new[]{"floor-wall","captured-water","captured-ground"}) {
                camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world;Fixture();
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                Texture2D mask=null;
                if(dataset!="floor-wall")mask=SetupCapturedReplay(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",dataset=="captured-water"?"20261001-102353-500":"20261001-102702-951"));
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    p.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);
                    Color[] baseline=null,baselineRaw=null,baselineCost=null,baselineWork=null,baselineNormal=null;Vector3[] positions=null;
                    int Receiver(int j)=>Math.Min((int)((j/1024+.5f)*height/1024),height-1)*width+Math.Min((int)((j%1024+.5f)*width/1024),width-1);
                    foreach(float range in new[]{0f,25f,50f,100f,250f,500f}) {
                        var o=CutoffOptions(.5f);o.Distance=range;o.LimitNativeRange=range>0;
                        Globals(cb);TodGlobals(cb,.2f);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                        var records=Read(p.TracePipeline.Record);var work=Read(p.TracePipeline.Sample);var topology=Read(p.TracePipeline.DepthHit);var raw=Read(p.TracePipeline.Radiance);var cost=Read(p.TracePipeline.TraceInfo);var hits=Read(p.TracePipeline.HitPoint);var normal=Read(p.TracePipeline.WaterNormal);
                        if(range==0) {
                            baseline=records;baselineRaw=raw;baselineCost=cost;baselineWork=work;baselineNormal=normal;
                            var eye=Read(p.TracePipeline.Depth[0]);var inverse=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false).inverse;
                            positions=Enumerable.Range(0,width*height).Select(j=>ReceiverPosition(j,eye[j].r,inverse)).ToArray();
                        } else {
                            Check(Enumerable.Range(0,records.Length).Where(j=>positions[Receiver(j)].magnitude<range-.01f).All(j=>records[j].Equals(baseline[j]) && raw[j].Equals(baselineRaw[j]) && cost[j].Equals(baselineCost[j]) && work[j].Equals(baselineWork[j]) && normal[j].Equals(baselineNormal[j])),"captured receiver-range retains selected rays/donors/classification exactly "+dataset+"/"+range);
                            Check(work.Select((v,j)=>positions[Receiver(j)].magnitude<=range+.01f || (v.r==0 && v.g==0 && v.b==0 && v.a==0 && records[j].a==0)).All(v=>v),"captured far receivers execute no GGX/traversal work "+dataset+"/"+range);
                        }
                        int excluded=range>0?Enumerable.Range(0,work.Length).Count(j=>baselineWork[j].a>0 && positions[Receiver(j)].magnitude>range+.01f):0;
                        int farHits=range>0?Enumerable.Range(0,records.Length).Count(j=>records[j].a==1 && new Vector3(hits[j].r,hits[j].g,hits[j].b).magnitude>range):0;
                        rows.Add(dataset+","+range+","+work.Sum(v=>(long)v.a)+","+work.Sum(v=>(long)v.r)+","+work.Sum(v=>(long)v.g)+","+topology.Sum(v=>(long)v.r)+","+excluded+","+farHits+","+records.Count(v=>v.a==1)+","+records.Count(v=>v.a==2));
                        Check(!records.Any(v=>v.a<=0 && v.b==7),"retired hit-range reason 7 is never emitted "+dataset+"/"+range);
                        File.WriteAllLines("receiver-range-work.csv",rows);
                    }
                }
            }
            File.WriteAllText("receiver-range-work-method.txt","R1024, smoothness cutoff 0.5, sample phase 0, current unchanged budgets/normal stabilization. Range off/25/50/100/250/500m, fixed input and settings otherwise. Existing optional traversal diagnostics count executed work; no timestamp intervals or wall-time performance claims. Captured water/ground replay plus floor/wall control. Near receivers retain exact raw results, records, continuation, normals and iteration counts. Out-of-range receivers have zero eligible/iteration/continuation counts.\n");
        } finally {AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.worldToCameraMatrix=world;camera.ResetProjectionMatrix();}
    }
    static partial void ProfileCurrentSsr()
    {
        if(File.Exists("receiver-range-work.txt")){ProfileReceiverRangeWork();return;}
        if(File.Exists("smoothness-sweep.txt")){ProfileSmoothnessSweep();return;}
        var rows=new List<string>{"dataset,resolution,region,trial,sample,stage,gpu_ms"};
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        var world=camera.worldToCameraMatrix;float near=camera.nearClipPlane,far=camera.farClipPlane,fov=camera.fieldOfView;
        ulong probes=timer.CompletionProbes,failures=timer.CompletionFailures;
        try {
            foreach(string dataset in new[]{"floor-wall","captured-water","captured-ground"}) {
                camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world;Fixture();
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                Texture2D mask=null;
                if(dataset!="floor-wall")mask=SetupCapturedReplay(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",dataset=="captured-water"?"20261001-102353-500":"20261001-102702-951"));
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer()) {
                    Check(AmbientReflectionCapture.Begin(cb,camera,true),"current timing captured subtraction "+dataset);cb.ClearRandomWriteTargets();
                    cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));
                    cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    var o=Options();o.Smoothness=0;o.Distance=0;o.LimitNativeRange=false;o.Freeze=true;o.Temporal=false;
                    o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalStartDistance=10;o.NormalEndDistance=100;o.NormalRadius=4;
                    o.BypassHitNormal=true;o.UseCapturedContribution=true;o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
                    o.Thickness=1;o.ThicknessConfidenceFloor=1;o.FallbackStrength=.600939f;o.SurfaceColourInfluence=.1971831f;
                    var pipelines=new[]{new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian),new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)};
                    try {
                        for(int i=0;i<2;i++) {
                            var p=pipelines[i];int size=i==0?1024:768;
                            p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);
                            // Diagnostic traversal is outside timing and explicitly opt-in.
                            Globals(cb);TodGlobals(cb,.2f);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                            string folder="current-work-"+dataset+"-R"+size;Directory.CreateDirectory(folder);
                            ContinuationCapture.SaveTraversal(folder,Read(p.TracePipeline.Sample),Read(p.TracePipeline.DepthHit),Read(p.TracePipeline.Record),Read(p.TracePipeline.TraceInfo),size);
                            Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                            Check(p.TracePipeline.Sample==null && p.TracePipeline.DepthHit==null,"ordinary timing has no optional diagnostics "+dataset+"/R"+size);
                        }
                        foreach(string region in new[]{"outer-SSR","depth-normal-trace-sky","stages"})for(int trial=0;trial<3;trial++) {
                            perStage=false;completionOutput=null;
                            // Paired continuous warmup; keep allocations and CPU readbacks outside intervals.
                            for(int warm=0;warm<32;warm++)foreach(var p in pipelines){Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);}
                            Execute(cb);GpuBarrier();
                            for(int first=0;first<24;first+=4) {
                                for(int sample=first;sample<first+4;sample++)foreach(int i in (sample+trial)%2==0?new[]{0,1}:new[]{1,0}) {
                                    var p=pipelines[i];perStage=region=="stages";
                                    completionOutput=name=>name.EndsWith("/HiZ build")?(Texture)p.TracePipeline.Depth.Last():
                                        name.EndsWith("/Normal footprint filter")?(Texture)p.TracePipeline.WaterNormal:
                                        name.EndsWith("/HiZ trace") || name.EndsWith("/Completed continuation sky")?(Texture)p.TracePipeline.Radiance:
                                        name.EndsWith("/Receiver colour fallback")?(Texture)p.ReceiverFallback.Radiance:
                                        name.EndsWith("/Radiance and coverage resolve")?(Texture)p.DepthGapFilled:
                                        name.EndsWith("/Environment replacement")?(Texture)camera.targetTexture:null;
                                    Globals(cb);TodGlobals(cb,.2f);var ticket=timer.Reserve(trial*1000+sample,i+1,camera.GetInstanceID(),0);
                                    Check(ticket!=IntPtr.Zero,"current SSR timestamp reservation");timer.Event(cb,1,ticket);
                                    if(region=="depth-normal-trace-sky") {
                                        timer.DeepMark(cb,400);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular);
                                        timer.DeepMark(cb,400,true,true,p.TracePipeline.Radiance);
                                    } else p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                                    timer.Event(cb,2,ticket);
                                }
                                Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                                var buffer=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;
                                while((count=timer.Read(buffer))>0)results.AddRange(buffer.Take(count));
                                Check(results.Count(r=>r.Stage==0)==8 && results.All(r=>r.Flags==0) && timer.Pending==0,"current SSR queries complete without disjoint/missing intervals");
                                if(region=="depth-normal-trace-sky")Check(results.Count(r=>r.Stage==400)==8,"combined front-end completion probes present");
                                foreach(var r in results) {
                                    var root=results.Single(v=>v.Stage==0 && v.Frame==r.Frame && v.Window==r.Window);
                                    Check(r.Begin>=root.Begin && r.End<=root.End,"current SSR stage lies in its total interval");
                                    string stage=r.Stage==0?"Root":r.Stage==400?"Combined-front-end":stageIds.Single(kv=>kv.Value==r.Stage).Key;
                                    rows.Add(dataset+","+(r.Window==1?1024:768)+","+region+","+trial+","+(r.Frame%1000)+","+stage+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                                }
                                File.WriteAllLines("current-ssr-gpu.csv",rows);
                            }
                        }
                    } finally {perStage=false;completionOutput=null;foreach(var p in pipelines)p.Dispose();}
                }
                AmbientReflectionCapture.Dispose();
            }
            Check(timer.CompletionProbes>probes && timer.CompletionFailures==failures && timer.Dropped==0 && timer.Pending==0,"current SSR completion probes valid; no dropped/pending queries");
            File.WriteAllText("current-ssr-method.txt",SystemInfo.graphicsDeviceName+"; "+SystemInfo.graphicsDeviceType+"; camera 2560x1440, full-rate square R1024/R768. Native cutoff 0 (smoothness >= 0); sample phase frozen at 0; temporal off. Current production shaders, traversal 515 / continuation 557 / 500 camera px / 50 m; normal stabilization 85%, 10-100 m, radius 4. Source fill, fallback, sky and captured subtraction enabled. Three trials per region, 32 paired continuous warmups, 24 alternating samples per resolution/trial; discard first four samples when summarizing. Batches contain four pairs. Outer SSR includes initialization, depth, normal, trace, sky, fallback mips, resolve and composition, with no internal probes. Separate combined front-end runs have one output-dependent compute completion probe; separate stage runs include internal probe overhead and must not be summed into the root-only result. Diagnostic traversal/readbacks and fences are outside measured intervals. No genuinely reduced-rate tracer exists; withheld full-rate reconstruction is not timed as a speedup. Capture-derived EXRs and synthetic TOD/subtraction do not reproduce a live raid. Completion probes="+(timer.CompletionProbes-probes)+"; failures="+(timer.CompletionFailures-failures)+".\n");
        } finally {
            perStage=false;completionOutput=null;AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;
            camera.nearClipPlane=near;camera.farClipPlane=far;camera.fieldOfView=fov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=world;Fixture();
        }
    }
}
