using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using Before=FuckTheseFX.Source.StochasticSSR.TraceOptimizationBaseline;

public static partial class StochasticSsrValidation
{
    private static Before.Options OptimizationOptions(Options options)
    {
        object value=new Before.Options();
        foreach(var field in typeof(Options).GetFields(System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance)) {
            var target=typeof(Before.Options).GetField(field.Name,System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);
            if(target==null)continue;var item=field.GetValue(options);target.SetValue(value,target.FieldType.IsEnum?Enum.ToObject(target.FieldType,(int)item):item);
        }
        return (Before.Options)value;
    }
    private static void TraceOptimizationContracts()
    {
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeTraceOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeTraceOptimization/Reflection.shader");
        Check(oldCompute!=null && oldReflection!=null,"pre-trace-optimization baseline frozen separately from release assets");
        File.WriteAllText("trace-optimization-parity.csv","temporal,normals,reconstruction,frame,raw,records,cost,stop,normal,resolve,fill,composition\n");
        foreach(bool temporal in new[]{false,true})foreach(bool stabilize in new[]{false,true})
        foreach(var reconstruction in Enum.GetValues(typeof(ReflectionReconstruction)).Cast<ReflectionReconstruction>()) {
            using(var cb=new CommandBuffer())using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                before.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);
                var o=Options();o.Temporal=temporal;o.WaterNormals=stabilize;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.BypassHitNormal=true;
                o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.Reconstruction=reconstruction;
                for(int frame=0;frame<3;frame++) {
                    Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,OptimizationOptions(o),depths,normals,specular,true);Execute(cb);var image=Read(camera.targetTexture);
                    Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    double[] errors={Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance)),Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record)),
                        Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo)),Error(Read(before.TracePipeline.TraceStop),Read(after.TracePipeline.TraceStop)),
                        stabilize?Error(Read(before.TracePipeline.WaterNormal),Read(after.TracePipeline.WaterNormal)):0,Error(Read(before.Resolved),Read(after.Resolved)),
                        Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled)),Error(image,Read(camera.targetTexture))};
                    Check(errors.Take(7).All(e=>e==0) && EquivalentComposition(image,Read(camera.targetTexture)),"trace optimization baseline parity temporal="+temporal+" normals="+stabilize+" reconstruction="+reconstruction+" frame="+frame+" errors="+string.Join(",",errors));
                    Check(Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 && Error(Read(before.TracePipeline.HitPoint),Read(after.TracePipeline.HitPoint))==0 &&
                        Error(Read(before.TracePipeline.Sample),Read(after.TracePipeline.Sample))==0 && Error(Read(before.TracePipeline.DepthHit),Read(after.TracePipeline.DepthHit))==0 &&
                        (!temporal || (Error(Read(before.History),Read(after.History))==0 && Error(Read(before.HistoryStats),Read(after.HistoryStats))==0)),
                        "trace optimization baseline retains exact hit geometry, ray/PDF, confidence factors and measured history");
                    File.AppendAllText("trace-optimization-parity.csv",temporal+","+stabilize+","+reconstruction+","+frame+","+string.Join(",",errors)+"\n");
                }
                Check(after.TracePipeline.Depth[0].width==width && after.TracePipeline.Depth[0].height==height,"Hi-Z starts at camera extent without power-of-two padding");
                for(int level=1;level<after.TracePipeline.Depth.Count;level++) {
                    var a=after.TracePipeline.Depth[level-1];var b=after.TracePipeline.Depth[level];
                    Check(b.width==(a.width+1)/2 && b.height==(a.height+1)/2,"Hi-Z partial cells use ceiling reduction level "+level);
                }
                if(!temporal)Check(after.History==null && after.Temporal==null && after.HistoryPlane==null && after.TemporalStats==null,"temporal-off does not allocate history or statistics targets");
                o.Temporal=!temporal;Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                Check(o.Temporal?after.History!=null:after.History==null,"temporal resources follow live toggle");
            }
        }
        OptimizationOddExtent();
        OptimizationTraversalStress();
        OptimizationStateConsumers();
    }
    private static void OptimizationOddExtent()
    {
        int originalWidth=width,originalHeight=height;
        try {
            width=259;height=145;Fixture();
            var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeTraceOptimization/HiZ.compute");
            var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeTraceOptimization/Reflection.shader");
            foreach(bool bypass in new[]{false,true})using(var cb=new CommandBuffer())
            using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                before.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);
                var o=Options();o.BypassHitNormal=bypass;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;
                o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
                Globals(cb);before.Render(cb,camera,scene,camera.targetTexture,OptimizationOptions(o),depths,normals,specular,true);Execute(cb);var image=Read(camera.targetTexture);
                Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 && Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 &&
                    Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"odd rectangular camera retains ray/coverage/continuation semantics with bypass="+bypass);
                Check(before.TracePipeline.Depth.Count==after.TracePipeline.Depth.Count,"unpadded hierarchy retains traversal level count");
                for(int level=0;level<after.TracePipeline.Depth.Count;level++) {
                    var a=before.TracePipeline.Depth[level];var b=after.TracePipeline.Depth[level];var av=Read(a);var bv=Read(b);
                    Check(Enumerable.Range(0,bv.Length).All(j=>bv[j].r==av[j/b.width*a.width+j%b.width].r),"odd partial Hi-Z edge equals old far-padded minimum at level "+level);
                }
            }
        } finally {width=originalWidth;height=originalHeight;Fixture();}
    }
    // Exercise arbitrary raster/trace aspect, animated wet normals, foreground
    // occlusion, sky, active range/continuation limits and reused output targets.
    private static void OptimizationTraversalStress()
    {
        int ow=width,oh=height;var projection=camera.projectionMatrix;
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeTraceOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeTraceOptimization/Reflection.shader");
        try {
            width=259;height=145;Fixture();
            foreach(bool late in new[]{false,true})foreach(bool diagnostics in new[]{false,true})
            foreach(int scenario in new[]{0,1,2,3})using(var cb=new CommandBuffer())
            using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                int size=scenario==3?128:64;before.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
                var o=Options();o.Freeze=false;o.Temporal=true;o.BypassHitNormal=scenario!=2;o.WaterNormals=scenario!=1;o.WaterTraceStrength=.85f;o.NormalRadius=4;
                o.Steps=scenario==1?3:515;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.ContinuationSamples=scenario==2?3:557;
                o.ContinuationPixels=scenario==2?6:500;o.ContinuationDepth=scenario==2?1:50;
                o.LimitNativeRange=false;o.Distance=250; // Historical hit-range parity is replaced by ReceiverRangeContracts.
                for(int frame=0;frame<3;frame++) {
                    camera.projectionMatrix=projection;
                    var jitter=projection;jitter.m02+=(frame-1)*.8f/width;jitter.m12+=(1-frame)*.6f/height;
                    camera.projectionMatrix=jitter;
                    var gpu=GL.GetGPUProjectionMatrix(jitter,false);var d=new Color[width*height];var n=new Color[d.Length];var s=new Color[d.Length];var c=new Color[d.Length];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
                        int i=y*width+x;bool sky=y>height*3/4;bool foreground=x>width/3 && x<width/2 && y>height/3 && y<height*3/4;
                        float z=foreground?2:20+y*.3f+(float)Math.Sin(x*.06)*3;
                        var clip=gpu*new Vector4(0,0,-z,1);d[i]=new Color(sky?(SystemInfo.usesReversedZBuffer?0:1):clip.z/clip.w,0,0,0);
                        var normal=new Vector3((float)Math.Sin(x*.7+frame)*.12f,1,(float)Math.Cos(y*.6+frame)*.12f).normalized;
                        if(foreground)normal=Vector3.forward;
                        n[i]=i%997==0?Color.clear:new Color(normal.x*.5f+.5f,normal.y*.5f+.5f,normal.z*.5f+.5f,1);
                        s[i]=new Color(.04f,.06f,.08f,foreground?.3f:i%5==0?1:.92f);
                        c[i]=new Color(.1f+x*.005f,.2f+y*.01f,foreground?2:.4f,1);
                    }
                    depths=Texture(d);normals=Texture(n);specular=Texture(s);scene=Texture(c);
                    if(late) {
                        before.PrepareRaster(camera,1,width,height);before.TracePipeline.Raster.FinalizeRaster(camera);
                        after.PrepareRaster(camera,1,width,height);after.TracePipeline.Raster.FinalizeRaster(camera);
                    }
                    Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,OptimizationOptions(o),depths,normals,specular,diagnostics);Execute(cb);var image=Read(camera.targetTexture);
                    Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,diagnostics);Execute(cb);
                    Check(Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 && Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 &&
                        Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 && Error(Read(before.TracePipeline.HitPoint),Read(after.TracePipeline.HitPoint))==0 &&
                        Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo))==0 && Error(Read(before.TracePipeline.TraceStop),Read(after.TracePipeline.TraceStop))==0,
                        "exact traversal stress late="+late+" diagnostics="+diagnostics+" scenario="+scenario+" frame="+frame);
                    Check(Error(Read(before.Resolved),Read(after.Resolved))==0 && Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled))==0 &&
                        Error(Read(before.History),Read(after.History))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"stress preserves measured/fill/history and composition");
                    if(diagnostics)Check(Error(Read(before.TracePipeline.Sample),Read(after.TracePipeline.Sample))==0 && Error(Read(before.TracePipeline.DepthHit),Read(after.TracePipeline.DepthHit))==0,"stress diagnostics preserve sampled rays and hit confidence");
                    if(late){before.TracePipeline.Raster.Commit();after.TracePipeline.Raster.Commit();}
                }
            }
        } finally {camera.ResetProjectionMatrix();width=ow;height=oh;Fixture();}
    }
    private static void OptimizationStateConsumers()
    {
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeTraceOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeTraceOptimization/Reflection.shader");
        using(var cb=new CommandBuffer())using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
        using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            before.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
            var o=Options();o.BypassHitNormal=true;o.Steps=515;
            foreach(int mode in new[]{0,1,2,3,0}) {
                o.Temporal=mode==1;o.View=mode==2?ReflectionView.HitDepthDistance:ReflectionView.Normal;bool diagnostics=mode==3;
                Globals(cb);before.Render(cb,camera,scene,camera.targetTexture,OptimizationOptions(o),depths,normals,specular,diagnostics);Execute(cb);var image=Read(camera.targetTexture);
                Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,diagnostics);Execute(cb);
                Check(Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 && Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 &&
                    Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 && Error(Read(before.Resolved),Read(after.Resolved))==0 &&
                    Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"state consumer toggle retains exact rendered signal mode="+mode);
                var oldPoint=Read(before.TracePipeline.HitPoint);var newPoint=Read(after.TracePipeline.HitPoint);var record=Read(after.TracePipeline.Record);
                Check(Error(oldPoint,newPoint)==0,"all consumers retain complete hit geometry mode="+mode);
            }
        }
    }
}

