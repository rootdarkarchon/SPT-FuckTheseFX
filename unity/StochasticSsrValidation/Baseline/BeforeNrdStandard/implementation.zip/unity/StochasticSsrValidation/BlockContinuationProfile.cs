using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using CustomAmbientResearch;

public static partial class StochasticSsrValidation
{
    private sealed class BlockSnapshot {
        internal Color[] Radiance,Guide,Point,Record,Cost,Stop,Resolved,Filled,History,Composed;
        internal BlockSnapshot(ConfidenceSsrPipeline p) {
            var t=p.TracePipeline;Radiance=Read(t.Radiance);Guide=Read(t.Hit);Point=Read(t.HitPoint);
            Record=Read(t.Record);Cost=Read(t.TraceInfo);Stop=Read(t.TraceStop);Resolved=Read(p.Resolved);Filled=Read(p.DepthGapFilled);History=p.History!=null?Read(p.History):null;Composed=Read(camera.targetTexture);
        }
    }
    private static float BlockError(Color a,Color b) => Mathf.Max(Mathf.Max(Mathf.Abs(a.r-b.r),Mathf.Abs(a.g-b.g)),Mathf.Max(Mathf.Abs(a.b-b.b),Mathf.Abs(a.a-b.a)));
    private static bool BlockClose(Color a,Color b,float absolute=0.00025f,float relative=0.000002f) {
        for(int c=0;c<4;c++)if(!float.IsNaN(a[c]) && !float.IsNaN(b[c]) && Mathf.Abs(a[c]-b[c])<=absolute+relative*Mathf.Max(Mathf.Abs(a[c]),Mathf.Abs(b[c]))){}else return false;
        return true;
    }
    private static bool BlockBudget(Color r)=>r.a==0 && r.b==8;
    private static void CheckBlockSignals(string label,BlockSnapshot baseline,BlockSnapshot high,BlockSnapshot candidate,List<string> evidence,int traceWidth=1024) {
        int failures=0,recovered=0,stillBudget=0;float maxCost=0,maxGuide=0,maxPoint=0;
        var detail=new List<string>{"label,x,y,baseline_reason,baseline_kind,reference_reason,reference_kind,candidate_reason,candidate_kind,raw_error,guide_error,point_error,cost_error,stop_error"};
        for(int i=0;i<candidate.Record.Length;i++) {
            bool exhausted=BlockBudget(baseline.Record[i]),unresolved=BlockBudget(candidate.Record[i]);
            if(exhausted && unresolved){stillBudget++;continue;}
            var reference=exhausted?high:baseline;var r=reference.Record[i];var c=candidate.Record[i];
            bool record=c.a==r.a && (r.a==1?c.r==r.r && c.g==r.g:r.a==2?BlockClose(c,r):c.b==r.b);
            bool ok=record && BlockClose(candidate.Radiance[i],reference.Radiance[i],0,0) && BlockClose(candidate.Guide[i],reference.Guide[i]) &&
                BlockClose(candidate.Point[i],reference.Point[i]) && BlockClose(candidate.Stop[i],reference.Stop[i]) &&
                candidate.Resolved[i]==reference.Resolved[i] && (candidate.History!=null || candidate.Filled[i]==reference.Filled[i]) &&
                candidate.Cost[i].r==reference.Cost[i].r && candidate.Cost[i].a==reference.Cost[i].a && BlockClose(candidate.Cost[i],reference.Cost[i]);
            maxCost=Mathf.Max(maxCost,BlockError(candidate.Cost[i],reference.Cost[i]));maxGuide=Mathf.Max(maxGuide,BlockError(candidate.Guide[i],reference.Guide[i]));maxPoint=Mathf.Max(maxPoint,BlockError(candidate.Point[i],reference.Point[i]));
            if(exhausted && !unresolved)recovered++;
            if(!ok){failures++;if(detail.Count<2001)detail.Add(label+","+(i%traceWidth)+","+(i/traceWidth)+","+baseline.Record[i].b+","+baseline.Record[i].a+","+r.b+","+r.a+","+c.b+","+c.a+","+BlockError(candidate.Radiance[i],reference.Radiance[i])+","+BlockError(candidate.Guide[i],reference.Guide[i])+","+BlockError(candidate.Point[i],reference.Point[i])+","+BlockError(candidate.Cost[i],reference.Cost[i])+","+BlockError(candidate.Stop[i],reference.Stop[i]));}
        }
        evidence.Add(label+","+candidate.Record.Length+","+failures+","+recovered+","+stillBudget+","+maxCost.ToString("G9",CultureInfo.InvariantCulture)+","+maxGuide.ToString("G9",CultureInfo.InvariantCulture)+","+maxPoint.ToString("G9",CultureInfo.InvariantCulture));
        File.WriteAllLines("block-continuation-correctness.csv",evidence);File.WriteAllLines("block-continuation-failures.csv",detail);
        Check(failures==0,"bounded continuation preserves conclusive rays and checks recovered budgets against 4096-work baseline: "+label+" recovered="+recovered+" remaining="+stillBudget);
        if(recovered==0 && stillBudget==0)Check(Error(baseline.Resolved,candidate.Resolved)==0 && Error(baseline.Filled,candidate.Filled)==0 && EquivalentComposition(baseline.Composed,candidate.Composed) && (baseline.History==null || Error(baseline.History,candidate.History)==0),"bounded continuation retains resolved, source-filled, history and composition energy: "+label);
        else if(stillBudget==0 && candidate.History==null)Check(Error(high.Resolved,candidate.Resolved)==0 && Error(high.Filled,candidate.Filled)==0 && EquivalentComposition(high.Composed,candidate.Composed),"recovered coverage matches full higher-budget resolve/fill/composition: "+label);
    }
    private static void BlockGatherContract(ComputeShader shader) {
        int ow=width,oh=height;width=31;height=19;Fixture();
        using(var cb=new CommandBuffer()) {
            var depth=new Texture2D(width,height,TextureFormat.RFloat,false,true);owned.Add(depth);
            var values=Enumerable.Range(0,width*height).Select(i=>new Color(i+1,0,0,0)).ToArray();depth.SetPixels(values);depth.Apply();
            var output=new RenderTexture(width/2,height/2,0,RenderTextureFormat.ARGBFloat){enableRandomWrite=true};output.Create();
            var probe=UnityEngine.Object.Instantiate(shader);int k=probe.FindKernel("ValidateGather");
            cb.SetComputeVectorParam(probe,"_Size",new Vector4(width,height,0,0));cb.SetComputeTextureParam(probe,k,"_HiZ0",depth);cb.SetComputeTextureParam(probe,k,"_RadianceOutput",output);
            cb.DispatchCompute(probe,k,(output.width+7)/8,(output.height+7)/8,1);Execute(cb);var pixels=Read(output);
            Check(pixels.Select((v,i)=>{int x=(i%output.width)*2,y=(i/output.width)*2;return v==new Color(values[(y+1)*width+x].r,values[(y+1)*width+x+1].r,values[y*width+x+1].r,values[y*width+x].r);}).All(v=>v),"DX11 gather has exact integer-depth lane order on odd camera dimensions");
            output.Release();UnityEngine.Object.DestroyImmediate(output);UnityEngine.Object.DestroyImmediate(probe);
        }
        width=ow;height=oh;Fixture();
    }
    private static void BlockDynamicContracts(ComputeShader baselineShader,ComputeShader candidateShader) {
        int ow=width,oh=height;var world=camera.worldToCameraMatrix;var projection=camera.projectionMatrix;
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        var evidence=new List<string>{"dataset,rays,incorrect,recovered_baseline_budget,remaining_budget,max_cost_error,max_guide_error,max_point_error"};
        try {
            // Stationary-camera moving depth is tested separately from jitter /
            // camera motion. No acceleration data persists across dispatches.
            width=321;height=185;camera.ResetProjectionMatrix();Fixture();var stable=camera.projectionMatrix;
            foreach(bool temporal in new[]{false,true})foreach(bool late in new[]{false,true})foreach(int scenario in new[]{0,1,2,3})
            using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
            using(var cb=new CommandBuffer())using(var baseline=new ConfidenceSsrPipeline(baselineShader,blend,reflection,noise,native,gaussian))
            using(var candidate=new ConfidenceSsrPipeline(candidateShader,blend,reflection,noise,native,gaussian))using(var high=new ConfidenceSsrPipeline(baselineShader,blend,reflection,noise,native,gaussian)) {
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                int size=scenario==2?768:scenario==1?256:128;
                foreach(var p in new[]{baseline,candidate,high}){p.ReceiverFallback.DirectFinalMip=false;p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);}
                var o=Options();o.Temporal=temporal;o.Freeze=false;o.Steps=scenario==3?32:515;o.Thickness=1;o.ThicknessConfidenceFloor=1;
                o.ContinuationSamples=scenario==2?3:557;o.ContinuationPixels=scenario==2?6:500;o.ContinuationDepth=scenario==2?1:50;
                o.BypassHitNormal=scenario!=2;o.WaterNormals=scenario!=2;o.WaterTraceStrength=.85f;o.NormalRadius=4;
                o.LimitNativeRange=scenario==2;o.Distance=3;o.Reconstruction=scenario==1?ReflectionReconstruction.NativeGaussian:ReflectionReconstruction.Custom;
                for(int frame=0;frame<4;frame++) {
                    camera.projectionMatrix=stable;camera.worldToCameraMatrix=world;
                    if(scenario==1) {var jitter=stable;jitter.m02+=(frame-1)*.8f/width;jitter.m12+=(1-frame)*.6f/height;camera.projectionMatrix=jitter;var view=world;view.m03+=frame*.02f;camera.worldToCameraMatrix=view;}
                    var gpu=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);var d=new Color[width*height];var n=new Color[d.Length];var sp=new Color[d.Length];var colors=new Color[d.Length];var wm=new Color[d.Length];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
                        int i=y*width+x;bool sky=y>height*3/4;
                        bool weapon=x>width/3+frame*9 && x<width/2+frame*9 && y>height/4 && y<height*3/4;
                        bool foliage=x>width*2/3 && y>height/3 && ((x+frame*3)%7)<3;
                        float z=weapon?2+y*.003f:foliage?4:20+y*.3f+(float)Math.Sin(x*.06)*3;
                        sky=sky && !foliage;var clip=gpu*new Vector4(0,0,-z,1);d[i]=new Color(sky?(SystemInfo.usesReversedZBuffer?0:1):clip.z/clip.w,0,0,0);
                        var normal=new Vector3((float)Math.Sin(x*.7+frame)*.12f,1,(float)Math.Cos(y*.6+frame)*.12f).normalized;
                        if(weapon || foliage)normal=Vector3.forward;
                        n[i]=scenario==2 && i%997==0?Color.clear:new Color(normal.x*.5f+.5f,normal.y*.5f+.5f,normal.z*.5f+.5f,1);
                        sp[i]=new Color(.04f,.06f,.08f,weapon?.3f:foliage?.4f:i%5==0?1:.92f);colors[i]=new Color(.1f+x*.005f,.2f+y*.01f,weapon?2:foliage?1:.4f,1);
                        wm[i]=!sky && !weapon && !foliage?new Color(z,1,0,0):Color.clear;
                    }
                    depths=Texture(d);normals=Texture(n);specular=Texture(sp);scene=Texture(colors);
                    Check(AmbientReflectionCapture.Begin(cb,camera,true),"animated fixture native subtraction available");cb.ClearRandomWriteTargets();cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));cb.Blit(Texture(wm),WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    foreach(var p in new[]{baseline,candidate,high})if(late){p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);}
                    // Blocking CPU validation readbacks are outside simulated
                    // frame time. Avoid their artificial >0.5s history timeout;
                    // camera, settings, raster and material checks still run.
                    if(frame>0)HarmonyLib.AccessTools.Field(typeof(ConfidenceSsrPipeline),"lastTime").SetValue(baseline,Time.realtimeSinceStartup);
                    Globals(cb);TodGlobals(cb,.2f);baseline.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);var a=new BlockSnapshot(baseline);
                    var highOptions=o;highOptions.Steps=4096;highOptions.Temporal=false;Globals(cb);TodGlobals(cb,.2f);high.Render(cb,camera,scene,camera.targetTexture,highOptions,depths,normals,specular);Execute(cb);var reference=new BlockSnapshot(high);
                    if(frame>0)HarmonyLib.AccessTools.Field(typeof(ConfidenceSsrPipeline),"lastTime").SetValue(candidate,Time.realtimeSinceStartup);
                    Globals(cb);TodGlobals(cb,.2f);candidate.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);var b=new BlockSnapshot(candidate);
                    string label="dynamic-temporal-"+temporal+"-late-"+late+"-scenario-"+scenario+"-frame-"+frame;CheckBlockSignals(label,a,reference,b,evidence,size);
                    if(temporal && frame>0)Check(baseline.UsedHistory==candidate.UsedHistory && candidate.UsedHistory,"animated sequence exercises actual temporal support: "+label);
                    if(late)foreach(var p in new[]{baseline,candidate,high})p.TracePipeline.Raster.Commit();
                }
                AmbientReflectionCapture.Dispose();
            }
            File.WriteAllLines("block-continuation-dynamic.csv",evidence);
        } finally {AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;camera.worldToCameraMatrix=world;camera.projectionMatrix=projection;width=ow;height=oh;Fixture();}
    }
    private static void ProfileBlockContinuation() {
        bool replayOnly=File.Exists("block-continuation-replay-only.txt");
        perStage=false;completionOutput=null;
        var baselineCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeBlockContinuation/HiZ.compute");
        var candidateCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BlockContinuation.compute");
        Check(!ShaderUtil.GetComputeShaderMessages(candidateCompute).Any(v=>v.severity.ToString()=="Error"),"bounded continuation compute compiles");BlockGatherContract(candidateCompute);BlockDynamicContracts(baselineCompute,candidateCompute);
        var rows=new List<string>{"dataset,candidate,region,trial,phase,sample,gpu_ms"};
        var evidence=new List<string>{"dataset,rays,incorrect,recovered_baseline_budget,remaining_budget,max_cost_error,max_guide_error,max_point_error"};
        var workRows=new List<string>{"dataset,variant,iterations,after_first,descents,fine_logical_visits,batched_logical_fine_visits,original_fine_path_visits,depth_fetch_instructions,rejections,budget,geometry,sky,offscreen"};
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        var originalWorld=camera.worldToCameraMatrix;float originalNear=camera.nearClipPlane,originalFar=camera.farClipPlane,originalFov=camera.fieldOfView;
        try {
            foreach(string dataset in new[]{"floor-wall","captured-water","captured-ground"}) {
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                camera.nearClipPlane=originalNear;camera.farClipPlane=originalFar;camera.fieldOfView=originalFov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=originalWorld;Fixture();
                Texture2D mask=null;
                if(dataset!="floor-wall")mask=SetupCapturedReplay(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",dataset=="captured-water"?"20261001-102353-500":"20261001-102702-951"));
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer())using(var baseline=new ConfidenceSsrPipeline(baselineCompute,blend,reflection,noise,native,gaussian))using(var candidate=new ConfidenceSsrPipeline(candidateCompute,blend,reflection,noise,native,gaussian))
                using(var workBaseline=new SsrPipeline(AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BlockBaselineWork.compute"),blend,noise)) {
                    Check(AmbientReflectionCapture.Begin(cb,camera,true),"bounded continuation uses unchanged native subtraction");cb.ClearRandomWriteTargets();
                    cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    var o=Options();o.Freeze=true;o.Temporal=false;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalStartDistance=10;o.NormalEndDistance=100;o.NormalRadius=4;
                    o.BypassHitNormal=true;o.UseCapturedContribution=true;o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.FallbackStrength=.600939f;o.SurfaceColourInfluence=.1971831f;
                    foreach(var p in new[]{baseline,candidate}){p.ReceiverFallback.DirectFinalMip=false;p.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);p.PrepareRaster(camera,1,width,height);p.TracePipeline.Raster.FinalizeRaster(camera);}
                    Globals(cb);TodGlobals(cb,.2f);baseline.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);var normal=new BlockSnapshot(baseline);
                    var highOptions=o;highOptions.Steps=4096;Globals(cb);TodGlobals(cb,.2f);baseline.Render(cb,camera,scene,camera.targetTexture,highOptions,depths,normals,specular);Execute(cb);var high=new BlockSnapshot(baseline);
                    Globals(cb);TodGlobals(cb,.2f);candidate.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);var optimized=new BlockSnapshot(candidate);
                    CheckBlockSignals(dataset,normal,high,optimized,evidence);
                    workBaseline.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);workBaseline.Raster.Enable(camera);workBaseline.Raster.Record(camera,1,width,height);workBaseline.Raster.FinalizeRaster(camera);
                    foreach(var pair in new[]{new KeyValuePair<string,SsrPipeline>("baseline",workBaseline),new KeyValuePair<string,SsrPipeline>("candidate",candidate.TracePipeline)}) {
                        Globals(cb);pair.Value.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                        var a=Read(pair.Value.Sample);var b=Read(pair.Value.DepthHit);var r=Read(pair.Value.Record);
                        workRows.Add(dataset+","+pair.Key+","+a.Sum(v=>(double)v.r)+","+a.Sum(v=>(double)v.g)+","+a.Sum(v=>(double)v.b)+","+b.Sum(v=>(double)v.r)+","+b.Sum(v=>(double)v.g)+","+b.Sum(v=>(double)(v.r-v.g))+","+b.Sum(v=>(double)v.b)+","+b.Sum(v=>(double)v.a)+","+r.Count(BlockBudget)+","+r.Count(v=>v.a==1)+","+r.Count(v=>v.a==2)+","+r.Count(v=>v.a==0 && v.b==6));
                    }
                    File.WriteAllLines("block-continuation-work.csv",workRows);
                    if(!replayOnly)foreach(string region in new[]{"outer-SSR","depth-normal-trace-sky"})for(int trial=0;trial<3;trial++) {
                        for(int warm=0;warm<24;warm++)foreach(var p in new[]{baseline,candidate}){Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);}Execute(cb);GpuBarrier();
                        Check(baseline.TracePipeline.Sample==null && candidate.TracePipeline.Sample==null && baseline.TracePipeline.DepthHit==null && candidate.TracePipeline.DepthHit==null,"bounded continuation timing has no work diagnostic targets");
                        for(int first=0;first<24;first+=4) {
                            for(int sample=first;sample<first+4;sample++)for(int phase=0;phase<3;phase++) {
                                var p=phase==1?candidate:baseline;int frame=trial*10000+sample*3+phase;
                                Globals(cb);TodGlobals(cb,.2f);var ticket=timer.Reserve(frame,phase==1?2:1,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"bounded continuation timestamp reservation");timer.Event(cb,1,ticket);
                                if(region=="outer-SSR")p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                                else{timer.DeepMark(cb,400);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular);timer.DeepMark(cb,400,true,true,p.TracePipeline.Radiance);}
                                timer.Event(cb,2,ticket);
                            }
                            Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                            var buffer=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;while((count=timer.Read(buffer))>0)results.AddRange(buffer.Take(count));
                            Check(results.Count(r=>r.Stage==0)==12 && results.All(r=>r.Flags==0) && timer.Pending==0,"bounded continuation A/B/A intervals complete without disjoint queries");
                            if(region!="outer-SSR")Check(results.Count(r=>r.Stage==400)==12,"bounded continuation combined-front completion present");
                            foreach(var r in results.Where(r=>r.Stage==0))rows.Add(dataset+",gather2x2,"+region+","+trial+","+((r.Frame%10000)%3)+","+((r.Frame%10000)/3)+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                        }
                        File.WriteAllLines("block-continuation-gpu.csv",rows);
                    }
                    normal=null;high=null;optimized=null;GC.Collect();
                }
                AmbientReflectionCapture.Dispose();
            }
            Directory.CreateDirectory("BlockOutput");Check(BuildPipeline.BuildAssetBundles("BlockOutput",new[]{new AssetBundleBuild{assetBundleName="block-continuation-test",assetNames=new[]{"Assets/BeforeBlockContinuation/HiZ.compute","Assets/BlockBaselineWork.compute","Assets/BlockContinuation.compute"}}},BuildAssetBundleOptions.ForceRebuildAssetBundle|BuildAssetBundleOptions.ChunkBasedCompression,BuildTarget.StandaloneWindows64)!=null,"isolated research-only continuation shaders build");
        } finally {AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;camera.nearClipPlane=originalNear;camera.farClipPlane=originalFar;camera.fieldOfView=originalFov;camera.ResetProjectionMatrix();camera.worldToCameraMatrix=originalWorld;Fixture();}
    }
}
