using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CustomAmbientResearch;
using FuckTheseFX.Source.StochasticSSR;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.PostProcessing;

public static partial class StochasticSsrValidation
{
    static partial void RunReducedRateFeasibility();
    static partial void ProfileHistory();
    private static bool historyOnly;
    static partial void ProfileCurrentSsr();
    private static GpuTiming timer;
    private static bool perStage;
    private static Func<string,Texture> completionOutput;
    private static readonly Dictionary<string,int> stageIds=new Dictionary<string,int>();
    private static void BeginGpu(CommandBuffer __0,string __2) {
        if(!perStage)return;
        string name="FTFX Stochastic SSR/"+__2;
        if(historyOnly && __2!="History store")return;
        if(!stageIds.TryGetValue(name,out int id)){id=17+stageIds.Count;stageIds.Add(name,id);}timer.DeepMark(__0,id);
    }
    private static void EndGpu(SsrGpuSample __instance) {
        if(!perStage)return;
        string name=(string)AccessTools.Field(typeof(SsrGpuSample),"name").GetValue(__instance);
        if(historyOnly && name!="FTFX Stochastic SSR/History store")return;
        var cb=(CommandBuffer)AccessTools.Field(typeof(SsrGpuSample),"buffer").GetValue(__instance);
        var output=completionOutput?.Invoke(name);
        timer.DeepMark(cb,stageIds[name],true,output!=null,output);
    }
    private static void GpuBarrier() { var r=AsyncGPUReadback.Request(camera.targetTexture,0,0,1,0,1,0,1,TextureFormat.RGBAFloat);r.WaitForCompletion();if(r.hasError)throw new Exception("GPU fence readback failed"); }
    static partial void Profile()
    {
        int ow=width,oh=height;width=2560;height=1440;Fixture();
        specular=Texture(specular.GetPixels().Select(v=>new Color(v.r,v.g,v.b,v.a>.5f?.9f:v.a)).ToArray());
        timer=new GpuTiming();timer.Initialize(Path.GetFullPath("Native/CustomAmbientGpu.dll"),GpuTiming.StageCapacity);
        var harmony=new Harmony("ssr.confidence.gpu-fixture");
        harmony.Patch(AccessTools.Method(typeof(SsrGpuSample),"Measure"),prefix:new HarmonyMethod(typeof(StochasticSsrValidation),nameof(BeginGpu)));
        harmony.Patch(AccessTools.Method(typeof(SsrGpuSample),"Dispose"),prefix:new HarmonyMethod(typeof(StochasticSsrValidation),nameof(EndGpu)));
        var rows=new List<string>{"mode,frame,stage,gpu_ms,begin,end"};var measurements=new Dictionary<string,List<double>>();
        var factory=new PropertySheetFactory();var context=Context(factory);var renderer=CreateRenderer(out var effect);
        try {
            if(File.Exists("history-timing.txt")){ProfileHistory();return;}
            if(File.Exists("current-ssr-timing.txt")){ProfileCurrentSsr();return;}
            if(File.Exists("reduced-rate-feasibility.txt")){RunReducedRateFeasibility();return;}
            if(File.Exists("block-continuation-profile.txt")){ProfileBlockContinuation();return;}
            if(File.Exists("continuation-profile.txt")){ProfileContinuationCandidates();return;}
            using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);var o=Options();o.Freeze=false;o.Temporal=true;
                // Warm a continuous workload before interleaved measurements to avoid measuring idle-clock ramp-up.
                perStage=false;for(int warm=0;warm<64;warm++){Globals(context.command);renderer.Render(context);p.Render(context.command,camera,scene,camera.targetTexture,o,depths,normals,specular);}Execute(context.command);GpuBarrier();
                for(int frame=0;frame<32;frame++)foreach(string mode in new[]{"Native","FTFX-root","FTFX-stages"}) {
                    perStage=mode=="FTFX-stages";Globals(context.command);TodGlobals(context.command,.2f);
                    var ticket=timer.Reserve(frame,mode=="Native"?1:2,camera.GetInstanceID(),0);
                    Check(ticket!=IntPtr.Zero,"GPU timestamp reservation "+mode+" "+frame);
                    timer.Event(context.command,1,ticket);
                    if(mode=="Native")renderer.Render(context);
                    else using(SsrGpuSample.Measure(context.command,camera,"Total"))p.Render(context.command,camera,scene,camera.targetTexture,o,depths,normals,specular);
                    timer.Event(context.command,2,ticket);Execute(context.command);GpuBarrier();
                    timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                    var batch=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;
                    while((count=timer.Read(batch))>0)results.AddRange(batch.Take(count));
                    Check(results.Count>0 && results.All(r=>r.Flags==0) && timer.Pending==0,"executed non-disjoint GPU boundaries "+mode+" "+frame);
                    var root=results.Single(r=>r.Stage==0);
                    foreach(var r in results) {
                        Check(r.Begin>=root.Begin && r.End<=root.End && r.End>=r.Begin,"GPU interval contained in frame "+mode+" "+frame+"/"+r.Stage);
                        string stage=r.Stage==0?"Root":stageIds.Single(kv=>kv.Value==r.Stage).Key;
                        rows.Add(mode+","+frame+","+stage+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture)+","+r.Begin+","+r.End);
                        if(frame<8)continue;string key=mode+"/"+stage;if(!measurements.ContainsKey(key))measurements[key]=new List<double>();measurements[key].Add(r.Ms);
                    }
                }
            }
            File.WriteAllLines("gpu-timings.csv",rows);
            File.WriteAllLines("gpu-timings-summary.txt",new[]{SystemInfo.graphicsDeviceName+"; 2560x1440 scene / 1024x1024 trace; synthetic floor/wall, reflective smoothness .9 (Custom temporal accumulation); 64 continuous native/FTFX warmups, then interleaved 8 warmup + 24 measured frames per mode; D3D11 timestamp queries, not CPU recording time."}.Concat(measurements.Select(kv=>kv.Key+" median_ms="+kv.Value.OrderBy(x=>x).ElementAt(kv.Value.Count/2).ToString("F6",CultureInfo.InvariantCulture))));
            ProfilePerformanceBaseline();ProfileTraceOptimizationBaseline();ProfileNativeReconstruction();ProfileAmbientCapture();
        } finally {harmony.UnpatchSelf();timer.Dispose();context.command.Dispose();renderer.Release();factory.Release();width=ow;height=oh;Fixture();}
    }
    private static void ProfilePerformanceBaseline()
    {
        var oldCompute=UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforePerformance/HiZ.compute");
        var oldReflection=UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforePerformance/Reflection.shader");
        var rows=new List<string>{"mode,frame,stage,gpu_ms"};var values=new Dictionary<string,List<double>>();
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        using(var cb=new CommandBuffer())using(var before=new FuckTheseFX.Source.StochasticSSR.PerformanceBaseline.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
        using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            before.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);
            var o=Options();o.Temporal=false;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.BypassHitNormal=true;o.UseCapturedContribution=true;
            o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.FallbackStrength=.600939f;
            AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
            try {
                Check(AmbientReflectionCapture.Begin(cb,camera,true),"performance timing supplies a valid captured reflection");cb.ClearRandomWriteTargets();
                cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));Execute(cb);
                var oldOptions=PerformanceOptions(o);perStage=false;
                for(int warm=0;warm<24;warm++) {
                    Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular);
                    Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                }
                Execute(cb);GpuBarrier();perStage=true;
                for(int frame=0;frame<32;frame++)foreach(bool old in frame%2==0?new[]{true,false}:new[]{false,true}) {
                    string mode=old?"Before":"After";Globals(cb);TodGlobals(cb,.2f);
                    var ticket=timer.Reserve(frame,old?1:2,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"performance GPU reservation");timer.Event(cb,1,ticket);
                    using(SsrGpuSample.Measure(cb,camera,"Total")) {
                        if(old)before.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular);
                        else after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                    }
                    timer.Event(cb,2,ticket);Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                    var batch=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;while((count=timer.Read(batch))>0)results.AddRange(batch.Take(count));
                    Check(results.Count>0 && results.All(r=>r.Flags==0) && timer.Pending==0,"performance timing has valid executed timestamps");
                    var root=results.Single(r=>r.Stage==0);
                    foreach(var r in results) {
                        Check(r.Begin>=root.Begin && r.End<=root.End,"performance stage is contained in root");
                        string stage=r.Stage==0?"Root":stageIds.Single(kv=>kv.Value==r.Stage).Key;
                        rows.Add(mode+","+frame+","+stage+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                        if(frame<8)continue;string key=mode+"/"+stage;if(!values.ContainsKey(key))values[key]=new List<double>();values[key].Add(r.Ms);
                    }
                }
            } finally {AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;perStage=false;}
        }
        File.WriteAllLines("performance-gpu-timings.csv",rows);
        File.WriteAllLines("performance-gpu-summary.txt",new[]{SystemInfo.graphicsDeviceName+"; synthetic 2560x1440 floor/wall, 1024 square trace, temporal off, stabilized normals, valid captured subtraction. 24 paired warmups; alternating before/after order; 8 warmup + 24 measured samples. Not live Tarkov timing."}.Concat(values.Select(kv=>kv.Key+" median_ms="+kv.Value.OrderBy(x=>x).ElementAt(kv.Value.Count/2).ToString("F6",CultureInfo.InvariantCulture))));
    }
    private static void ProfileTraceOptimizationBaseline()
    {
        var oldCompute=UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeTraceOptimization/HiZ.compute");
        var oldReflection=UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeTraceOptimization/Reflection.shader");
        var rows=new List<string>{"mode,frame,stage,gpu_ms"};var values=new Dictionary<string,List<double>>();
        var requested=AmbientReflectionCapture.Requested;var main=AmbientReflectionCapture.IsMainCamera;
        using(var cb=new CommandBuffer())using(var before=new FuckTheseFX.Source.StochasticSSR.TraceOptimizationBaseline.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
        using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            before.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);
            var o=Options();o.Temporal=false;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.BypassHitNormal=true;o.UseCapturedContribution=true;
            o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.FallbackStrength=.600939f;
            AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
            try {
                Check(AmbientReflectionCapture.Begin(cb,camera,true),"trace optimization timing supplies a valid captured reflection");cb.ClearRandomWriteTargets();
                cb.Blit(Solid(new Color(.02f,.03f,.04f,1)),AmbientReflectionCapture.Get(camera,width,height));Execute(cb);
                var oldOptions=OptimizationOptions(o);perStage=false;
                // Production uploads raster state after PP sets jitter. Measure
                // that path, including the repeated row loads being optimized.
                before.PrepareRaster(camera,1,width,height);before.TracePipeline.Raster.FinalizeRaster(camera);
                after.PrepareRaster(camera,1,width,height);after.TracePipeline.Raster.FinalizeRaster(camera);
                Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular,true);Execute(cb);
                var image=Read(camera.targetTexture);var raw=Read(before.TracePipeline.Radiance);var records=Read(before.TracePipeline.Record);
                var hit=Read(before.TracePipeline.Hit);var point=Read(before.TracePipeline.HitPoint);var cost=Read(before.TracePipeline.TraceInfo);var stop=Read(before.TracePipeline.TraceStop);
                Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(Error(raw,Read(after.TracePipeline.Radiance))==0 && Error(records,Read(after.TracePipeline.Record))==0 && Error(hit,Read(after.TracePipeline.Hit))==0 &&
                    Error(point,Read(after.TracePipeline.HitPoint))==0 && Error(cost,Read(after.TracePipeline.TraceInfo))==0 && Error(stop,Read(after.TracePipeline.TraceStop))==0 &&
                    Error(Read(before.Resolved),Read(after.Resolved))==0 && Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled))==0 && EquivalentComposition(image,Read(camera.targetTexture)),
                    "R1024 2560x1440 late-raster optimization retains exact trace/resolve/fill and equivalent final composition");
                for(int warm=0;warm<24;warm++) {
                    Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular);
                    Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                }
                Execute(cb);GpuBarrier();
                // Submit pairs continuously: one buffer per four pairs avoids
                // inserting a CPU/readback idle gap between every measured ray
                // workload. Measure root-only separately from nested markers.
                foreach(bool detailed in new[]{false,true})for(int first=0;first<32;first+=4) {
                    perStage=detailed;
                    for(int frame=first;frame<first+4;frame++)foreach(bool old in frame%2==0?new[]{true,false}:new[]{false,true}) {
                        Globals(cb);TodGlobals(cb,.2f);
                        completionOutput=name=>name.EndsWith("/HiZ build")?(Texture)(old?before.TracePipeline.Depth.Last():after.TracePipeline.Depth.Last()):
                            name.EndsWith("/HiZ trace")?(Texture)(old?before.TracePipeline.Radiance:after.TracePipeline.Radiance):
                            name.EndsWith("/Normal footprint filter")?(Texture)(old?before.TracePipeline.WaterNormal:after.TracePipeline.WaterNormal):
                            name.EndsWith("/Receiver colour fallback")?(Texture)(old?before.ReceiverFallback.Radiance:after.ReceiverFallback.Radiance):null;
                        var ticket=timer.Reserve(frame,old?1:2,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"trace optimization GPU reservation");timer.Event(cb,1,ticket);
                        using(SsrGpuSample.Measure(cb,camera,"Total")) {
                            if(old)before.Render(cb,camera,scene,camera.targetTexture,oldOptions,depths,normals,specular);
                            else after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
                        }
                        timer.Event(cb,2,ticket);
                    }
                    Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                    var batch=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;while((count=timer.Read(batch))>0)results.AddRange(batch.Take(count));
                    Check(results.Count>0 && results.All(r=>r.Flags==0) && timer.Pending==0,"trace optimization timing has valid executed timestamps");
                    foreach(var r in results) {
                        var root=results.Single(v=>v.Stage==0 && v.Frame==r.Frame && v.Window==r.Window);
                        Check(r.Begin>=root.Begin && r.End<=root.End,"trace optimization stage is contained in root");
                        string mode=(r.Window==1?"Before":"After")+(detailed?"-stages":"-root");
                        string stage=r.Stage==0?"Root":stageIds.Single(kv=>kv.Value==r.Stage).Key;
                        rows.Add(mode+","+r.Frame+","+stage+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                        if(r.Frame<8)continue;string key=mode+"/"+stage;if(!values.ContainsKey(key))values[key]=new List<double>();values[key].Add(r.Ms);
                    }
                }
                ProfileTraceKernel(before.TracePipeline,after.TracePipeline);
            } finally {completionOutput=null;AmbientReflectionCapture.Dispose();AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=main;perStage=false;}
        }
        File.WriteAllLines("trace-optimization-gpu-timings.csv",rows);
        File.WriteAllLines("trace-optimization-gpu-summary.txt",new[]{SystemInfo.graphicsDeviceName+"; synthetic 2560x1440 floor/wall, 1024 square trace, late raster, temporal off, stabilized normals, valid captured subtraction. 24 paired warmups; alternating before/after order in batches of four pairs; 8 warmup + 24 measured samples for root-only and detailed scopes separately. Detailed scopes use compute completion probes at Hi-Z, normal, trace and fallback boundaries. Not live Tarkov timing."}.Concat(values.Select(kv=>kv.Key+" median_ms="+kv.Value.OrderBy(x=>x).ElementAt(kv.Value.Count/2).ToString("F6",CultureInfo.InvariantCulture))));
    }
    private static void ProfileTraceKernel(FuckTheseFX.Source.StochasticSSR.TraceOptimizationBaseline.SsrPipeline before,SsrPipeline after)
    {
        var oldCompute=(ComputeShader)AccessTools.Field(before.GetType(),"compute").GetValue(before);
        var newCompute=(ComputeShader)AccessTools.Field(after.GetType(),"compute").GetValue(after);
        int oldKernel=oldCompute.FindKernel("Trace"),newKernel=newCompute.FindKernel("Trace");
        int stage=17+stageIds.Count;stageIds.Add("FTFX Stochastic SSR/Isolated trace batch",stage);
        const int repetitions=16;var rows=new List<string>{"mode,frame,batch_ms,per_dispatch_ms"};var values=new Dictionary<string,List<double>>();
        perStage=false;completionOutput=null;
        using(var cb=new CommandBuffer()) {
            for(int warm=0;warm<16;warm++) {cb.DispatchCompute(oldCompute,oldKernel,128,128,1);cb.DispatchCompute(newCompute,newKernel,128,128,1);}Execute(cb);GpuBarrier();
            for(int frame=0;frame<32;frame++)foreach(bool old in frame%2==0?new[]{true,false}:new[]{false,true}) {
                string mode=old?"Before":"After";var ticket=timer.Reserve(frame,old?1:2,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"isolated trace GPU reservation");timer.Event(cb,1,ticket);
                timer.DeepMark(cb,stage);
                for(int repeat=0;repeat<repetitions;repeat++)cb.DispatchCompute(old?oldCompute:newCompute,old?oldKernel:newKernel,128,128,1);
                timer.DeepMark(cb,stage,true,true,old?before.Radiance:after.Radiance);timer.Event(cb,2,ticket);
                Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                var batch=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;while((count=timer.Read(batch))>0)results.AddRange(batch.Take(count));
                Check(results.Count==2 && results.All(r=>r.Flags==0) && timer.Pending==0,"isolated trace queries complete without disjoint intervals");
                double ms=results.Single(r=>r.Stage==stage).Ms;rows.Add(mode+","+frame+","+ms.ToString("G9",CultureInfo.InvariantCulture)+","+(ms/repetitions).ToString("G9",CultureInfo.InvariantCulture));
                if(frame>=8){if(!values.ContainsKey(mode))values[mode]=new List<double>();values[mode].Add(ms/repetitions);}
            }
        }
        File.WriteAllLines("trace-kernel-gpu-timings.csv",rows);
        File.WriteAllLines("trace-kernel-gpu-summary.txt",new[]{"R1024 / 2560x1440 synthetic inputs, late raster, frozen sample phase, bypass hit normals, full hit geometry. Sixteen consecutive Trace dispatches per GPU interval; one completion probe at the end. Eight warmup plus 24 measured alternating pairs. Batch time divided by 16 includes amortized probe/dispatch overhead; not live Tarkov timing."}.Concat(values.Select(kv=>kv.Key+" median_per_dispatch_ms="+kv.Value.OrderBy(v=>v).ElementAt(kv.Value.Count/2).ToString("F6",CultureInfo.InvariantCulture))));
    }
    private static void ProfileNativeReconstruction()
    {
        var rows=new List<string>{"mode,frame,stage,gpu_ms"};var values=new Dictionary<string,List<double>>();
        using(var cb=new CommandBuffer())using(var custom=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))
        using(var gaussianPipeline=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            custom.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);gaussianPipeline.Ensure(width,height,1024,RenderTextureFormat.ARGBHalf);
            var a=Options();a.Temporal=true;
            var b=a;b.Reconstruction=ReflectionReconstruction.NativeGaussian;
            Globals(cb);custom.Render(cb,camera,scene,camera.targetTexture,a,depths,normals,specular);
            Globals(cb);gaussianPipeline.Render(cb,camera,scene,camera.targetTexture,b,depths,normals,specular);Execute(cb);
            Check(Error(Read(custom.TracePipeline.Radiance),Read(gaussianPipeline.TracePipeline.Radiance))==0 && Error(Read(custom.TracePipeline.Record),Read(gaussianPipeline.TracePipeline.Record))==0,"native reconstruction profile uses identical frozen trace inputs");
            perStage=false;
            for(int warm=0;warm<64;warm++) {
                Globals(cb);custom.Reconstruct(cb,camera,scene,camera.targetTexture,a);
                Globals(cb);gaussianPipeline.Reconstruct(cb,camera,scene,camera.targetTexture,b);
            }
            Execute(cb);GpuBarrier();perStage=true;
            for(int frame=0;frame<40;frame++)foreach(bool nativeReconstruction in new[]{false,true}) {
                string mode=nativeReconstruction?"NativeGaussian":"Custom";
                Globals(cb);var ticket=timer.Reserve(frame,2,camera.GetInstanceID(),0);
                Check(ticket!=IntPtr.Zero,"native reconstruction GPU reservation "+mode+" "+frame);
                timer.Event(cb,1,ticket);
                (nativeReconstruction?gaussianPipeline:custom).Reconstruct(cb,camera,scene,camera.targetTexture,nativeReconstruction?b:a);
                timer.Event(cb,2,ticket);Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                var batch=new GpuTiming.Row[512];var results=new List<GpuTiming.Row>();int count;
                while((count=timer.Read(batch))>0)results.AddRange(batch.Take(count));
                Check(results.Count>0 && results.All(r=>r.Flags==0) && timer.Pending==0,"native reconstruction non-disjoint GPU intervals "+mode+" "+frame);
                var root=results.Single(r=>r.Stage==0);
                foreach(var r in results) {
                    Check(r.Begin>=root.Begin && r.End<=root.End,"native reconstruction stage contained in root "+mode+" "+frame+"/"+r.Stage);
                    string stage=r.Stage==0?"Root":stageIds.Single(kv=>kv.Value==r.Stage).Key;
                    rows.Add(mode+","+frame+","+stage+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                    if(frame<16)continue;string key=mode+"/"+stage;
                    if(!values.ContainsKey(key))values[key]=new List<double>();values[key].Add(r.Ms);
                }
            }
        }
        perStage=false;File.WriteAllLines("native-reconstruction-gpu-timings.csv",rows);
        File.WriteAllLines("native-reconstruction-gpu-summary.txt",new[]{SystemInfo.graphicsDeviceName+"; 2560x1440 camera / 1024x1024 trace; synthetic floor/wall s=.9; same frozen original trace; Custom temporal enabled; full Reconstruct interval excludes tracing; 64 continuous paired warmups then 16 interleaved warmups + 24 measured frames; per-stage instrumented GPU timestamps. Fixture cost, not live EFT performance."}.Concat(values.Select(kv=>kv.Key+" median_ms="+kv.Value.OrderBy(x=>x).ElementAt(kv.Value.Count/2).ToString("F6",CultureInfo.InvariantCulture))));
    }
    private static void ProfileAmbientCapture()
    {
        perStage=false;PrepareAmbientCapture();camera.cullingMask=0;
        var values=new Dictionary<string,List<double>>();var rows=new List<string>{"mode,frame,gpu_ms"};
        try {
            for(int frame=0;frame<40;frame++)foreach(bool capture in new[]{false,true})using(var cb=new CommandBuffer()) {
                // Allocate outside timing, then include the capture's per-render clear in the interval.
                AmbientReflectionCapture.Begin(cb,camera,true);cb.Clear();
                string mode=capture?"Capture-clear-and-ambient-draw":"Ambient-draw";
                var ticket=timer.Reserve(frame,capture?2:1,camera.GetInstanceID(),0);timer.Event(cb,1,ticket);
                if(capture){cb.SetRenderTarget(AmbientReflectionCapture.Get(camera,width,height));cb.ClearRenderTarget(false,true,Color.clear);}
                RecordAmbientCapture(cb,capture,new Color(.3f,.7f,1.7f,.6f));timer.Event(cb,2,ticket);
                camera.AddCommandBuffer(CameraEvent.AfterEverything,cb);
                try {camera.Render();}finally {camera.RemoveCommandBuffer(CameraEvent.AfterEverything,cb);}
                GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                var batch=new GpuTiming.Row[512];int count=timer.Read(batch);
                Check(count==1 && batch[0].Flags==0 && timer.Pending==0,"ambient capture timestamp "+mode+" "+frame);
                double ms=batch[0].Ms;rows.Add(mode+","+frame+","+ms.ToString("G9",CultureInfo.InvariantCulture));
                if(frame>=16){if(!values.ContainsKey(mode))values[mode]=new List<double>();values[mode].Add(ms);}
            }
            File.WriteAllLines("ambient-capture-gpu-timings.csv",rows);
            File.WriteAllLines("ambient-capture-gpu-summary.txt",new[]{SystemInfo.graphicsDeviceName+"; 2560x1440; actual CustomAmbient shader, synthetic G-buffer; interleaved 16 warmup + 24 measured draws per mode; GPU timestamps include capture clear + UAV read/write, exclude later SSR capture sampling and round-trip scratch. Destination clear/additive draw common to both modes."}.Concat(values.Select(kv=>kv.Key+" median_ms="+kv.Value.OrderBy(x=>x).ElementAt(kv.Value.Count/2).ToString("F6",CultureInfo.InvariantCulture))));
        } finally {AmbientReflectionCapture.Dispose();}
    }
}


