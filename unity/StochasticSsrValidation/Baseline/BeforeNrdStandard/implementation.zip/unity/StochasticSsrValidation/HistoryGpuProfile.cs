using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using CustomAmbientResearch;
using OwnershipBaseline=FuckTheseFX.Source.StochasticSSR.HistoryOwnershipBaseline;
using CopyBaseline=FuckTheseFX.Source.StochasticSSR.HistoryCopyBaseline;

public static partial class StochasticSsrValidation
{
    static partial void ProfileHistory() {
        var copyShader=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeHistoryOwnership/Reflection.shader");
        var rows=new List<string>{"change,dataset,region,trial,sample,candidate,stage,gpu_ms"};
        var oldWorld=camera.worldToCameraMatrix;float oldNear=camera.nearClipPlane,oldFar=camera.farClipPlane,oldFov=camera.fieldOfView;
        try {
            foreach(string dataset in new[]{"floor-wall","captured-water","captured-ground"}) {
                camera.nearClipPlane=oldNear;camera.farClipPlane=oldFar;camera.fieldOfView=oldFov;camera.worldToCameraMatrix=oldWorld;camera.ResetProjectionMatrix();Fixture();
                Texture2D mask=null;
                if(dataset!="floor-wall")mask=SetupCapturedReplay(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",dataset=="captured-water"?"20261001-102353-500":"20261001-102702-951"));
                else specular=Texture(specular.GetPixels().Select((v,i)=>new Color(v.r,v.g,v.b,new[]{.2f,.6f,.98f,1f}[i%4])).ToArray());
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer())
                using(var before=new CopyBaseline.ConfidenceSsrPipeline(compute,blend,copyShader,noise,native,gaussian))
                using(var ownership=new OwnershipBaseline.ConfidenceSsrPipeline(compute,blend,AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeHistoryPacking/Reflection.shader"),noise,native,gaussian))
                using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    before.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);ownership.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);
                    cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    var o=Options();o.Smoothness=0;o.Freeze=false;o.Temporal=true;o.CoverageTemporal=true;o.HistoryFrames=16;
                    o.CoverageFullSmoothness=.7f;o.CoverageEndSmoothness=.95f;o.Steps=350;o.ContinuationSamples=350;o.ContinuationPixels=500;o.ContinuationDepth=200;o.GlobalContinuedSky=true;
                    o.CoverageFilter=true;o.CoverageFilterStrength=1;o.CoverageFilterFullSmoothness=.7f;o.CoverageFilterEndSmoothness=.95f;o.CoverageFilterSmoothStrength=.25f;
                    foreach(string change in new[]{"ownership","packing"}) {
                    Action<int> render=i=>{Globals(cb);TodGlobals(cb,.2f);if(change=="ownership" && i==0)before.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);else if(change=="ownership" || i==0)ownership.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);else after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);};
                    foreach(string region in new[]{"root","history-store"})for(int trial=0;trial<3;trial++) {
                        perStage=false;historyOnly=false;completionOutput=null;
                        before.ResetHistory();ownership.ResetHistory();after.ResetHistory();
                        for(int warm=0;warm<32;warm++){render(0);render(1);}Execute(cb);GpuBarrier();
                        perStage=region=="history-store";historyOnly=perStage;
                        for(int first=0;first<40;first+=4) {
                            for(int sample=first;sample<first+4;sample++)foreach(int candidate in (sample+trial)%2==0?new[]{0,1}:new[]{1,0}) {
                                var ticket=timer.Reserve(trial*1000+sample,candidate+1,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"history benchmark timestamp reservation");
                                timer.Event(cb,1,ticket);render(candidate);timer.Event(cb,2,ticket);
                            }
                            Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                            var buffer=new GpuTiming.Row[512];var result=new List<GpuTiming.Row>();int count;
                            while((count=timer.Read(buffer))>0)result.AddRange(buffer.Take(count));
                            Check(result.Count(r=>r.Stage==0)==8 && result.All(r=>r.Flags==0) && timer.Pending==0 && timer.Dropped==0,"history benchmark complete non-disjoint GPU queries");
                            if(perStage)Check(result.Count(r=>r.Stage!=0)==8,"isolated history-store timestamps present");
                            foreach(var r in result) {
                                var root=result.Single(v=>v.Stage==0 && v.Frame==r.Frame && v.Window==r.Window);
                                Check(r.Begin>=root.Begin && r.End<=root.End,"history timestamp contained in its root");
                                string stage=r.Stage==0?"Root":"History store";
                                rows.Add(change+","+dataset+","+region+","+trial+","+(r.Frame%1000)+","+(change=="ownership"?(r.Window==1?"copies":"ping-pong"):(r.Window==1?"ping-pong":"packed"))+","+stage+","+r.Ms.ToString("G9",CultureInfo.InvariantCulture));
                            }
                            File.WriteAllLines("history-gpu.csv",rows);
                        }
                    }
                    }
                }
            }
            File.WriteAllText("history-gpu-method.txt",SystemInfo.graphicsDeviceName+"; D3D11 GPU timestamps; camera 2560x1440; R768; confidence + coverage temporal, 16 frames, mixed smoothness, Custom reconstruction; unchanged 350/350 traversal and 200m separation on both sides. Independent frozen copies versus frozen ownership, then frozen ownership versus packed production. Three trials per change/dataset/region; 32 paired warmups; alternating A/B and B/A order; 40 samples per trial, discard first eight. Root-only trials have no stage instrumentation. Separate history-store trials instrument only that region with no completion-probe draws. Allocations, EXR imports, CPU readbacks and fences outside intervals. Capture-derived inputs and synthetic TOD are not a live raid. External game GPU load may bias absolute timings and variance.\n");
        } finally {perStage=false;historyOnly=false;completionOutput=null;camera.worldToCameraMatrix=oldWorld;camera.nearClipPlane=oldNear;camera.farClipPlane=oldFar;camera.fieldOfView=oldFov;camera.ResetProjectionMatrix();Fixture();}
    }
}
