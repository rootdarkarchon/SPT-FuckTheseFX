using System;
using System.Linq;
using FuckTheseFX.Source.StochasticSSR;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public static partial class StochasticSsrValidation
{
    private static Material captureMaterial;
    private static Mesh captureQuad;
    private static MaterialPropertyBlock captureProperties;
    private static void PrepareAmbientCapture()
    {
        captureMaterial=new Material(AssetDatabase.LoadAssetAtPath<Shader>("Assets/CustomAmbient.shader"));owned.Add(captureMaterial);
        captureMaterial.EnableKeyword("UNITY_HDR_ON");
        captureQuad=new Mesh {vertices=new[]{new Vector3(-1,-1,.1f),new Vector3(1,-1,.1f),new Vector3(-1,1,.1f),new Vector3(1,1,.1f)},triangles=new[]{0,1,3,3,2,0}};owned.Add(captureQuad);
        captureProperties=new MaterialPropertyBlock();
        captureProperties.SetTexture("_CameraDepthTexture",depths);
        captureProperties.SetTexture("_CameraGBufferTexture1",specular);
        captureProperties.SetTexture("_CameraGBufferTexture2",normals);
        // Spatially varying producer visibility catches flipped/shifted capture coordinates.
        captureProperties.SetTexture("_CameraGBufferTexture0",Texture(Enumerable.Range(0,width*height).Select(i=>new Color(0,0,0,.1f+.9f*i/(width*height))).ToArray()));
        captureProperties.SetTexture("_StencilShadow",Texture2D.blackTexture);
        captureProperties.SetTexture("_CameraMotionVectorsDepth",Texture(Enumerable.Range(0,width*height).Select(i=>new Color(i%width<width/2?1:0,0,0,0)).ToArray()));
        var cube=new Cubemap(1,TextureFormat.RGBAFloat,false);owned.Add(cube);
        for(int f=0;f<6;f++)cube.SetPixel((CubemapFace)f,0,0,new Color(.4f,.7f,1.3f,1));cube.Apply();
        captureProperties.SetTexture("_MyGlobalReflectionProbe",cube);
        captureProperties.SetFloat("_ReflectionIntensity",1);captureProperties.SetFloat("_ReflectionBottomShade",2);
        foreach(string sh in new[]{"_SHAr","_SHAg","_SHAb","_SHBr","_SHBg","_SHBb","_SHC"})captureProperties.SetVector(sh,Vector4.zero);
        AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
    }
    private static void RecordAmbientCapture(CommandBuffer cb,bool enabled,Color initial,int draws=1)
    {
        if(enabled)captureMaterial.EnableKeyword("FTFX_REFLECTION_CAPTURE");else captureMaterial.DisableKeyword("FTFX_REFLECTION_CAPTURE");
        cb.EnableShaderKeyword("UNITY_HDR_ON");cb.SetGlobalFloat("_SrcBlend",1);cb.SetGlobalFloat("_DstBlend",1);
        cb.SetRenderTarget(camera.targetTexture);cb.ClearRenderTarget(false,true,initial);
        if(enabled)AmbientReflectionCapture.Begin(cb,camera,true);
        if(enabled)AmbientSurfaceCapture.Begin(cb,camera,true);
        for(int i=0;i<draws;i++)cb.DrawMesh(captureQuad,Matrix4x4.identity,captureMaterial,0,0,captureProperties);
        cb.ClearRandomWriteTargets();cb.SetGlobalFloat("_FTFX_CA_ReflectionCaptureEnabled",0);
    }
    private static Color[] DrawAmbientCapture(bool enabled,Color initial,int draws=1)
    {
        using(var cb=new CommandBuffer()) {
            RecordAmbientCapture(cb,enabled,initial,draws);
            camera.AddCommandBuffer(CameraEvent.AfterEverything,cb);
            try {camera.Render();}finally {camera.RemoveCommandBuffer(CameraEvent.AfterEverything,cb);}
        }
        return Read(camera.targetTexture);
    }
    private static void AmbientCaptureContracts()
    {
        PrepareAmbientCapture();var originalTarget=camera.targetTexture;
        var exactTarget=new RenderTexture(width,height,24,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear);exactTarget.Create();owned.Add(exactTarget);
        camera.targetTexture=exactTarget;camera.cullingMask=0;
        try {
            using(var startup=new CommandBuffer()) {
                Check(AmbientReflectionCapture.Begin(startup,camera,true),"capture can allocate before first camera render");
                Check(Read(AmbientReflectionCapture.Get(camera,width,height)).All(v=>v==Color.clear),"new capture is initialized before first lighting event");
            }
            var producer=DrawAmbientCapture(true,Color.clear);
            var texture=AmbientReflectionCapture.Get(camera,width,height);Check(texture!=null,"exact capture allocated for main HDR deferred camera");
            var captured=Read(texture);
            Check(captured.All(v=>v.a==1),"actual ambient draw writes every capture pixel exactly once");
            Check(captured.Any(v=>v.r>.01f) && captured.All(v=>!float.IsNaN(v.r)),"actual capture contains finite nonzero reflection");
            Check(producer.Select((v,i)=>Mathf.Max(Mathf.Abs(v.r-captured[i].r),Mathf.Abs(v.g-captured[i].g),Mathf.Abs(v.b-captured[i].b))).Max()==0,"FP32 capture equals actual reflection-only producer output at every pixel, including actor and low-AO regions");
            camera.targetTexture=originalTarget;
            var initial=new Color(.319f,.733f,1.791f,.625f);
            var off=DrawAmbientCapture(false,initial);var on=DrawAmbientCapture(true,initial);
            Check(Error(off,on)==0,"capture keyword and UAV leave stored HDR scene RGBA bit-identical");
            var originalAlbedo=captureProperties.GetTexture("_CameraGBufferTexture0");
            var surfaceInput=Enumerable.Range(0,width*height).Select(i=>new Color(.1f+.5f*(i%width)/width,.7f,.2f,.15f)).ToArray();
            captureProperties.SetTexture("_CameraGBufferTexture0",Texture(surfaceInput));
            var surfaceOff=DrawAmbientCapture(true,initial);
            AmbientSurfaceCapture.Requested=()=>true;AmbientSurfaceCapture.IsMainCamera=c=>c==camera;
            var surface=AmbientSurfaceCapture.Get(camera,width,height);
            Check(Read(surface).All(v=>v.a==0),"surface capture initializes invalid before first ambient draw");
            var surfaceOn=DrawAmbientCapture(true,initial);
            Check(Error(surfaceOff,surfaceOn)==0,"surface capture leaves CustomAmbient output unchanged");
            var sampled=Read(surface);
            Check(sampled.Select((v,i)=>Math.Max(Math.Abs(v.r-surfaceInput[i].r),Math.Max(Math.Abs(v.g-surfaceInput[i].g),Math.Abs(v.b-surfaceInput[i].b)))).Max()<.001 && sampled.All(v=>v.a==1),"surface capture records CustomAmbient input albedo, not lit scene or AO alpha");
            captureProperties.SetFloat("_ReflectionIntensity",4);DrawAmbientCapture(true,initial);
            Check(Error(sampled,Read(surface))==0,"surface colour is independent of CustomAmbient reflection intensity");
            camera.Render();Check(Read(surface).All(v=>v.a==0),"missing ambient draw clears stale surface colour");
            AmbientSurfaceCapture.Dispose();captureProperties.SetFloat("_ReflectionIntensity",1);captureProperties.SetTexture("_CameraGBufferTexture0",originalAlbedo);
            DrawAmbientCapture(true,initial);
            var lit=new RenderTexture(width,height,0,RenderTextureFormat.ARGBHalf,RenderTextureReadWrite.Linear);lit.Create();owned.Add(lit);Graphics.CopyTexture(originalTarget,lit);
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();
                o.View=ReflectionView.Normal;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);var normalOutput=Read(originalTarget);
                o.View=ReflectionView.CaptureNormal;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Error(normalOutput,Read(originalTarget))==0,"CaptureNormal reproduces production composite exactly with valid capture");
                o.View=ReflectionView.ExactRoundTrip;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Error(on,Read(originalTarget))==0,"two-pass FP32 remove/re-add reproduces original stored HDR RGBA exactly");
                o.View=ReflectionView.ExactRoundTripError;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                double error=Read(originalTarget).Max(v=>Math.Max(v.r,Math.Max(v.g,v.b)))/10000;
                Check(error<1e-6,"round-trip raw FP32 error before HDR storage: "+error.ToString("G9"));
                o.View=ReflectionView.EnvironmentContribution;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);var nativeTerm=Read(originalTarget);
                o.View=ReflectionView.EnvironmentDifference;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);var delta=Read(originalTarget);captured=Read(texture);
                var receiverSpec=specular.GetPixels();
                Check(delta.Select((v,i)=>Math.Abs(v.r-(receiverSpec[i].a>=o.Smoothness?.5+captured[i].r-nativeTerm[i].r:.5))).Max()<.001,"difference view compares contributions only on the same eligible receivers");
                o.View=ReflectionView.ExactReplacement;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);var replacement=Read(originalTarget);
                o.View=ReflectionView.AddedReflection;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);var added=Read(originalTarget);
                Check(replacement.Select((v,i)=>Math.Abs(v.r-(receiverSpec[i].a>=o.Smoothness?Math.Max(on[i].r-captured[i].r,0)+added[i].r:on[i].r))).Max()<.004,"exact replacement uses captured removal and independently chosen added reflection");
                o.View=ReflectionView.Normal;o.UseCapturedContribution=true;
                Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Error(replacement,Read(originalTarget))==0,"Normal comparison toggle exactly matches captured replacement preview");
                o.View=ReflectionView.AddedReflection;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Error(added,Read(originalTarget))==0,"subtraction toggle leaves added geometry/TOD reflection identical");
                cb.Blit(Texture2D.blackTexture,p.TracePipeline.Record);cb.Blit(Texture2D.blackTexture,p.TracePipeline.Hit);
                o.View=ReflectionView.Normal;p.Reconstruct(cb,camera,lit,originalTarget,o);Execute(cb);var unresolved=Read(originalTarget);
                o.View=ReflectionView.ExactRemovalScene;p.Reconstruct(cb,camera,lit,originalTarget,o);Execute(cb);
                var removedScene=Read(originalTarget);
                o.View=ReflectionView.ReceiverColourFallback;p.Reconstruct(cb,camera,lit,originalTarget,o);Execute(cb);var receiverFallback=Read(originalTarget);
                Check(unresolved.Select((v,i)=>Math.Abs(v.r-removedScene[i].r-receiverFallback[i].r)).Max()<.004,"captured subtraction with unresolved rays adds receiver fallback to masked removal baseline");
                Check(unresolved.Where((v,i)=>receiverSpec[i].a<o.Smoothness).Select((v,j)=>v).Count()>0,"comparison fixture includes excluded receivers");
                Check(unresolved.Select((v,i)=>receiverSpec[i].a>=o.Smoothness?0:Math.Abs(v.r-on[i].r)+Math.Abs(v.g-on[i].g)+Math.Abs(v.b-on[i].b)).Max()==0,"captured comparison leaves excluded receivers unchanged");
                o.UseCapturedContribution=false;
                DrawAmbientCapture(true,initial,2);Check(Read(texture).All(v=>v.a==2),"repeated ambient writes are detected");
                o.View=ReflectionView.Normal;o.UseCapturedContribution=false;
                Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);var nativeFallback=Read(originalTarget);
                o.UseCapturedContribution=true;
                Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Error(nativeFallback,Read(originalTarget))==0,"Normal uses native subtraction on repeated capture instead of magenta");
                o.View=ReflectionView.ExactEnvironmentContribution;Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Read(originalTarget).All(v=>v.r==1 && v.g==0 && v.b==1),"multiple producer writes display magenta instead of claiming exact support");
                DrawAmbientCapture(true,initial,0);Check(Read(texture).All(v=>v==Color.clear),"camera-render clear prevents stale capture after missing producer draw");
                Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Read(originalTarget).All(v=>v.r==0 && v.g==1 && v.b==1),"missing producer writes display cyan");
                o.View=ReflectionView.Normal;
                Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Error(nativeFallback,Read(originalTarget))==0,"Normal uses native subtraction during producer startup instead of cyan");
                DrawAmbientCapture(true,initial);
                Globals(cb);p.Render(cb,camera,lit,originalTarget,o,depths,normals,specular,true);Execute(cb);
                Check(Error(replacement,Read(originalTarget))==0,"captured subtraction resumes automatically after producer recovery");
                AmbientReflectionCapture.IsMainCamera=c=>false;Check(AmbientReflectionCapture.Get(camera,width,height)==null,"other-camera consumer cannot use capture");
                AmbientReflectionCapture.IsMainCamera=c=>c==camera;AmbientReflectionCapture.Requested=()=>false;
                Check(!AmbientReflectionCapture.Begin(cb,camera,true) && AmbientReflectionCapture.Get(camera,width,height)==null,"disabling diagnostic releases capture");
                Check(!camera.GetCommandBuffers(CameraEvent.BeforeLighting).Any(b=>b.name.Contains("reflection capture")),"disabled diagnostic removes its clear command buffer");
            }
            Check(!ShaderUtil.GetShaderMessages(captureMaterial.shader).Any(m=>m.severity.ToString()=="Error"),"executed CustomAmbient capture variant compiles");
        } finally {AmbientSurfaceCapture.Dispose();AmbientReflectionCapture.Dispose();camera.targetTexture=originalTarget;}
    }
}
