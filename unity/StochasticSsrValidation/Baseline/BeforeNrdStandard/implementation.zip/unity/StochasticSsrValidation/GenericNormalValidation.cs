using System;
using System.IO;
using System.Linq;
using BepInEx.Configuration;
using FuckTheseFX.Source.StochasticSSR;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public static partial class StochasticSsrValidation
{
    private static void GenericNormalContracts()
    {
        var oldDepth=depths;var oldNormals=normals;var oldSpec=specular;
        try {
            File.WriteAllText("generic-normal-metrics.csv","shape,samples,original_macro_angle,filtered_macro_angle,animated_samples,original_ray_delta,filtered_ray_delta\n");
            var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
            float Raw(float z){var c=projection*new Vector4(0,0,-z,1);return c.z/c.w;}
            Color Encode(Vector3 n)=>new Color(n.x*.5f+.5f,n.y*.5f+.5f,n.z*.5f+.5f,1);
            Vector3 Vector(Color n)=>new Vector3(n.r,n.g,n.b);
            specular=Texture(Enumerable.Repeat(new Color(.04f,.04f,.04f,1),width*height).ToArray());
            // Rain-like normal detail on ordinary flat geometry. No water
            // producer or water shader is involved in these comparisons.
            Check(WaterReflectionCapture.Get(camera,width,height)==null,"generic normal fixture has no water capture");
            foreach(var shape in new[]{new Vector2Int(128,128),new Vector2Int(96,64)}) {
                string label=shape.x+"x"+shape.y;int tw=shape.x,th=shape.y;
                using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    p.Ensure(width,height,tw,th,RenderTextureFormat.ARGBHalf);
                    var o=Options();o.BypassHitNormal=true;
                    o.WaterTraceStrength=1;
                    var pattern=Enumerable.Range(0,width*height).Select(j=>Encode(new Vector3(.15f+.13f*Mathf.Sin(j%width*2.4f+j/width*1.7f),.06f+.1f*Mathf.Sin(j%width*1.8f-j/width*2.1f),1).normalized)).ToArray();
                    normals=Texture(pattern);depths=Texture(Enumerable.Repeat(new Color(Raw(5),0,0,0),width*height).ToArray());
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var closeRays=Read(p.TracePipeline.Sample);var closeRecords=Read(p.TracePipeline.Record);
                    o.WaterNormals=true;
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(p.TracePipeline.WaterNormalsActive,"generic normal prepass works without water capture: "+label);
                    Check(Error(closeRays,Read(p.TracePipeline.Sample))==0 && Error(closeRecords,Read(p.TracePipeline.Record))==0,"below start distance retains exact high-detail rays: "+label);
                    Check(Read(p.TracePipeline.WaterNormal).All(v=>v.a<0),"near footprint sentinel bypasses normal substitution: "+label);
                    depths=Texture(Enumerable.Repeat(new Color(Raw(150),0,0,0),width*height).ToArray());
                    o.WaterNormals=false;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var farRays=Read(p.TracePipeline.Sample);var farGuides=Read(p.TracePipeline.Hit);
                    o.WaterNormals=true;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var filtered=Read(p.TracePipeline.WaterNormal);var filteredRays=Read(p.TracePipeline.Sample);
                    Check(filtered.Count(v=>v.a>=0)>tw*th*.7,"distant ordinary geometry receives reliable normal support: "+label);
                    Check(Error(farRays,filteredRays)>.01f,"distant rain-like normals alter generic reflection rays: "+label);
                    var guide=Read(p.TracePipeline.Hit);
                    Check(farGuides.Select((v,j)=>v.g==guide[j].g && v.b==guide[j].b && v.a==guide[j].a).All(v=>v),"generic filter preserves original receiver guide and shading normal: "+label);
                    double rawAngular=0,filteredAngular=0;int count=0;
                    var macro=new Vector3(.15f,.06f,1).normalized;
                    for(int y=4;y<th-4;y++)for(int x=4;x<tw-4;x++) {
                        int j=y*tw+x;if(filtered[j].a<0)continue;
                        int source=(int)((y+.5f)*height/th)*width+(int)((x+.5f)*width/tw);
                        rawAngular+=Vector3.Angle(macro,Vector(pattern[source])*2-Vector3.one);
                        filteredAngular+=Vector3.Angle(macro,Vector(filtered[j]));count++;
                    }
                    Check(count>500 && filteredAngular<rawAngular*.65,"distant micro-normal detail reduced while tilted macro normal survives: "+label);
                    double rawDelta=0,filteredDelta=0;int animatedCount=0;
                    Color[] previousRaw=null,previousFiltered=null;
                    for(int frame=0;frame<5;frame++) {
                        normals=Texture(Enumerable.Range(0,width*height).Select(j=>Encode(new Vector3(.15f+.13f*Mathf.Sin(j%width*2.4f+j/width*1.7f+frame*.8f),.06f+.1f*Mathf.Sin(j%width*1.8f-j/width*2.1f-frame*.6f),1).normalized)).ToArray());
                        o.WaterNormals=false;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var animatedRaw=Read(p.TracePipeline.Sample);
                        o.WaterNormals=true;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var animatedFiltered=Read(p.TracePipeline.Sample);
                        if(previousRaw!=null)for(int y=4;y<th-4;y++)for(int x=4;x<tw-4;x++) {
                            int j=y*tw+x;rawDelta+=Vector3.Angle(Vector(animatedRaw[j]),Vector(previousRaw[j]));
                            filteredDelta+=Vector3.Angle(Vector(animatedFiltered[j]),Vector(previousFiltered[j]));animatedCount++;
                        }
                        previousRaw=animatedRaw;previousFiltered=animatedFiltered;
                    }
                    Check(animatedCount>500 && filteredDelta<rawDelta*.65,"animated rain on ordinary geometry reduces ray fluctuation: "+label);
                    File.AppendAllText("generic-normal-metrics.csv",label+","+count+","+rawAngular/count+","+filteredAngular/count+","+animatedCount+","+rawDelta/animatedCount+","+filteredDelta/animatedCount+"\n");
                    normals=Texture(pattern);
                    o.WaterTraceStrength=0;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(!p.TracePipeline.WaterNormalsActive && p.TracePipeline.WaterNormal==null && Error(farRays,Read(p.TracePipeline.Sample))==0,"zero trace strength releases normal target, skips prepass and restores rays: "+label);
                    o.WaterTraceStrength=1;o.NormalStartDistance=300;o.NormalEndDistance=400;
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(Error(farRays,Read(p.TracePipeline.Sample))==0,"configurable start distance moves the detail-preservation region: "+label);
                    o.NormalStartDistance=10;o.NormalEndDistance=100;o.NormalRadius=1;
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var small=Read(p.TracePipeline.WaterNormal);
                    o.NormalRadius=8;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(Error(small,Read(p.TracePipeline.WaterNormal))>.001f,"radius control changes the distant footprint: "+label);
                    // The transition itself, holding scene distance fixed.
                    depths=Texture(Enumerable.Repeat(new Color(Raw(50),0,0,0),width*height).ToArray());
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var intermediate=Read(p.TracePipeline.WaterNormal);
                    o.NormalEndDistance=30;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var maximum=Read(p.TracePipeline.WaterNormal);int middle=(th/2)*tw+tw/2;
                    int sourceMiddle=(int)((th/2+.5f)*height/th)*width+(int)((tw/2+.5f)*width/tw);
                    var original=Vector(pattern[sourceMiddle])*2-Vector3.one;
                    Check(Vector3.Angle(original,Vector(maximum[middle]))>Vector3.Angle(original,Vector(intermediate[middle])),"end distance controls a continuous high-to-low-detail blend: "+label);
                    o.NormalStartDistance=100;o.NormalEndDistance=20;
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(Read(p.TracePipeline.WaterNormal).All(v=>v.a<0),"reversed distance bounds preserve detail until start threshold: "+label);
                    // A foreground object beside the floor must keep its own
                    // coherent normal even with the largest filter footprint.
                    o.NormalStartDistance=0;o.NormalEndDistance=1;o.NormalRadius=16;
                    var normalsAtEdge=Enumerable.Range(0,width*height).Select(j=>Encode(j%width<width/2?Vector3.forward:new Vector3(.6f,0,.8f))).ToArray();
                    normals=Texture(normalsAtEdge);
                    depths=Texture(Enumerable.Range(0,width*height).Select(j=>new Color(Raw(j%width<width/2?5:50),0,0,0)).ToArray());
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var edge=Read(p.TracePipeline.WaterNormal);
                    for(int side=0;side<2;side++) {
                        int x=tw/2+(side==0?-2:2),j=(th/2)*tw+x;
                        var expected=side==0?Vector3.forward:new Vector3(.6f,0,.8f);
                        Check(edge[j].a<0 || Vector3.Angle(Vector(edge[j]),expected)<.02f,"depth discontinuity rejects other object's normals, side="+side+": "+label);
                    }
                    depths=Texture(Enumerable.Repeat(new Color(SystemInfo.usesReversedZBuffer?0:1,0,0,0),width*height).ToArray());
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    Check(Read(p.TracePipeline.WaterNormal).All(v=>v.a<0),"generic filter excludes background depth: "+label);
                }
            }
        } finally {depths=oldDepth;normals=oldNormals;specular=oldSpec;}
    }

}
