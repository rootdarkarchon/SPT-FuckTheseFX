using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using BepInEx;
using CustomAmbientResearch;
using HarmonyLib;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public static partial class StochasticSsrValidation
{
    private static System.Collections.Generic.Dictionary<string,Color[]> InteropSignals(object pipeline)
    {
        var signals=new System.Collections.Generic.Dictionary<string,Color[]>{{"composition",Read(camera.targetTexture)}};
        var trace=AccessTools.Field(pipeline.GetType(),"TracePipeline").GetValue(pipeline);
        foreach(var item in new[]{Tuple.Create("trace",trace,new[]{"Radiance","Hit","HitPoint","Record","TraceInfo","TraceStop","WaterNormal"}),
            Tuple.Create("resolve",pipeline,new[]{"Resolved","DepthGapFilled","History","HistoryStats","HistoryPlane","HistoryGuide","HistoryPoint","HistoryRecord","HistoryMaterial","TemporalStats"}),
            Tuple.Create("fallback",AccessTools.Field(pipeline.GetType(),"ReceiverFallback").GetValue(pipeline),new[]{"Radiance"})})
            foreach(var name in item.Item3){var field=AccessTools.Field(item.Item2.GetType(),name);var texture=(RenderTexture)(field!=null?field.GetValue(item.Item2):AccessTools.Property(item.Item2.GetType(),name).GetValue(item.Item2));if(texture!=null)signals.Add(item.Item1+"/"+name,Read(texture));}
        return signals;
    }
    private static void RunInteropFrames(Assembly assembly,Type pipelineType,Type optionType,MethodInfo render,GpuTiming gpu,int session,
        System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,Color[]>> expected,DeepGpuProfiler deep=null)
    {
        int frame=0;
        var pipeline=Activator.CreateInstance(pipelineType,BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{compute,blend,reflection,noise,native,gaussian},null);
        try {
            using(var cb=new CommandBuffer{name="actual installed FTFX SSR"})
            foreach(int size in new[]{64,128})foreach(int reconstruction in new[]{0,1})foreach(bool temporal in new[]{false,true})foreach(bool stabilize in new[]{false,true}) {
                object options=Activator.CreateInstance(optionType);
                foreach(var field in typeof(FuckTheseFX.Source.StochasticSSR.Options).GetFields(BindingFlags.Instance|BindingFlags.NonPublic)) {
                    var target=optionType.GetField(field.Name,BindingFlags.Instance|BindingFlags.NonPublic);if(target==null)continue;var value=field.GetValue(Options());
                    target.SetValue(options,target.FieldType.IsEnum?Enum.ToObject(target.FieldType,(int)value):value);
                }
                AccessTools.Field(optionType,"WaterNormals").SetValue(options,stabilize);AccessTools.Field(optionType,"WaterTraceStrength").SetValue(options,.85f);
                AccessTools.Field(optionType,"Temporal").SetValue(options,temporal);
                AccessTools.Field(optionType,"Reconstruction").SetValue(options,Enum.ToObject(AccessTools.Field(optionType,"Reconstruction").FieldType,reconstruction));
                AccessTools.Method(pipelineType,"Ensure",new[]{typeof(int),typeof(int),typeof(int),typeof(RenderTextureFormat)}).Invoke(pipeline,new object[]{width,height,size,RenderTextureFormat.ARGBHalf});
                for(int step=0;step<3;step++,frame++) {
                    // Alternate unqueried, coarse and detailed frames while hooks stay installed.
                    bool sampled=gpu!=null&&step>0;ulong probes=gpu?.CompletionProbes??0;cb.Clear();IntPtr ticket=IntPtr.Zero;
                    if(sampled){ticket=gpu.Reserve(frame,session,camera.GetInstanceID(),0,step==1?-1:0);gpu.Event(cb,1,ticket);}
                    ProfilerFrame(pipeline,render,cb,options);if(sampled)gpu.Event(cb,2,ticket);Execute(cb);
                    if(deep!=null && step==2) {
                        var fallback=AccessTools.Field(pipelineType,"ReceiverFallback").GetValue(pipeline);
                        if(AccessTools.Field(fallback.GetType(),"DirectFinalMip")!=null) {
                            var outputs=(System.Collections.IDictionary)AccessTools.Field(typeof(DeepGpuProfiler),"computeOutputs").GetValue(deep);
                            int observed=-1;
                            foreach(System.Collections.DictionaryEntry binding in outputs)
                                if(ReferenceEquals(((ITuple)binding.Key)[0],cb) && ReferenceEquals(((ITuple)binding.Key)[1],gaussian))observed=(int)((ITuple)binding.Value)[1];
                            // NativeGaussian reconstruction runs the same
                            // kernel afterward and leaves a standalone mip-0
                            // destination as the last recorded binding.
                            int expectedMip=reconstruction==0?(int)AccessTools.Property(fallback.GetType(),"MipCount").GetValue(fallback):0;
                            Check(observed==expectedMip,"profiler records the actual final Gaussian UAV mip="+expectedMip);
                        }
                    }
                    var current=InteropSignals(pipeline);
                    if(session==0)expected.Add(current);
                    else Check(current.Keys.OrderBy(k=>k).SequenceEqual(expected[frame].Keys.OrderBy(k=>k))&&current.All(s=>Error(s.Value,expected[frame][s.Key])==0),
                        "installed SSR exact signal/resource parity session="+session+" frame="+frame+" size="+size+" reconstruction="+reconstruction+" temporal="+temporal+" normals="+stabilize);
                    var trace=AccessTools.Field(pipelineType,"TracePipeline").GetValue(pipeline);
                    Check((bool)AccessTools.Property(trace.GetType(),"WaterNormalsActive").GetValue(trace)==stabilize&&
                        (((RenderTexture)AccessTools.Field(trace.GetType(),"WaterNormal").GetValue(trace)!=null)==stabilize),"normal buffer lifetime agrees with enabled flag");
                    if(gpu!=null){gpu.Immediate(3);Read(camera.targetTexture);gpu.Immediate(4);Read(camera.targetTexture);
                        var rows=new GpuTiming.Row[1024];int count=gpu.Read(rows);
                        Check(sampled?count>0&&rows.Take(count).All(r=>r.Flags==0):count==0,"profiler interval coverage/flags");
                        Check(step==2?gpu.CompletionProbes>probes:gpu.CompletionProbes==probes,"completion probes only in detailed frame");
                    }
                }
            }
            if(gpu!=null)Check(gpu.Pending==0&&gpu.Dropped==0&&gpu.CompletionFailures==0,"profiler session drains without completion failures");
        } finally {((IDisposable)pipeline).Dispose();}
    }
    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void ProfilerFrame(object pipeline, MethodInfo render, CommandBuffer cb, object options)
    {
        Globals(cb);
        render.Invoke(pipeline,new object[]{cb,camera, new RenderTargetIdentifier(scene),new RenderTargetIdentifier(camera.targetTexture),options,
            (RenderTargetIdentifier?)new RenderTargetIdentifier(depths),(RenderTargetIdentifier?)new RenderTargetIdentifier(normals),
            (RenderTargetIdentifier?)new RenderTargetIdentifier(specular),false});
    }
    public static void RunProfilerInterop()
    {
        try {
            AccessTools.Property(typeof(Paths),"BepInExConfigPath").SetValue(null,Path.GetFullPath("BepInEx-test.cfg"));
            AccessTools.Property(typeof(Paths),"ConfigPath").SetValue(null,Directory.GetCurrentDirectory());
            AccessTools.Property(typeof(Paths),"BepInExRootPath").SetValue(null,Path.GetFullPath("Capture-test"));
            compute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/HiZ.compute");blend=AssetDatabase.LoadAssetAtPath<Shader>("Assets/Support.shader");reflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/Reflection.shader");
            noise=new Texture2D(128,128,TextureFormat.RG16,false,true){filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Repeat};owned.Add(noise);
            noise.LoadRawTextureData(File.ReadAllBytes("Assets/AMD/BlueNoise.bytes"));noise.Apply();
            var gamePath=File.ReadAllText("game-path.txt").Trim();
            game=AssetBundle.LoadFromFile(Path.Combine(gamePath,"EscapeFromTarkov_Data/StreamingAssets/Windows/shaders"));
            native=game.LoadAllAssets<Shader>().Single(s=>s.name=="Hidden/PostProcessing/ScreenSpaceReflections");
            gaussian=game.LoadAllAssets<ComputeShader>().First(c=>c.name.IndexOf("Gaussian",StringComparison.OrdinalIgnoreCase)>=0);
            var go=new GameObject("SSR profiler interoperability");owned.Add(go);camera=go.AddComponent<Camera>();camera.enabled=false;
            camera.renderingPath=RenderingPath.DeferredShading;camera.allowHDR=true;camera.nearClipPlane=.1f;camera.farClipPlane=500;camera.fieldOfView=65;
            rendererType=AccessTools.TypeByName("UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer");
            var factory=new UnityEngine.Rendering.PostProcessing.PropertySheetFactory();var context=Context(factory);context.command.Dispose();factory.Release();Fixture();
            var dll=File.Exists("ftfx-dll-path.txt")?File.ReadAllText("ftfx-dll-path.txt").Trim():Path.Combine(gamePath,"BepInEx/plugins/FuckTheseFX/FuckTheseFX.dll");
            var assembly=Assembly.LoadFile(dll);
            var pipelineType=assembly.GetType("FuckTheseFX.Source.StochasticSSR.ConfidenceSsrPipeline",true);
            var optionType=assembly.GetType("FuckTheseFX.Source.StochasticSSR.Options",true);
            var render=AccessTools.Method(pipelineType,"Render");
            var expected=new System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,Color[]>>();
            // Freeze the unpatched baseline before any profiler is installed.
            RunInteropFrames(assembly,pipelineType,optionType,render,null,0,expected);
            for(int session=1;session<=2;session++) {
                var gpu=new GpuTiming();gpu.Initialize(Path.GetFullPath("Native/CustomAmbientGpu.dll"),GpuTiming.StageCapacity);
                var profiler=new SceneGpuProfiler(camera,gpu);var deep=new DeepGpuProfiler(profiler,camera,gpu,false);profiler.Deep=deep;
                try {
                    deep.InstallRecordingRoot(AccessTools.Method(typeof(StochasticSsrValidation),nameof(ProfilerFrame)),null);
                    var samples=assembly.GetType("FuckTheseFX.Source.StochasticSSR.SsrGpuSample",true);
                    deep.InstallSamples(AccessTools.Constructor(samples,new[]{typeof(CommandBuffer),typeof(string)}));deep.InstallSamples(AccessTools.Method(samples,"Dispose"));
                    foreach(var pair in new[]{new[]{"SsrPipeline","Trace"},new[]{"NativeReceiverFallback","Render"},new[]{"NativeReflectionReconstruction","Render"}})
                        deep.InstallCompute(AccessTools.Method(assembly.GetType("FuckTheseFX.Source.StochasticSSR."+pair[0],true),pair[1]));
                    RunInteropFrames(assembly,pipelineType,optionType,render,gpu,session,expected,deep);
                } finally {profiler.Dispose();gpu.Dispose();}
            }
            RunInteropFrames(assembly,pipelineType,optionType,render,null,3,expected);
            File.WriteAllLines("profiler-interop-validation.txt",checks);
        } catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);throw;}
        finally {foreach(var o in owned)if(o!=null)UnityEngine.Object.DestroyImmediate(o);if(game!=null)game.Unload(true);}
    }
}


