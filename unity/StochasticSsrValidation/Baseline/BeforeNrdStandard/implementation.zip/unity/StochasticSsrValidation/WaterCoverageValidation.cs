using System;
using System.IO;
using System.Linq;
using FuckTheseFX.Source.StochasticSSR;
using HarmonyLib;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public static partial class StochasticSsrValidation
{
    private sealed class NativeWaterDrawFixture
    {
        internal CommandBuffer Buffer;internal Mesh Mesh;internal Material Material;
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        public void method_2(Camera camera)
        {
            Buffer.SetRenderTarget(new[]{new RenderTargetIdentifier(BuiltinRenderTextureType.GBuffer0)},BuiltinRenderTextureType.CameraTarget);
            Buffer.DrawMesh(Mesh,Matrix4x4.identity,Material,0,0,new MaterialPropertyBlock());
            Buffer.SetRenderTarget(BuiltinRenderTextureType.CameraTarget,BuiltinRenderTextureType.ResolvedDepth);
            Buffer.DrawMesh(Mesh,Matrix4x4.identity,Material,0,1);
        }
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        public void RenderBuffer(CommandBuffer buffer,Camera camera)
        {
            buffer.SetRenderTarget(new[]{new RenderTargetIdentifier(BuiltinRenderTextureType.GBuffer0)},BuiltinRenderTextureType.CameraTarget);
            buffer.DrawMesh(Mesh,Matrix4x4.identity,Material,0,0);
            buffer.SetRenderTarget(BuiltinRenderTextureType.CameraTarget,BuiltinRenderTextureType.ResolvedDepth);
            buffer.DrawMesh(Mesh,Matrix4x4.identity,Material,0,1);
        }
    }
    private static void WaterCameraOrdering(Shader shader,Mesh mesh)
    {
        var oldTarget=camera.targetTexture;var oldMask=camera.cullingMask;var oldMode=camera.depthTextureMode;
        var target=new RenderTexture(width,height,24,RenderTextureFormat.ARGBHalf);target.Create();owned.Add(target);
        var bed=GameObject.CreatePrimitive(PrimitiveType.Quad);bed.layer=31;bed.transform.position=new Vector3(0,0,8);bed.transform.localScale=Vector3.one*30;
        var standard=new Material(Shader.Find("Standard"));bed.GetComponent<Renderer>().sharedMaterial=standard;
        var writer=new Material(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCaptureFixture.shader"));
        var patch=new Harmony("ftfx.water.capture.fixture");var render=AccessTools.Method(typeof(NativeWaterDrawFixture),"method_2");
        try {
            camera.targetTexture=target;camera.cullingMask=1<<31;camera.depthTextureMode=DepthTextureMode.Depth;
            using(var capture=new WaterReflectionCapture(shader,false){Requested=()=>true,IsMainCamera=c=>c==camera})
            using(var cb=new CommandBuffer{name="native water draw fixture"}) {
                // PostProcessLayer builds the SSR consumer in OnPreCull before
                // native Camera.onPreCull water callbacks can record the producer.
                var observed=new RenderTexture(width,height,0,RenderTextureFormat.RGFloat);observed.Create();owned.Add(observed);
                var early=WaterReflectionCapture.Get(camera,width,height);
                using(var consumer=new CommandBuffer{name="SSR recorded before water"}) {
                consumer.Blit(early!=null?(Texture)early:Texture2D.blackTexture,observed);
                camera.AddCommandBuffer(CameraEvent.BeforeImageEffectsOpaque,consumer);
                try {
                patch.Patch(render,transpiler:new HarmonyMethod(typeof(WaterReflectionCapture),nameof(WaterReflectionCapture.ObserveDraws)));
                var fixture=new NativeWaterDrawFixture{Buffer=cb,Mesh=mesh,Material=writer};
                var v2=AccessTools.Method(typeof(NativeWaterDrawFixture),"RenderBuffer");
                patch.Patch(v2,transpiler:new HarmonyMethod(typeof(WaterReflectionCapture),nameof(WaterReflectionCapture.ObserveDraws)));
                render.Invoke(fixture,new object[]{camera});
                v2.Invoke(fixture,new object[]{cb,camera}); // A later owner must not overwrite opaque depth with water depth.
                camera.AddCommandBuffer(CameraEvent.BeforeReflections,cb);
                try {
                    camera.Render();
                    var mask=WaterReflectionCapture.Get(camera,width,height);
                    Check(mask!=null,"camera render retains water capture for SSR");
                    var entry=AccessTools.Method(typeof(WaterReflectionCapture),"Prepare").Invoke(capture,new object[]{camera});
                    var bottom=(RenderTexture)AccessTools.Field(entry.GetType(),"Bottom").GetValue(entry);
                    var pixels=Read(mask);var beds=Read(bottom);
                    Check(Read(observed).Count(v=>Math.Abs(v.r-5)<.002)>100,"SSR recorded before native water binds the current GPU capture instead of black");
                    Check(pixels.Count(v=>Math.Abs(v.r-5)<.002)>100,"patched native draw emits visible water coverage with camera depth test");
                    Check(Math.Abs(beds[width*(height/2)+width/2].r-8)<.02,"native boundary snapshot retains opaque bed across v3 and v2 resolved-depth writes");
                    bed.transform.position=new Vector3(0,0,3);camera.Render();
                    Check(Read(mask).All(v=>v.r==0),"foreground geometry occludes water mask through real camera depth test");
                    bed.transform.position=new Vector3(0,0,8);
                    // A render with no issued water draw must clear all old coverage.
                    cb.Clear();camera.Render();Check(Read(mask).All(v=>v.r==0),"no-water camera render clears previous coverage");
                    Check(Read(observed).All(v=>v.r==0),"early-bound SSR consumer sees cleared coverage when no water draws");
                }finally{camera.RemoveCommandBuffer(CameraEvent.BeforeReflections,cb);}
                }finally{camera.RemoveCommandBuffer(CameraEvent.BeforeImageEffectsOpaque,consumer);}
                }
            }
        } finally {
            patch.UnpatchSelf();camera.targetTexture=oldTarget;camera.cullingMask=oldMask;camera.depthTextureMode=oldMode;
            UnityEngine.Object.DestroyImmediate(bed);UnityEngine.Object.DestroyImmediate(standard);UnityEngine.Object.DestroyImmediate(writer);
        }
    }
    private static void WaterDistanceCoverage(Shader shader)
    {
        var oldPosition=camera.transform.position;var oldRotation=camera.transform.rotation;
        var oldNear=camera.nearClipPlane;var oldFar=camera.farClipPlane;
        var oldTarget=camera.targetTexture;var oldMask=camera.cullingMask;
        var target=new RenderTexture(width,height,24,RenderTextureFormat.ARGBHalf);target.Create();owned.Add(target);
        var observed=new RenderTexture(width,height,0,RenderTextureFormat.RFloat);observed.Create();owned.Add(observed);
        var water=new Mesh();owned.Add(water);
        water.vertices=new[]{new Vector3(-2000,0,1),new Vector3(-2000,0,1500),new Vector3(2000,0,1500),new Vector3(2000,0,1)};
        water.triangles=new[]{0,1,2,0,2,3};
        var full=new Mesh();owned.Add(full);full.vertices=new[]{new Vector3(-1,-1),new Vector3(-1,3),new Vector3(3,-1)};full.triangles=new[]{0,1,2};
        var writer=new Material(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCaptureFixture.shader"));owned.Add(writer);
        var reader=new Material(shader);owned.Add(reader);
        try {
            camera.targetTexture=target;camera.cullingMask=0;camera.nearClipPlane=.01f;camera.farClipPlane=2000;
            camera.transform.rotation=Quaternion.Euler(4,0,0);
            using(var capture=new WaterReflectionCapture(shader,false){Requested=()=>true,IsMainCamera=c=>c==camera})
            using(var draws=new CommandBuffer())using(var read=new CommandBuffer()) {
                var mask=WaterReflectionCapture.Get(camera,width,height);
                camera.AddCommandBuffer(CameraEvent.BeforeReflections,draws);camera.AddCommandBuffer(CameraEvent.BeforeImageEffectsOpaque,read);
                try {
                    read.SetGlobalFloat("_FTFXWaterBottomCaptured",0);
                    read.SetGlobalTexture("_WaterSourceDepth",BuiltinRenderTextureType.ResolvedDepth);
                    read.SetRenderTarget(observed);read.DrawMesh(full,Matrix4x4.identity,reader,0,0);
                    foreach(float offset in new[]{0f,1500f})foreach(float heightAbove in new[]{2f,12f,40f}) {
                        camera.transform.position=new Vector3(offset,heightAbove,offset);
                        draws.Clear();
                        AccessTools.Method(typeof(WaterReflectionCapture),"Targets").Invoke(null,new object[]{draws,new[]{new RenderTargetIdentifier(BuiltinRenderTextureType.GBuffer0)},new RenderTargetIdentifier(BuiltinRenderTextureType.CameraTarget),camera});
                        AccessTools.Method(typeof(WaterReflectionCapture),"Draw").Invoke(null,new object[]{draws,water,Matrix4x4.Translate(new Vector3(offset,0,offset)),writer,0,0,camera});
                        draws.SetRenderTarget(BuiltinRenderTextureType.CameraTarget,BuiltinRenderTextureType.ResolvedDepth);
                        draws.DrawMesh(water,Matrix4x4.Translate(new Vector3(offset,0,offset)),writer,0,1);
                        camera.Render();var masks=Read(mask);var depthsNow=Read(observed);
                        int covered=0,missing=0,rejected=0;
                        for(int y=2;y<height-2;y++)for(int x=2;x<width-2;x++) {
                            int k=y*width+x;float eye=depthsNow[k].r;
                            if(eye<2 || eye>1200)continue;
                            covered++;if(masks[k].r<=0)missing++;
                            else if(Math.Abs(eye-masks[k].r)>Math.Max(.005f,eye*.0001f))rejected++;
                        }
                        Check(covered>100,"distance mask fixture contains native water height="+heightAbove);
                        if(rejected>0)Debug.Log("Water depth disagreement: "+string.Join("; ",depthsNow.Select((v,k)=>new{eye=v.r,mask=masks[k].r}).Where(v=>v.eye>2 && v.eye<1200 && v.mask>0 && Math.Abs(v.eye-v.mask)>Math.Max(.005f,v.eye*.0001f)).Take(8).Select(v=>v.eye+" / "+v.mask)));
                        Check(missing==0 && rejected==0,"continuous visible water mask offset="+offset+" height="+heightAbove+" missing="+missing+" rejected="+rejected);
                    }
                }finally{camera.RemoveCommandBuffer(CameraEvent.BeforeReflections,draws);camera.RemoveCommandBuffer(CameraEvent.BeforeImageEffectsOpaque,read);}
            }
        }finally{camera.transform.position=oldPosition;camera.transform.rotation=oldRotation;camera.nearClipPlane=oldNear;camera.farClipPlane=oldFar;camera.targetTexture=oldTarget;camera.cullingMask=oldMask;}
    }
}
