using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using Before=FuckTheseFX.Source.StochasticSSR.ContinuationOptimizationBaseline;

public static partial class StochasticSsrValidation
{
    private static Before.Options CandidateOptions(Options options)
    {
        object value=new Before.Options();
        foreach(var field in typeof(Options).GetFields(System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance)) {
            var target=typeof(Before.Options).GetField(field.Name,System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);
            if(target==null)continue;var item=field.GetValue(options);target.SetValue(value,target.FieldType.IsEnum?Enum.ToObject(target.FieldType,(int)item):item);
        }
        return (Before.Options)value;
    }
    private static void ContinuationOptimizationContracts()
    {
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeContinuationOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeContinuationOptimization/Reflection.shader");
        Check(oldCompute!=null && oldReflection!=null,"pre-trace-optimization baseline frozen separately from release assets");
        File.WriteAllText("continuation-optimization-parity.csv","temporal,normals,reconstruction,frame,raw,records,cost,stop,normal,resolve,fill,composition\n");
        foreach(bool temporal in new[]{false,true})foreach(bool stabilize in new[]{false,true})
        foreach(var reconstruction in Enum.GetValues(typeof(ReflectionReconstruction)).Cast<ReflectionReconstruction>()) {
            using(var cb=new CommandBuffer())using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                before.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);
                var o=Options();o.Temporal=temporal;o.WaterNormals=stabilize;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.BypassHitNormal=true;
                o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.Reconstruction=reconstruction;
                for(int frame=0;frame<3;frame++) {
                    Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,CandidateOptions(o),depths,normals,specular,true);Execute(cb);var image=Read(camera.targetTexture);
                    Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    double[] errors={Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance)),Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record)),
                        Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo)),Error(Read(before.TracePipeline.TraceStop),Read(after.TracePipeline.TraceStop)),
                        stabilize?Error(Read(before.TracePipeline.WaterNormal),Read(after.TracePipeline.WaterNormal)):0,Error(Read(before.Resolved),Read(after.Resolved)),
                        Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled)),Error(image,Read(camera.targetTexture))};
                    Check(errors.Take(7).All(e=>e==0) && EquivalentComposition(image,Read(camera.targetTexture)),"trace optimization baseline parity temporal="+temporal+" normals="+stabilize+" reconstruction="+reconstruction+" frame="+frame+" errors="+string.Join(",",errors));
                    Check(Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 && Error(Read(before.TracePipeline.HitPoint),Read(after.TracePipeline.HitPoint))==0 &&
                        Error(Read(before.TracePipeline.Sample),Read(after.TracePipeline.Sample))==0 && Error(Read(before.TracePipeline.DepthHit),Read(after.TracePipeline.DepthHit))==0 &&
                        (!temporal || (Error(Read(before.History),Read(after.History))==0 && Error(Read(before.HistoryStats),Read(after.HistoryStats))==0)),
                        "trace optimization baseline retains exact hit geometry, ray/PDF, confidence factors and measured history");
                    File.AppendAllText("continuation-optimization-parity.csv",temporal+","+stabilize+","+reconstruction+","+frame+","+string.Join(",",errors)+"\n");
                }
                Check(after.TracePipeline.Depth[0].width==width && after.TracePipeline.Depth[0].height==height,"Hi-Z starts at camera extent without power-of-two padding");
                for(int level=1;level<after.TracePipeline.Depth.Count;level++) {
                    var a=after.TracePipeline.Depth[level-1];var b=after.TracePipeline.Depth[level];
                    Check(b.width==(a.width+1)/2 && b.height==(a.height+1)/2,"Hi-Z partial cells use ceiling reduction level "+level);
                }
                if(!temporal)Check(after.History==null && after.Temporal==null && after.HistoryPlane==null && after.TemporalStats==null,"temporal-off does not allocate history or statistics targets");
                o.Temporal=!temporal;Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                Check(o.Temporal?after.History!=null:after.History==null,"temporal resources follow live toggle");
            }
        }
        CandidateOddExtent();
        CandidateTraversalStress();
        CandidateStateConsumers();CandidateSpecificContracts();
    }
    private static void CandidateOddExtent()
    {
        int originalWidth=width,originalHeight=height;
        try {
            width=259;height=145;Fixture();
            var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeContinuationOptimization/HiZ.compute");
            var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeContinuationOptimization/Reflection.shader");
            foreach(bool bypass in new[]{false,true})using(var cb=new CommandBuffer())
            using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                before.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);
                var o=Options();o.BypassHitNormal=bypass;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;
                o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
                Globals(cb);before.Render(cb,camera,scene,camera.targetTexture,CandidateOptions(o),depths,normals,specular,true);Execute(cb);var image=Read(camera.targetTexture);
                Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 && Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 &&
                    Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"odd rectangular camera retains ray/coverage/continuation semantics with bypass="+bypass);
                Check(before.TracePipeline.Depth.Count==after.TracePipeline.Depth.Count,"unpadded hierarchy retains traversal level count");
                for(int level=0;level<after.TracePipeline.Depth.Count;level++) {
                    var a=before.TracePipeline.Depth[level];var b=after.TracePipeline.Depth[level];var av=Read(a);var bv=Read(b);
                    Check(Enumerable.Range(0,bv.Length).All(j=>bv[j].r==av[j/b.width*a.width+j%b.width].r),"odd partial Hi-Z edge equals old far-padded minimum at level "+level);
                }
            }
        } finally {width=originalWidth;height=originalHeight;Fixture();}
    }
    // Exercise arbitrary raster/trace aspect, animated wet normals, foreground
    // occlusion, sky, active range/continuation limits and reused output targets.
    private static void CandidateTraversalStress()
    {
        int ow=width,oh=height;var projection=camera.projectionMatrix;
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeContinuationOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeContinuationOptimization/Reflection.shader");
        try {
            width=259;height=145;Fixture();
            foreach(bool late in new[]{false,true})foreach(bool diagnostics in new[]{false,true})
            foreach(int scenario in new[]{0,1,2,3})using(var cb=new CommandBuffer())
            using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                int size=scenario==3?128:64;before.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
                var o=Options();o.Freeze=false;o.Temporal=true;o.BypassHitNormal=scenario!=2;o.WaterNormals=scenario!=1;o.WaterTraceStrength=.85f;o.NormalRadius=4;
                o.Steps=scenario==1?3:515;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.ContinuationSamples=scenario==2?3:557;
                o.ContinuationPixels=scenario==2?6:500;o.ContinuationDepth=scenario==2?1:50;
                o.LimitNativeRange=false;o.Distance=250; // Historical hit-range parity is replaced by ReceiverRangeContracts.
                for(int frame=0;frame<3;frame++) {
                    camera.projectionMatrix=projection;
                    var jitter=projection;jitter.m02+=(frame-1)*.8f/width;jitter.m12+=(1-frame)*.6f/height;
                    camera.projectionMatrix=jitter;
                    var gpu=GL.GetGPUProjectionMatrix(jitter,false);var d=new Color[width*height];var n=new Color[d.Length];var s=new Color[d.Length];var c=new Color[d.Length];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
                        int i=y*width+x;bool sky=y>height*3/4;bool foreground=x>width/3 && x<width/2 && y>height/3 && y<height*3/4;
                        float z=foreground?2:20+y*.3f+(float)Math.Sin(x*.06)*3;
                        var clip=gpu*new Vector4(0,0,-z,1);d[i]=new Color(sky?(SystemInfo.usesReversedZBuffer?0:1):clip.z/clip.w,0,0,0);
                        var normal=new Vector3((float)Math.Sin(x*.7+frame)*.12f,1,(float)Math.Cos(y*.6+frame)*.12f).normalized;
                        if(foreground)normal=Vector3.forward;
                        n[i]=i%997==0?Color.clear:new Color(normal.x*.5f+.5f,normal.y*.5f+.5f,normal.z*.5f+.5f,1);
                        s[i]=new Color(.04f,.06f,.08f,foreground?.3f:i%5==0?1:.92f);
                        c[i]=new Color(.1f+x*.005f,.2f+y*.01f,foreground?2:.4f,1);
                    }
                    depths=Texture(d);normals=Texture(n);specular=Texture(s);scene=Texture(c);
                    if(late) {
                        before.PrepareRaster(camera,1,width,height);before.TracePipeline.Raster.FinalizeRaster(camera);
                        after.PrepareRaster(camera,1,width,height);after.TracePipeline.Raster.FinalizeRaster(camera);
                    }
                    Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,CandidateOptions(o),depths,normals,specular,diagnostics);Execute(cb);var image=Read(camera.targetTexture);
                    Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,diagnostics);Execute(cb);
                    Check(Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 && Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 &&
                        Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 && Error(Read(before.TracePipeline.HitPoint),Read(after.TracePipeline.HitPoint))==0 &&
                        Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo))==0 && Error(Read(before.TracePipeline.TraceStop),Read(after.TracePipeline.TraceStop))==0,
                        "exact traversal stress late="+late+" diagnostics="+diagnostics+" scenario="+scenario+" frame="+frame);
                    Check(Error(Read(before.Resolved),Read(after.Resolved))==0 && Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled))==0 &&
                        Error(Read(before.History),Read(after.History))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"stress preserves measured/fill/history and composition");
                    if(diagnostics)Check(Error(Read(before.TracePipeline.Sample),Read(after.TracePipeline.Sample))==0 && Error(Read(before.TracePipeline.DepthHit),Read(after.TracePipeline.DepthHit))==0,"stress diagnostics preserve sampled rays and hit confidence");
                    if(late){before.TracePipeline.Raster.Commit();after.TracePipeline.Raster.Commit();}
                }
            }
        } finally {camera.ResetProjectionMatrix();width=ow;height=oh;Fixture();}
    }
    private static Color[] ReadMip(RenderTexture texture,int mip)
    {
        var request=AsyncGPUReadback.Request(texture,mip,TextureFormat.RGBAFloat);request.WaitForCompletion();
        Check(!request.hasError,"fallback mip readback "+mip);return request.GetData<Color>().ToArray();
    }
    private static void CandidateSpecificContracts()
    {
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeContinuationOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeContinuationOptimization/Reflection.shader");
        foreach(var extent in new[]{new Vector2Int(32,20),new Vector2Int(128,96),new Vector2Int(768,768),new Vector2Int(1024,1024),new Vector2Int(1536,1536)})
        foreach(bool temporal in new[]{false,true})using(var cb=new CommandBuffer())
        using(var before=new Before.NativeReceiverFallback(native,gaussian))using(var after=new NativeReceiverFallback(native,gaussian)) {
            before.Ensure(extent.x,extent.y);after.Ensure(extent.x,extent.y);
            for(int frame=0;frame<3;frame++) {
                Globals(cb);before.Render(cb,scene,.5f,temporal);after.Render(cb,scene,.5f,temporal);Execute(cb);
                for(int level=0;level<=after.MipCount;level++)Check(Error(ReadMip(before.Radiance,level),ReadMip(after.Radiance,level))==0,
                    "direct final fallback mip exact native filtering "+extent+" temporal="+temporal+" frame="+frame+" level="+level);
            }
        }
        using(var cb=new CommandBuffer())using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
        using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            before.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);
            var o=Options();o.Freeze=true;o.BypassHitNormal=true;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
            foreach(int steps in new[]{1,32,515,1024}) {
                o.Steps=steps;Globals(cb);before.Render(cb,camera,scene,camera.targetTexture,CandidateOptions(o),depths,normals,specular);Execute(cb);var image=Read(camera.targetTexture);
                Globals(cb);after.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);after.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                Check(Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 && Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 &&
                    Error(Read(before.TracePipeline.TraceStop),Read(after.TracePipeline.TraceStop))==0 && Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo))==0 &&
                    EquivalentComposition(image,Read(camera.targetTexture)),"work diagnostics retain exact tracing and rendered signal cap="+steps);
                var work=Read(after.TracePipeline.Sample);var topology=Read(after.TracePipeline.DepthHit);var records=Read(after.TracePipeline.Record);var info=Read(after.TracePipeline.TraceInfo);
                Check(work.Any(v=>v.a==1 && v.r>0) && work.All(v=>v.r>=0 && v.r<=steps && v.g<=v.r && v.b<=v.r),"all termination work counters bounded and eligible cap="+steps);
                Check(Enumerable.Range(0,work.Length).All(i=>records[i].a!=1 || work[i].r==Mathf.Round(records[i].b*steps)),"successful-hit work equals existing traversal fraction cap="+steps);
                Check(Enumerable.Range(0,work.Length).All(i=>records[i].a!=0 || records[i].b!=8 || work[i].r==steps),"budget-exhausted rays retain complete iteration count cap="+steps);
                Check(topology.All(v=>v.g>=0 && v.g<=16383 && v.r<=steps) && after.TracePipeline.DepthHit.format==RenderTextureFormat.ARGBFloat,"mip masks retain exact integer bits");
                if(steps==515) {
                    string folder="traversal-fixture";Directory.CreateDirectory(folder);
                    ContinuationCapture.SaveTraversal(folder,work,topology,records,info,96);
                    Check(File.ReadAllLines(Path.Combine(folder,"traversal-rays.csv")).Length==work.Length+1,"work capture exports every ray, including excluded receivers");
                }
            }
            Globals(cb);after.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,false);Execute(cb);
            Check(after.TracePipeline.DepthHit.format==RenderTextureFormat.ARGBHalf,"diagnostic mode restores accepted-depth format");
            Globals(cb);after.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,false);Execute(cb);
            Check(after.TracePipeline.Sample==null && after.TracePipeline.DepthHit==null,"ordinary rendering has no traversal diagnostic targets");
        }
        foreach(var group in new[]{new Vector2Int(16,8),new Vector2Int(16,16)}) {
            string path="Assets/Trace"+group.x+"x"+group.y+".compute";
            var shaderSource=File.ReadAllText("Assets/BeforeContinuationOptimization/HiZ.compute");
            shaderSource=System.Text.RegularExpressions.Regex.Replace(shaderSource,@"\[numthreads\(8,8,1\)\](\s*void Trace\()","[numthreads("+group.x+","+group.y+",1)]$1");
            File.WriteAllText(path,shaderSource);AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
            var groupCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
            using(var cb=new CommandBuffer())using(var normal=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))
            using(var candidate=new ConfidenceSsrPipeline(groupCompute,blend,reflection,noise,native,gaussian)) {
                normal.Ensure(width,height,97,65,RenderTextureFormat.ARGBHalf);candidate.Ensure(width,height,97,65,RenderTextureFormat.ARGBHalf);
                var o=Options();o.Freeze=true;o.BypassHitNormal=true;o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
                Globals(cb);normal.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);var image=Read(camera.targetTexture);
                Globals(cb);candidate.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(Error(Read(normal.TracePipeline.Record),Read(candidate.TracePipeline.Record))==0 && Error(Read(normal.TracePipeline.Radiance),Read(candidate.TracePipeline.Radiance))==0 &&
                    Error(Read(normal.TracePipeline.TraceInfo),Read(candidate.TracePipeline.TraceInfo))==0 && Error(Read(normal.TracePipeline.TraceStop),Read(candidate.TracePipeline.TraceStop))==0 &&
                    Error(Read(normal.TracePipeline.HitPoint),Read(candidate.TracePipeline.HitPoint))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"group shape keeps exact seeds/rays/state and partial tiles "+group);
                Check(!ShaderUtil.GetComputeShaderMessages(groupCompute).Any(m=>m.severity.ToString()=="Error"),"experimental group shader compiles "+group);
            }
        }
    }
    private static void CandidateStateConsumers()
    {
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforeContinuationOptimization/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforeContinuationOptimization/Reflection.shader");
        using(var cb=new CommandBuffer())using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
        using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            before.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
            var o=Options();o.BypassHitNormal=true;o.Steps=515;
            foreach(int mode in new[]{0,1,2,3,0}) {
                o.Temporal=mode==1;o.View=mode==2?ReflectionView.HitDepthDistance:ReflectionView.Normal;bool diagnostics=mode==3;
                Globals(cb);before.Render(cb,camera,scene,camera.targetTexture,CandidateOptions(o),depths,normals,specular,diagnostics);Execute(cb);var image=Read(camera.targetTexture);
                Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,diagnostics);Execute(cb);
                Check(Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 && Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 &&
                    Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 && Error(Read(before.Resolved),Read(after.Resolved))==0 &&
                    Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"state consumer toggle retains exact rendered signal mode="+mode);
                var oldPoint=Read(before.TracePipeline.HitPoint);var newPoint=Read(after.TracePipeline.HitPoint);var record=Read(after.TracePipeline.Record);
                Check(Error(oldPoint,newPoint)==0,"all consumers retain complete hit geometry mode="+mode);
            }
        }
    }
}


