using System;
using System.Linq;
using FuckTheseFX.Source.StochasticSSR;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.PostProcessing;

public static partial class StochasticSsrValidation
{
    private static void NativeReconstructionContracts()
    {
        var input=new RenderTexture(32,24,0,RenderTextureFormat.ARGBHalf,RenderTextureReadWrite.Linear);
        var output=new RenderTexture(16,12,0,RenderTextureFormat.ARGBHalf,RenderTextureReadWrite.Linear) {enableRandomWrite=true};
        input.Create();output.Create();
        try {
            using(var cb=new CommandBuffer()) {
                cb.SetRenderTarget(input);cb.ClearRenderTarget(false,true,new Color(4,.5f,2,.25f));
                int k=gaussian.FindKernel("KMain");
                cb.SetComputeTextureParam(gaussian,k,"_Source",input);
                cb.SetComputeTextureParam(gaussian,k,"_Result",output);
                cb.SetComputeVectorParam(gaussian,"_Size",new Vector4(16,12,1f/16,1f/12));
                cb.DispatchCompute(gaussian,k,2,2,1);Execute(cb);
                var result=Read(output);
                Debug.Log("Native Gaussian constant RGBA: "+result[0]+" / "+result[result.Length-1]);
                Check(result.All(v=>Mathf.Abs(v.r-4)<.01f && Mathf.Abs(v.g-.5f)<.01f && Mathf.Abs(v.b-2)<.01f && Mathf.Abs(v.a-.25f)<.002f),"installed native Gaussian preserves HDR premultiplied RGB and independent coverage alpha including partial tiles");
            }
        } finally {input.Release();output.Release();UnityEngine.Object.DestroyImmediate(input);UnityEngine.Object.DestroyImmediate(output);}
        using(var cb=new CommandBuffer())using(var reconstruction=new NativeReflectionReconstruction(gaussian)) {
            foreach(var size in new[]{new Vector2Int(23,17),new Vector2Int(64,40),new Vector2Int(256,256),new Vector2Int(768,768),new Vector2Int(1368,768)}) {
                var source=new RenderTexture(size.x,size.y,0,RenderTextureFormat.ARGBHalf,RenderTextureReadWrite.Linear);source.Create();
                try {
                    reconstruction.Ensure(size.x,size.y);
                    cb.SetRenderTarget(source);cb.ClearRenderTarget(false,true,new Color(.5f,1,2,.25f));
                    reconstruction.Render(cb,source);Execute(cb);
                    for(int mip=0;mip<=reconstruction.MipCount;mip++) {
                        var readback=AsyncGPUReadback.Request(reconstruction.Signal,mip,TextureFormat.RGBAFloat);readback.WaitForCompletion();
                        Check(!readback.hasError && readback.GetData<Color>().All(v=>Mathf.Abs(v.r-.5f)<.002f && Mathf.Abs(v.g-1)<.002f && Mathf.Abs(v.b-2)<.002f && Mathf.Abs(v.a-.25f)<.002f),"native signal mip preserves HDR/coverage including rectangular tail: "+size+" mip="+mip);
                    }
                } finally {source.Release();UnityEngine.Object.DestroyImmediate(source);}
            }
            reconstruction.Signal.Release();reconstruction.Ensure(64,40);
            Check(reconstruction.Signal.IsCreated() && reconstruction.Signal.width==64 && reconstruction.Signal.height==40,"native reconstruction recreates lost/resized resources");
        }
        var oldDepth=depths;var oldNormal=normals;var oldSpec=specular;var oldScene=scene;
        var factory=new PropertySheetFactory();var sheet=factory.Get(native);
        try {
            var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);var clip=projection*new Vector4(0,0,-5,1);
            depths=Texture(Enumerable.Repeat(new Color(clip.z/clip.w,0,0,0),width*height).ToArray());
            normals=Texture(Enumerable.Repeat(new Color(.5f,.5f,1,1),width*height).ToArray());
            scene=Texture(Enumerable.Repeat(Color.clear,width*height).ToArray());
            sheet.properties.SetMatrix("_InverseProjectionMatrix",projection.inverse);sheet.properties.SetMatrix("_InverseViewMatrix",camera.cameraToWorldMatrix);
            sheet.properties.SetFloat("_CutOffThreshold",.5f);
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,64,40,RenderTextureFormat.ARGBHalf);var o=Options();
                specular=Texture(Enumerable.Repeat(new Color(.04f,.06f,.08f,1),width*height).ToArray());
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                var trace=p.TracePipeline;
                o.Reconstruction=ReflectionReconstruction.NativeGaussian;o.FallbackStrength=0;
                foreach(float smooth in new[]{.55f,.8f,.98f,1f}) {
                    
                    specular=Texture(Enumerable.Repeat(new Color(.04f,.06f,.08f,smooth),width*height).ToArray());
                    var raw=new Color[64*40];var guides=new Color[raw.Length];
                    for(int j=0;j<raw.Length;j++) {
                        int x=j%64,y=j/64;float c=(x<16?0:x<40?.25f:1);
                        raw[j]=new Color(x%8<4?4:.1f,y%6<3?2:.2f,.5f,.7f);guides[j]=new Color(c,5,0,0);
                    }
                    Globals(cb);cb.Blit(Sized(raw,64,40),trace.Radiance);cb.Blit(Sized(guides,64,40),trace.Hit);
                    cb.Blit(Solid(new Color(0,0,-8,smooth)),trace.HitPoint);cb.Blit(Solid(new Color(0,0,0,1)),trace.Record);
                    p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                    var actual=Read(camera.targetTexture);var frozenRaw=Read(trace.Radiance);var frozenRecords=Read(trace.Record);
                    Check(Error(Read(p.Resolved),Read(p.NativeReconstruction.Signal))<.004,"native mip zero preserves denoised resolved signal and fractional coverage: "+"Custom"+" s="+smooth);
                    // Native's final pass treats reflection RGB as already-resolved
                    // colour. With zero scene/removal/fallback, this directly
                    // checks LOD, bilinear/trilinear sampling and material energy.
                    sheet.properties.SetVector("_Params",new Vector4(0,0,0,p.NativeReconstruction.MipCount));
                    Globals(cb);cb.SetGlobalFloat("_SSRFactor",0);cb.SetGlobalTexture("_Resolve",p.NativeReconstruction.Signal);
                    RuntimeUtilities.BlitFullscreenTriangle(cb,scene,camera.targetTexture,sheet,3);Execute(cb);
                    var expected=Read(camera.targetTexture);
                    float error=actual.Select((v,j)=>Mathf.Max(Mathf.Abs(v.r-expected[j].r),Mathf.Abs(v.g-expected[j].g),Mathf.Abs(v.b-expected[j].b))).Max();
                    Check(error<.003,"native reconstruction sampling/energy matches installed final pass on zero/partial/full coverage: "+"Custom"+" s="+smooth+" error="+error);
                    Check(Error(frozenRaw,Read(trace.Radiance))==0 && Error(frozenRecords,Read(trace.Record))==0,"native reconstruction preserves raw trace radiance and classification: "+"Custom"+" s="+smooth);
                }
                o.Temporal=true;
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(Error(Read(p.History),Read(p.Temporal))==0,"native display Gaussian output never enters custom pre-spatial history");
                o.Reconstruction=ReflectionReconstruction.Custom;
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(p.NativeReconstruction==null && !p.UsedHistory,"switching back to custom releases native resources and invalidates history");
            }
        } finally {factory.Release();depths=oldDepth;normals=oldNormal;specular=oldSpec;scene=oldScene;}
    }
}
