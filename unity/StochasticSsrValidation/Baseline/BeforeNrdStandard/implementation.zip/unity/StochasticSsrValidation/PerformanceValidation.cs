using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using FuckTheseFX.Source.StochasticSSR;
using Before=FuckTheseFX.Source.StochasticSSR.PerformanceBaseline;

public static partial class StochasticSsrValidation
{
    // Shader specialization can change the last ARGBHalf rounding bit. Keep
    // trace/coverage/history exact; permit at most ~one half ULP in composition.
    private static bool EquivalentComposition(Color[] before,Color[] after)
    {
        return before.Zip(after,(a,b)=>Enumerable.Range(0,4).All(c=>Math.Abs(a[c]-b[c])<=Math.Max(.0005,Math.Max(Math.Abs(a[c]),Math.Abs(b[c]))*.001))).All(v=>v);
    }
    private static Before.Options PerformanceOptions(Options options)
    {
        object value=new Before.Options();
        foreach(var field in typeof(Options).GetFields(System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance)) {
            var target=typeof(Before.Options).GetField(field.Name,System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);
            if(target==null)continue;var item=field.GetValue(options);target.SetValue(value,target.FieldType.IsEnum?Enum.ToObject(target.FieldType,(int)item):item);
        }
        return (Before.Options)value;
    }
    private static void PerformanceContracts()
    {
        var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforePerformance/HiZ.compute");
        var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforePerformance/Reflection.shader");
        Check(oldCompute!=null && oldReflection!=null,"pre-performance baseline frozen separately from release assets");
        File.WriteAllText("performance-parity.csv","temporal,normals,reconstruction,frame,raw,records,cost,stop,normal,resolve,fill,composition\n");
        foreach(bool temporal in new[]{false,true})foreach(bool stabilize in new[]{false,true})
        foreach(var reconstruction in Enum.GetValues(typeof(ReflectionReconstruction)).Cast<ReflectionReconstruction>()) {
            using(var cb=new CommandBuffer())using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                before.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);
                var o=Options();o.Temporal=temporal;o.WaterNormals=stabilize;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.BypassHitNormal=true;
                o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.Thickness=1;o.ThicknessConfidenceFloor=1;o.Reconstruction=reconstruction;
                for(int frame=0;frame<3;frame++) {
                    Globals(cb);TodGlobals(cb,.2f);before.Render(cb,camera,scene,camera.targetTexture,PerformanceOptions(o),depths,normals,specular,true);Execute(cb);var image=Read(camera.targetTexture);
                    Globals(cb);TodGlobals(cb,.2f);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    double[] errors={Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance)),Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record)),
                        Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo)),Error(Read(before.TracePipeline.TraceStop),Read(after.TracePipeline.TraceStop)),
                        stabilize?Error(Read(before.TracePipeline.WaterNormal),Read(after.TracePipeline.WaterNormal)):0,Error(Read(before.Resolved),Read(after.Resolved)),
                        Error(Read(before.DepthGapFilled),Read(after.DepthGapFilled)),Error(image,Read(camera.targetTexture))};
                    Check(errors.Take(7).All(e=>e==0) && EquivalentComposition(image,Read(camera.targetTexture)),"performance baseline parity temporal="+temporal+" normals="+stabilize+" reconstruction="+reconstruction+" frame="+frame+" errors="+string.Join(",",errors));
                    Check(Error(Read(before.TracePipeline.Hit),Read(after.TracePipeline.Hit))==0 && Error(Read(before.TracePipeline.HitPoint),Read(after.TracePipeline.HitPoint))==0 &&
                        Error(Read(before.TracePipeline.Sample),Read(after.TracePipeline.Sample))==0 && Error(Read(before.TracePipeline.DepthHit),Read(after.TracePipeline.DepthHit))==0 &&
                        (!temporal || (Error(Read(before.History),Read(after.History))==0 && Error(Read(before.HistoryStats),Read(after.HistoryStats))==0)),
                        "performance baseline retains exact hit geometry, ray/PDF, confidence factors and measured history");
                    File.AppendAllText("performance-parity.csv",temporal+","+stabilize+","+reconstruction+","+frame+","+string.Join(",",errors)+"\n");
                }
                Check(after.TracePipeline.Depth[0].width==width && after.TracePipeline.Depth[0].height==height,"Hi-Z starts at camera extent without power-of-two padding");
                for(int level=1;level<after.TracePipeline.Depth.Count;level++) {
                    var a=after.TracePipeline.Depth[level-1];var b=after.TracePipeline.Depth[level];
                    Check(b.width==(a.width+1)/2 && b.height==(a.height+1)/2,"Hi-Z partial cells use ceiling reduction level "+level);
                }
                if(!temporal)Check(after.History==null && after.Temporal==null && after.HistoryPlane==null && after.TemporalStats==null,"temporal-off does not allocate history or statistics targets");
                o.Temporal=!temporal;Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                Check(o.Temporal?after.History!=null:after.History==null,"temporal resources follow live toggle");
            }
        }
        PerformanceOddExtent();
    }
    private static void PerformanceOddExtent()
    {
        int originalWidth=width,originalHeight=height;
        try {
            width=259;height=145;Fixture();
            var oldCompute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/BeforePerformance/HiZ.compute");
            var oldReflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/BeforePerformance/Reflection.shader");
            foreach(bool bypass in new[]{false,true})using(var cb=new CommandBuffer())
            using(var before=new Before.ConfidenceSsrPipeline(oldCompute,blend,oldReflection,noise,native,gaussian))
            using(var after=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                before.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);after.Ensure(width,height,96,64,RenderTextureFormat.ARGBHalf);
                var o=Options();o.BypassHitNormal=bypass;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;
                o.Steps=515;o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;
                Globals(cb);before.Render(cb,camera,scene,camera.targetTexture,PerformanceOptions(o),depths,normals,specular,true);Execute(cb);var image=Read(camera.targetTexture);
                Globals(cb);after.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                Check(Error(Read(before.TracePipeline.Record),Read(after.TracePipeline.Record))==0 && Error(Read(before.TracePipeline.Radiance),Read(after.TracePipeline.Radiance))==0 &&
                    Error(Read(before.TracePipeline.TraceInfo),Read(after.TracePipeline.TraceInfo))==0 && EquivalentComposition(image,Read(camera.targetTexture)),"odd rectangular camera retains ray/coverage/continuation semantics with bypass="+bypass);
                Check(before.TracePipeline.Depth.Count==after.TracePipeline.Depth.Count,"unpadded hierarchy retains traversal level count");
                for(int level=0;level<after.TracePipeline.Depth.Count;level++) {
                    var a=before.TracePipeline.Depth[level];var b=after.TracePipeline.Depth[level];var av=Read(a);var bv=Read(b);
                    Check(Enumerable.Range(0,bv.Length).All(j=>bv[j].r==av[j/b.width*a.width+j%b.width].r),"odd partial Hi-Z edge equals old far-padded minimum at level "+level);
                }
            }
        } finally {width=originalWidth;height=originalHeight;Fixture();}
    }
}

