using System;
using System.Linq;
using FuckTheseFX.Source.StochasticSSR;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.PostProcessing;
using HarmonyLib;

public static partial class StochasticSsrValidation
{
    private static void ZeroSmoothnessProbeContracts()
    {
        var oldDepth=depths;var oldNormal=normals;var oldSpec=specular;var oldScene=scene;var oldOcclusion=materialOcclusion;
        var requested=AmbientReflectionCapture.Requested;var mainCamera=AmbientReflectionCapture.IsMainCamera;
        var cube=new Cubemap(1,TextureFormat.RGBAFloat,false);owned.Add(cube);var probe=new Color(.7f,.9f,1.2f,1);
        for(int face=0;face<6;face++)cube.SetPixel((CubemapFace)face,0,0,probe);cube.Apply();
        var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);var clip=projection*new Vector4(0,0,-5,1);
        try {
            depths=Texture(Enumerable.Range(0,width*height).Select(j=>new Color(j/width<4?(SystemInfo.usesReversedZBuffer?0:1):clip.z/clip.w,0,0,0)).ToArray());
            normals=Texture(Enumerable.Range(0,width*height).Select(j=>j/width==4?Color.clear:new Color(.5f,1,.5f,1)).ToArray());
            specular=Texture(Enumerable.Range(0,width*height).Select(j=>j%width<width/3?new Color(.08f,.12f,.2f,0):j%width<2*width/3?Color.clear:new Color(.08f,.12f,.2f,.001f)).ToArray());
            scene=Texture(Enumerable.Repeat(new Color(1,2,3,.6f),width*height).ToArray());var source=scene.GetPixels();
            bool Selected(int j)=>j%width<width/3 && j/width>4;
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();o.SupportSmoothness=0;o.Smoothness=.5f;
                o.LimitNativeRange=true;o.Distance=1; // Probe replacement also applies to receivers excluded from SSR.
                Action bind=()=>{Globals(cb);cb.SetGlobalTexture("_MyGlobalReflectionProbe",cube);cb.SetGlobalTexture("_StencilShadow",Solid(new Color(0,0,0,.4f)));cb.SetGlobalFloat("_ReflectionBottomShade",2);};
                materialOcclusion=Texture(Enumerable.Repeat(new Color(1,1,1,0),width*height).ToArray());
                o.LimitNativeRange=false;bind();p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                var before=Read(p.TracePipeline.Record);var beforeWork=Read(p.TracePipeline.Sample);
                o.ZeroSmoothnessProbe=true;bind();p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                var after=Read(p.TracePipeline.Record);var work=Read(p.TracePipeline.Sample);var raw=Read(p.TracePipeline.Radiance);
                int Receiver(int j)=>Math.Min((int)((j/128+.5f)*height/128),height-1)*width+Math.Min((int)((j%128+.5f)*width/128),width-1);
                Check(Enumerable.Range(0,after.Length).Where(j=>Selected(Receiver(j))).All(j=>after[j]==Color.clear && work[j]==Color.clear && raw[j]==Color.clear),"probe-only receivers bypass GGX eligibility and traversal with zero radiance");
                Check(Enumerable.Range(0,after.Length).Where(j=>!Selected(Receiver(j))).All(j=>after[j]==before[j] && work[j]==beforeWork[j]),"zero specular and positive smoothness keep the original tracing path");
                o.View=ReflectionView.MaterialWeight;bind();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var response=Read(camera.targetTexture);
                o.View=ReflectionView.Normal;o.LimitNativeRange=true;
                foreach(var backend in new[]{ReflectionReconstruction.Custom,ReflectionReconstruction.NativeGaussian})
                foreach(float alpha in new[]{0f,.5f,1f}) {
                    materialOcclusion=Texture(Enumerable.Repeat(new Color(1,1,1,alpha),width*height).ToArray());o.Reconstruction=backend;
                    o.ZeroSmoothnessProbe=false;bind();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var unchanged=Read(camera.targetTexture);o.ZeroSmoothnessProbe=true;
                    foreach(float strength in new[]{0f,.25f,1f}) {
                        o.ZeroSmoothnessProbeStrength=strength;bind();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var image=Read(camera.targetTexture);
                        Check(Enumerable.Range(0,image.Length).Where(Selected).All(j=>{
                            var e=new Color(probe.r*response[j].r*.6f,probe.g*response[j].g*.6f,probe.b*response[j].b*.6f,0);
                            var expected=new Color(Mathf.Max(0,source[j].r-alpha*e.r)+strength*e.r,Mathf.Max(0,source[j].g-alpha*e.g)+strength*e.g,Mathf.Max(0,source[j].b-alpha*e.b)+strength*e.b,source[j].a);
                            return MaxRGBError(image[j],expected)<.003f && Mathf.Abs(image[j].a-source[j].a)<.001f;
                        }),"probe replacement respects material, stencil, attenuation, alpha and single subtraction "+backend+" alpha="+alpha+" strength="+strength);
                        Check(Enumerable.Range(0,image.Length).Where(j=>!Selected(j)).All(j=>MaxRGBError(image[j],unchanged[j])<.002f),"probe replacement preserves zero-specular, positive-smoothness, sky and invalid-normal receivers");
                    }
                }
                materialOcclusion=Texture(Enumerable.Repeat(new Color(1,1,1,0),width*height).ToArray());
                o.ZeroSmoothnessProbeStrength=.3f;o.ZeroSmoothnessProbeClose=.1f;
                foreach(var backend in new[]{ReflectionReconstruction.Custom,ReflectionReconstruction.NativeGaussian})
                foreach(var interval in new[]{new Vector2(5,15),new Vector2(4,6),new Vector2(6,6),new Vector2(7,5)}) {
                    o.Reconstruction=backend;o.ZeroSmoothnessProbeFadeStart=interval.x;o.ZeroSmoothnessProbeFadeEnd=interval.y;
                    bind();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var faded=Read(camera.targetTexture);
                    Check(Enumerable.Range(0,faded.Length).Where(Selected).All(j=>{
                        var h=projection.inverse*new Vector4(((j%width+.5f)/width)*2-1,((j/width+.5f)/height)*2-1,.5f,1);
                        float distance=(new Vector3(h.x,h.y,h.z)*(5/-h.z)).magnitude;
                        float t=interval.y>interval.x?Mathf.Clamp01((distance-interval.x)/(interval.y-interval.x)):(distance>=interval.x?1:0);
                        if(interval.y>interval.x)t=t*t*(3-2*t);
                        float strength=Mathf.Lerp(.1f,.3f,t);
                        var e=new Color(probe.r*response[j].r*.6f,probe.g*response[j].g*.6f,probe.b*response[j].b*.6f,0);
                        return MaxRGBError(faded[j],source[j]+strength*e)<.003f && Mathf.Abs(faded[j].a-source[j].a)<.001f;
                    }),"probe distance fade uses radial receiver distance and deterministic endpoints "+backend+" "+interval);
                }
                o.ZeroSmoothnessProbeClose=0;o.ZeroSmoothnessProbeFadeStart=0;o.ZeroSmoothnessProbeFadeEnd=0;
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                Check(AmbientReflectionCapture.Begin(cb,camera,true),"probe replacement accepts exact ambient capture");
                cb.ClearRandomWriteTargets();cb.Blit(Solid(new Color(.03f,.04f,.05f,1)),AmbientReflectionCapture.Get(camera,width,height));Execute(cb);
                o.UseCapturedContribution=true;o.ZeroSmoothnessProbeStrength=0;bind();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                Check(Read(camera.targetTexture).Select((v,j)=>!Selected(j) || MaxRGBError(v,source[j]-new Color(.03f,.04f,.05f,0))<.003f).All(v=>v),"zero probe strength subtracts the actual captured contribution once");
                o.ZeroSmoothnessProbe=false;o.UseCapturedContribution=false;o.LimitNativeRange=false;bind();p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                Check(Error(before,Read(p.TracePipeline.Record))==0 && Error(beforeWork,Read(p.TracePipeline.Sample))==0,"disabling probe experiment restores original traces exactly");
                var changed=o;changed.ZeroSmoothnessProbe=true;Check(!o.SameRendering(changed),"probe toggle resets measured history");
                changed=o;changed.ZeroSmoothnessProbeStrength=.37f;Check(!o.SameRendering(changed),"probe contribution changes reset measured history");
                changed=o;changed.ZeroSmoothnessProbeClose=.2f;Check(!o.SameRendering(changed),"close probe contribution changes reset measured history");
                changed=o;changed.ZeroSmoothnessProbeFadeStart=5;Check(!o.SameRendering(changed),"probe fade start changes reset measured history");
                changed=o;changed.ZeroSmoothnessProbeFadeEnd=15;Check(!o.SameRendering(changed),"probe fade end changes reset measured history");
            }
        } finally {AccessTools.Method(typeof(AmbientReflectionCapture),"Release").Invoke(null,new object[]{camera});AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=mainCamera;depths=oldDepth;normals=oldNormal;specular=oldSpec;scene=oldScene;materialOcclusion=oldOcclusion;}
    }
    private static void ReceiverCutoffContracts()
    {
        var oldDepth=depths;var oldNormal=normals;var oldSpec=specular;var oldScene=scene;
        var requested=AmbientReflectionCapture.Requested;var mainCamera=AmbientReflectionCapture.IsMainCamera;
        var cube=new Cubemap(1,TextureFormat.RGBAFloat,false);owned.Add(cube);
        for(int face=0;face<6;face++)cube.SetPixel((CubemapFace)face,0,0,new Color(.7f,.9f,1.2f,1));cube.Apply();
        var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);var clip=projection*new Vector4(0,0,-5,1);
        try {
            depths=Texture(Enumerable.Range(0,width*height).Select(j=>new Color(j/width<4?(SystemInfo.usesReversedZBuffer?0:1):clip.z/clip.w,0,0,0)).ToArray());
            normals=Texture(Enumerable.Repeat(new Color(.5f,.9f,.8f,1),width*height).ToArray());
            specular=Texture(Enumerable.Range(0,width*height).Select(j=>new Color(.08f,.12f,.2f,j%width<width/2?.3f:.9f)).ToArray());
            scene=Texture(Enumerable.Range(0,width*height).Select(j=>j%width<width/4?new Color(.001f,.002f,.003f,.6f):new Color(.5f,.7f,.9f,.6f)).ToArray());
            var source=scene.GetPixels();var sp=specular.GetPixels();var ao=Texture(Enumerable.Repeat(Color.white,width*height).ToArray());
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();o.Smoothness=.5f;o.SupportSmoothness=0;o.View=ReflectionView.EnvironmentRemovedScene;
                Action bind=()=>{Globals(cb);cb.SetGlobalTexture("_MyGlobalReflectionProbe",cube);cb.SetGlobalTexture("_CameraGBufferTexture0",ao);cb.SetGlobalTexture("_StencilShadow",Texture2D.blackTexture);cb.SetGlobalFloat("_SSRFactor",1);cb.SetGlobalFloat("_ReflectionBottomShade",2);};
                bind();p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);var removed=Read(camera.targetTexture);
                Check(Enumerable.Range(width*4,width*(height-4)).Any(j=>sp[j].a<.5f && Math.Abs(removed[j].r-source[j].r)>.01f),"cutoff fixture has nonzero environment subtraction on rough receivers");
                AmbientReflectionCapture.Requested=()=>true;AmbientReflectionCapture.IsMainCamera=c=>c==camera;
                Check(AmbientReflectionCapture.Begin(cb,camera,true),"cutoff fixture supplies valid captured subtraction distinct from native removal");
                cb.ClearRandomWriteTargets();cb.Blit(Solid(new Color(.33f,.11f,.22f,1)),AmbientReflectionCapture.Get(camera,width,height));Execute(cb);
                Color[] retained=null;
                foreach(var reconstruction in new[]{ReflectionReconstruction.Custom,ReflectionReconstruction.NativeGaussian})
                foreach(float blendValue in new[]{0f,.37f,1f})foreach(bool captured in new[]{false,true})foreach(float fallback in new[]{0f,1f}) {
                    o.View=ReflectionView.Normal;o.Reconstruction=reconstruction;o.CutoffEnvironmentBlend=blendValue;o.UseCapturedContribution=captured;o.FallbackStrength=fallback;
                    bind();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var image=Read(camera.targetTexture);
                    Check(image.Select((v,j)=>sp[j].a>=.5f || MaxRGBError(v,Color.LerpUnclamped(removed[j],source[j],blendValue))<.002f).All(v=>v),"cutoff source-scene blend matches debug endpoint without SSR/fallback "+reconstruction+"/"+blendValue+" capture="+captured+" fallback="+fallback);
                    Check(image.Select((v,j)=>Math.Abs(v.a-source[j].a)<.001f).All(v=>v),"cutoff preserves scene alpha");
                    if(!captured && fallback==0 && reconstruction==ReflectionReconstruction.Custom) {
                        if(retained==null)retained=image;
                        else Check(image.Select((v,j)=>sp[j].a<.5f || v.Equals(retained[j])).All(v=>v),"cutoff blend does not change eligible receiver composition");
                    }
                }
                o.SupportSmoothness=.4f;o.CutoffEnvironmentBlend=0;bind();p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                Check(Read(camera.targetTexture).Select((v,j)=>sp[j].a>=.4f || MaxRGBError(v,source[j])<.002f).All(v=>v),"cutoff retains native unsupported-region protection");
            }
        } finally {AccessTools.Method(typeof(AmbientReflectionCapture),"Release").Invoke(null,new object[]{camera});AmbientReflectionCapture.Requested=requested;AmbientReflectionCapture.IsMainCamera=mainCamera;depths=oldDepth;normals=oldNormal;specular=oldSpec;scene=oldScene;}
    }
    private static float MaxRGBError(Color a,Color b)=>Mathf.Max(Mathf.Abs(a.r-b.r),Mathf.Max(Mathf.Abs(a.g-b.g),Mathf.Abs(a.b-b.b)));

    private static Vector3 ReceiverPosition(int pixel,float eye,Matrix4x4 inverse) {
        var h=inverse*new Vector4(((pixel%width)+.5f)*2/width-1,((pixel/width)+.5f)*2/height-1,.5f,1);
        return new Vector3(h.x,h.y,h.z)*(eye/-h.z);
    }
    private static void ReceiverRangeContracts()
    {
        var oldDepth=depths;var oldProjection=camera.projectionMatrix;
        System.IO.File.WriteAllText("receiver-range-fixture-work.csv","trace_width,trace_height,jitter,reconstruction,range,eligible,iterations,post_continuation\n");
        // Scale the existing floor/wall fixture: receivers stay near enough to
        // trace, while the wall is a legitimate source more than 250m away.
        var z=oldDepth.GetPixels();float far=camera.farClipPlane,near=camera.nearClipPlane;
        float za=SystemInfo.usesReversedZBuffer?(far/near-1)/far:(1-far/near)/far,zb=SystemInfo.usesReversedZBuffer?1/far:1/near;
        float[] eye=z.Select(v=>50/(za*v.r+zb)).ToArray();
        try {
            foreach(bool jitter in new[]{false,true})foreach(var shape in new[]{new Vector2Int(128,128),new Vector2Int(96,64)})
            foreach(var reconstruction in new[]{ReflectionReconstruction.Custom,ReflectionReconstruction.NativeGaussian})
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                camera.projectionMatrix=oldProjection;var projection=oldProjection;if(jitter){projection.m02+=.7f/width;projection.m12-=.6f/height;}camera.projectionMatrix=projection;
                var gpu=GL.GetGPUProjectionMatrix(projection,false);depths=Texture(eye.Select(v=>{var clip=gpu*new Vector4(0,0,-v,1);return new Color(clip.z/clip.w,0,0,0);}).ToArray());
                p.Ensure(width,height,shape.x,shape.y,RenderTextureFormat.ARGBHalf);
                var o=Options();o.Steps=515;o.BypassHitNormal=true;o.WaterNormals=true;o.WaterTraceStrength=.85f;o.NormalRadius=4;o.Reconstruction=reconstruction;o.Distance=250;
                o.ContinuationSamples=557;o.ContinuationPixels=500;o.ContinuationDepth=50;o.CutoffEnvironmentBlend=.37f;
                Globals(cb);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                var baseline=Read(p.TracePipeline.Record);var raw=Read(p.TracePipeline.Radiance);var hits=Read(p.TracePipeline.HitPoint);var work=Read(p.TracePipeline.Sample);var normal=Read(p.TracePipeline.WaterNormal);
                var depth=Read(p.TracePipeline.Depth[0]);var positions=Enumerable.Range(0,width*height).Select(j=>ReceiverPosition(j,depth[j].r,gpu.inverse)).ToArray();
                int Receiver(int j)=>Math.Min((int)((j/shape.x+.5f)*height/shape.y),height-1)*width+Math.Min((int)((j%shape.x+.5f)*width/shape.x),width-1);
                var distance=Enumerable.Range(0,baseline.Length).Select(j=>positions[Receiver(j)].magnitude).ToArray();
                o.LimitNativeRange=true;Globals(cb);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true,false,true);Execute(cb);
                var limited=Read(p.TracePipeline.Record);var limitedWork=Read(p.TracePipeline.Sample);var limitedRaw=Read(p.TracePipeline.Radiance);var limitedNormal=Read(p.TracePipeline.WaterNormal);
                Check(limitedWork.Select((v,j)=>distance[j]<=250.01f || (v.r==0 && v.g==0 && v.b==0 && v.a==0 && limited[j].a==0 && limited[j].b==0)).All(v=>v),"distant receiver rejection precedes eligibility/GGX/traversal "+shape+" jitter="+jitter);
                Check(Enumerable.Range(0,baseline.Length).Where(j=>distance[j]<249.99f).All(j=>baseline[j].Equals(limited[j]) && raw[j].Equals(limitedRaw[j]) && work[j].Equals(limitedWork[j]) && normal[j].Equals(limitedNormal[j])),"eligible rays, normal-filter donors and budgets unchanged by receiver range "+shape+" jitter="+jitter);
                Check(Enumerable.Range(0,baseline.Length).Any(j=>distance[j]<249.99f && limited[j].a==1 && (new Vector3(hits[j].r,hits[j].g,hits[j].b)-positions[Receiver(j)]).magnitude>250),"near receivers reflect geometry over 250m away "+shape+" jitter="+jitter);
                Check(Enumerable.Range(0,baseline.Length).Any(j=>distance[j]>250.01f && -positions[Receiver(j)].z<250 && baseline[j].a!=0),"radial range rejects off-centre receivers whose eye depth is under 250m");
                foreach(var entry in new[]{new {Range=0,Work=work},new {Range=250,Work=limitedWork}})
                    System.IO.File.AppendAllText("receiver-range-fixture-work.csv",shape.x+","+shape.y+","+jitter+","+reconstruction+","+entry.Range+","+entry.Work.Sum(v=>(long)v.a)+","+entry.Work.Sum(v=>(long)v.r)+","+entry.Work.Sum(v=>(long)v.g)+"\n");
                Check(limitedWork.Sum(v=>(double)v.r)<work.Sum(v=>(double)v.r),"receiver eligibility removes actual executed traversal work");
                Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);var composed=Read(camera.targetTexture);
                o.View=ReflectionView.EnvironmentRemovedScene;Globals(cb);p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var removed=Read(camera.targetTexture);var source=scene.GetPixels();
                Check(composed.Select((v,j)=>positions[j].magnitude<=250.01f || MaxRGBError(v,Color.LerpUnclamped(removed[j],source[j],.37f))<.003f).All(v=>v),"full-resolution range exclusion prevents reconstruction leakage and uses existing cutoff composition "+reconstruction);
                o.View=ReflectionView.Normal;o.LimitNativeRange=false;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
                Check(Read(p.TracePipeline.Record).Any(v=>v.a==1),"disabling range restores distant receiver tracing");
            }
        } finally {depths=oldDepth;camera.projectionMatrix=oldProjection;}
    }

    // Use the installed final-pass shader as the material-response oracle for
    // geometry, confirmed sky and partial fallback on identical frozen inputs.
    private static void SharedReflectionResponse()
    {
        var oldDepth=depths;var oldNormals=normals;var oldSpec=specular;var oldScene=scene;
        var oldTodRadius=Shader.GetGlobalVector("TOD_kRadius");
        var factory=new PropertySheetFactory();var sheet=factory.Get(native);
        var audit=factory.Get(UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Assets/TodAudit.shader"));
        var target=new RenderTexture(1,1,0,RenderTextureFormat.ARGBFloat,RenderTextureReadWrite.Linear);target.Create();owned.Add(target);
        var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
        var clip=projection*new Vector4(0,0,-5,1);
        var source=new Color(.18f,.32f,.12f,.7f);var geometry=new Color(.7f,.8f,.9f,1);
        var direction=new Vector3(.1f,.6f,1).normalized;
        try {
            depths=Texture(Enumerable.Repeat(new Color(clip.z/clip.w,0,0,0),width*height).ToArray());
            scene=Texture(Enumerable.Repeat(source,width*height).ToArray());
            sheet.properties.SetMatrix("_InverseProjectionMatrix",projection.inverse);
            sheet.properties.SetMatrix("_InverseViewMatrix",camera.cameraToWorldMatrix);
            sheet.properties.SetVector("_Params",new Vector4(0,0,0,1));sheet.properties.SetFloat("_CutOffThreshold",.5f);
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();
                foreach(float smooth in new[]{.55f,.8f,.98f,1f})foreach(float length in new[]{.5f,1f}) {
                    normals=Texture(Enumerable.Repeat(new Color(.5f,.5f,.5f+.5f*length,1),width*height).ToArray());
                    specular=Texture(Enumerable.Repeat(new Color(.04f,.06f,.08f,smooth),width*height).ToArray());
                    Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    foreach(float weather in new[]{0f,.8f}) {
                        TodGlobals(cb,weather);audit.properties.SetVector("_AuditDirection",direction);audit.properties.SetFloat("_AuditFog",1);
                        RuntimeUtilities.BlitFullscreenTriangle(cb,Texture2D.blackTexture,target,audit,0);Execute(cb);var sky=Read(target)[0];
                        foreach(int kind in new[]{1,2})foreach(float c in new[]{0f,.5f,1f}) {
                            const float smith=.65f;
                            Globals(cb);TodGlobals(cb,weather);
                            cb.Blit(Solid(new Color(geometry.r,geometry.g,geometry.b,smith)),p.TracePipeline.Radiance);
                            cb.Blit(Solid(new Color(0,0,0,kind)),p.TracePipeline.Record);
                            cb.Blit(Solid(new Color(c,5,0,0)),p.TracePipeline.Hit);
                            var viewRay=camera.worldToCameraMatrix.MultiplyVector(direction);
                            cb.Blit(Solid(new Color(viewRay.x,viewRay.y,viewRay.z,smooth)),p.TracePipeline.HitPoint);
                            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var actual=Read(camera.targetTexture);
                            var selected=kind==1?geometry*smith:Color.LerpUnclamped(source,sky*smith,.5f);
                            var combined=Color.LerpUnclamped(source,selected,c);
                            Globals(cb);cb.SetGlobalTexture("_Resolve",Solid(combined));
                            RuntimeUtilities.BlitFullscreenTriangle(cb,scene,camera.targetTexture,sheet,3);Execute(cb);var expected=Read(camera.targetTexture);
                            double error=actual.Select((v,i)=>Math.Max(Math.Abs(v.r-expected[i].r),Math.Max(Math.Abs(v.g-expected[i].g),Math.Abs(v.b-expected[i].b)))).Max();
                            Check(error<.005,"shared native reflected response and bounded TOD: s="+smooth+" n="+length+" weather="+weather+" kind="+kind+" c="+c+" error="+error);
                            if(smooth==.98f && length==1 && weather==0) {
                                Globals(cb);TodGlobals(cb,weather);o.View=ReflectionView.ReceiverColourFallback;
                                p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var fallback=Read(camera.targetTexture);
                                foreach(float strength in new[]{0f,.5f}) {
                                    o.FallbackStrength=strength;o.View=ReflectionView.Normal;
                                    p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var scaled=Read(camera.targetTexture);
                                    float scaleError=scaled.Select((v,i)=>Mathf.Max(Mathf.Abs(v.r-(actual[i].r-(1-strength)*fallback[i].r)),Mathf.Abs(v.g-(actual[i].g-(1-strength)*fallback[i].g)),Mathf.Abs(v.b-(actual[i].b-(1-strength)*fallback[i].b)))).Max();
                                    Check(scaleError<.002,"fallback strength scales only uncovered addition: strength="+strength+" kind="+kind+" c="+c+" error="+scaleError);
                                    o.View=ReflectionView.ReceiverColourFallback;
                                    p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var debug=Read(camera.targetTexture);
                                    Check(debug.Select((v,i)=>Mathf.Max(Mathf.Abs(v.r-strength*fallback[i].r),Mathf.Abs(v.g-strength*fallback[i].g),Mathf.Abs(v.b-strength*fallback[i].b))).Max()<.001,"fallback debug shows applied strength="+strength+" kind="+kind+" c="+c);
                                }
                                o.FallbackStrength=1;o.View=ReflectionView.Normal;
                            }
                        }
                    }
                }
            }
        } finally {factory.Release();depths=oldDepth;normals=oldNormals;specular=oldSpec;scene=oldScene;Shader.SetGlobalVector("TOD_kRadius",oldTodRadius);}
    }
    private static void ForceNativeMiss(CommandBuffer __0,RenderTargetIdentifier __2,int __4)
    {
        if(__4!=0)return;
        __0.SetRenderTarget(__2);__0.ClearRenderTarget(false,true,Color.clear);
    }
    private static void ReceiverFallbackParity()
    {
        var oldSpec=specular;var oldNormals=normals;var oldScene=scene;
        var factory=new PropertySheetFactory();var context=Context(factory);var renderer=CreateRenderer(out var effect);
        var harmony=new Harmony("ssr.receiver.fallback.oracle");
        var blit=AccessTools.Method(typeof(RuntimeUtilities),"BlitFullscreenTriangle",new[]{typeof(CommandBuffer),typeof(RenderTargetIdentifier),typeof(RenderTargetIdentifier),typeof(PropertySheet),typeof(int),typeof(bool),typeof(Rect?)});
        harmony.Patch(blit,postfix:new HarmonyMethod(typeof(StochasticSsrValidation),nameof(ForceNativeMiss)));
        try {
            foreach(float smooth in new[]{.55f,.8f,.98f,1f})foreach(float normalLength in new[]{.5f,1f}) {
                specular=Texture(oldSpec.GetPixels().Select((v,i)=>new Color(.04f+.6f*(i%width)/(width-1),.15f,.3f,smooth)).ToArray());
                normals=Texture(oldNormals.GetPixels().Select(v=>new Color((v.r-.5f)*normalLength+.5f,(v.g-.5f)*normalLength+.5f,(v.b-.5f)*normalLength+.5f,1)).ToArray());
                AccessTools.Method(rendererType,"ResetHistory").Invoke(renderer,null);
                using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);var o=Options();o.Temporal=true;
                    for(int frame=0;frame<3;frame++) {
                        scene=Texture(oldScene.GetPixels().Select((v,i)=>new Color(v.r*(1+frame*.15f),v.g+((i%width+frame*9)%17)*.02f,v.b,v.a)).ToArray());
                        context.source=scene;Globals(context.command);renderer.Render(context);Execute(context.command);var expected=Read(camera.targetTexture);
                        Globals(cb);p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular,true);
                        cb.Blit(Solid(Color.clear),p.TracePipeline.Record);cb.Blit(Solid(Color.clear),p.TracePipeline.Hit);
                        p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var actual=Read(camera.targetTexture);
                        double error=actual.Select((v,i)=>Math.Max(Math.Abs(v.r-expected[i].r),Math.Max(Math.Abs(v.g-expected[i].g),Math.Abs(v.b-expected[i].b)))).Max();
                        Check(error<.004,"native forced-miss final RGB parity including temporal/Gaussian/material: s="+smooth+" normal="+normalLength+" frame="+frame+" error="+error);
                        Check(actual.Select((v,i)=>Math.Abs(v.a-scene.GetPixel(i%width,i/width).a)).Max()<.001,"receiver fallback preserves scene alpha");
                    }
                    p.ReceiverFallback.Radiance.Release();p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
                    Check(p.ReceiverFallback.Radiance.IsCreated(),"lost receiver fallback target recovers");
                }
            }
        } finally {harmony.UnpatchSelf();renderer.Release();context.command.Dispose();factory.Release();specular=oldSpec;normals=oldNormals;scene=oldScene;}
    }
    private static void BoundaryExitContracts()
    {
        var oldNormals=normals;var oldSpec=specular;
        try {
            specular=Texture(Enumerable.Repeat(new Color(.2f,.15f,.1f,1),width*height).ToArray());
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
                foreach(var direction in new[]{Vector3.right,Vector3.forward}) {
                    var ns=new Color[width*height];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
                        var v=camera.worldToCameraMatrix.MultiplyVector(camera.ScreenPointToRay(new Vector3(x+.5f,y+.5f)).direction).normalized;
                        var n=camera.cameraToWorldMatrix.MultiplyVector((direction-v).normalized);
                        ns[y*width+x]=new Color(n.x*.5f+.5f,n.y*.5f+.5f,n.z*.5f+.5f,1);
                    }
                    normals=Texture(ns);var o=Options();o.Steps=512;o.Distance=250;
                    Globals(cb);TodGlobals(cb,.5f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var records=Read(p.TracePipeline.Record);
                    Check(records.All(r=>r.a!=2),"geometric side/near exits never become sky: direction="+direction);
                    Check(records.Count(r=>r.a==0)>100,"side/near fixture launches unresolved rays: direction="+direction);
                    Check(records.Any(r=>r.a==0 && r.b==6),"termination records identify geometric frustum exits: direction="+direction);
                    Check(Read(p.Resolved).All(v=>v==Color.clear),"side/near exits do not add TOD despite available inputs: direction="+direction);
                    o.ContinuationSamples=64;o.ContinuationPixels=64;o.ContinuationDepth=1000;
                    Globals(cb);TodGlobals(cb,.5f);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                    var continued=Read(p.TracePipeline.Record);
                    Check(Enumerable.Range(0,records.Length).Where(j=>records[j].b==6 || records[j].b==4).All(j=>records[j]==continued[j]),"continuation preserves existing screen exits and self rejections: "+direction);
                    Check(continued.All(v=>v.a!=2),"continuation cannot turn side/near exit into sky: "+direction);
                }
            }
        } finally {normals=oldNormals;specular=oldSpec;}
    }
    // Compare against the installed final-pass bytecode with a black reflection
    // input. This isolates removal without trusting a second copy of our formula.
    private static void NativeRemovalParity()
    {
        var oldNormals=normals;var oldDepths=depths;
        var cube=new Cubemap(32,TextureFormat.RGBAFloat,true);owned.Add(cube);
        for(int face=0;face<6;face++)for(int mip=0;mip<cube.mipmapCount;mip++) {
            int size=Math.Max(1,32>>mip);
            cube.SetPixels(Enumerable.Repeat(new Color(.4f+face*.1f,mip*.12f+.3f,.8f,1),size*size).ToArray(),(CubemapFace)face,mip);
        }
        cube.Apply(false);var clear=Solid(Color.clear);
        var raw=depths.GetPixels();for(int i=0;i<width*8;i++)raw[i]=new Color(SystemInfo.usesReversedZBuffer?0:1,0,0,0);depths=Texture(raw);
        var factory=new PropertySheetFactory();
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            var sheet=factory.Get(native);p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
            sheet.properties.SetMatrix("_InverseProjectionMatrix",GL.GetGPUProjectionMatrix(camera.projectionMatrix,false).inverse);
            sheet.properties.SetMatrix("_InverseViewMatrix",camera.cameraToWorldMatrix);
            sheet.properties.SetVector("_Params",new Vector4(0,0,0,1));
            foreach(float length in new[]{.5f,1f})foreach(float cutoff in new[]{0f,.5f,1.1f})foreach(float factor in new[]{0f,.35f,1f}) {
                normals=Texture(oldNormals.GetPixels().Select(n=>new Color((n.r-.5f)*length+.5f,(n.g-.5f)*length+.5f,(n.b-.5f)*length+.5f,1)).ToArray());
                var ao=Texture(Enumerable.Range(0,width*height).Select(i=>new Color(0,0,0,(i%width)/(float)(width-1))).ToArray());
                var stencil=Sized(Enumerable.Range(0,16).Select(i=>new Color(0,0,0,i/20f)).ToArray(),4,4);
                var o=Options();o.Smoothness=cutoff;o.View=ReflectionView.EnvironmentRemovedScene;
                Action bind=()=>{Globals(cb);cb.SetGlobalTexture("_MyGlobalReflectionProbe",cube);cb.SetGlobalTexture("_CameraGBufferTexture0",ao);cb.SetGlobalTexture("_StencilShadow",stencil);cb.SetGlobalFloat("_SSRFactor",factor);cb.SetGlobalTexture("_CameraMotionVectorsDepth",Texture2D.whiteTexture);};
                bind();p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);
                cb.Blit(clear,p.TracePipeline.Hit);cb.Blit(clear,p.TracePipeline.Record);
                p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var actual=Read(camera.targetTexture);
                bind();cb.SetGlobalTexture("_Resolve",clear);sheet.properties.SetFloat("_CutOffThreshold",cutoff);
                RuntimeUtilities.BlitFullscreenTriangle(cb,scene,camera.targetTexture,sheet,3);Execute(cb);var expected=Read(camera.targetTexture);
                double error=Error(actual,expected);
                Check(error<.002,"installed native removal parity: normal="+length+" cutoff="+cutoff+" factor="+factor+" error="+error);
                if(cutoff==0 && factor==1)Check(expected.Where((v,i)=>v.r<scene.GetPixel(i%width,i/width).r-.01f).Count()>500,"native removal oracle exercises subtraction and clamp");
            }
        }
        factory.Release();normals=oldNormals;depths=oldDepths;
    }

    private static void RecedingPlaneCoverage()
    {
        var oldDepth=depths;var oldNormal=normals;var oldSpec=specular;
        var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
        var ds=new Color[width*height];var ns=new Color[ds.Length];var ss=new Color[ds.Length];var eye=new float[ds.Length];
        for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
            int i=y*width+x;var ray=camera.worldToCameraMatrix.MultiplyVector(camera.ScreenPointToRay(new Vector3(x+.5f,y+.5f)).direction);
            float t=ray.y<0?-3/ray.y:10000;var pos=ray*t;float z=-pos.z;eye[i]=z;
            var clip=projection*new Vector4(pos.x,pos.y,pos.z,1);
            ds[i]=new Color(z<400?clip.z/clip.w:0,0,0,0);ns[i]=new Color(.5f,1,.5f,1);ss[i]=new Color(.2f,.15f,.1f,.98f);
        }
        depths=Texture(ds);normals=Texture(ns);specular=Texture(ss);
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            const int size=32;p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);var o=Options();
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
            var guides=new Color[size*size];var records=new Color[guides.Length];
            for(int y=0;y<size;y++)for(int x=0;x<size;x++) {
                int pixel=(int)((y+.5f)*height/size)*width+(int)((x+.5f)*width/size),j=y*size+x;
                guides[j]=new Color(eye[pixel]<400?1:0,Math.Min(500,eye[pixel]),0,1);records[j]=new Color(0,0,0,guides[j].r);
            }
            cb.Blit(Sized(guides,size,size),p.TracePipeline.Hit);cb.Blit(Sized(records,size,size),p.TracePipeline.Record);
            cb.Blit(Solid(new Color(0,0,0,.98f)),p.TracePipeline.HitPoint);cb.Blit(Solid(new Color(.7f,.8f,.9f,1)),p.TracePipeline.Radiance);
            o.View=ReflectionView.Confidence;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var confidence=Read(camera.targetTexture);
            int oldHoles=0,tested=0,newHoles=0;
            for(int y=5;y<height/2-4;y++)for(int x=5;x<width-5;x++) {
                int i=y*width+x,j=(int)((y+.5f)*size/height)*size+(int)((x+.5f)*size/width);
                if(eye[i]<5 || eye[i]>100)continue;tested++;
                if(Math.Abs(eye[i]-guides[j].g)>Math.Max(.02f,eye[i]*.005f))oldHoles++;
                if(confidence[i].r<.99f)newHoles++;
            }
            Check(tested>1000 && oldHoles>tested/2,"receding water fixture reproduces nearest-depth row rejection: "+oldHoles+"/"+tested);
            Check(newHoles==0,"surface-plane reconstruction removes row gaps on valid receding plane: "+newHoles+"/"+tested);
            o.View=ReflectionView.CoverageStages;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var stages=Read(camera.targetTexture);
            Check(stages.Where((v,i)=>eye[i]>=5 && eye[i]<=100 && i%width>=5 && i%width<width-5 && i/width>=5 && i/width<height/2-4).All(v=>Math.Abs(v.r-1)<.001 && Math.Abs(v.g-1)<.001 && Math.Abs(v.b-1)<.001),"coverage stages retain white for full raw, filtered and reconstructed support without capture");
            o.View=ReflectionView.ReconstructionLoss;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(camera.targetTexture).Where((v,i)=>eye[i]>=5 && eye[i]<=100 && i%width>=5 && i%width<width-5 && i/width>=5 && i/width<height/2-4).All(v=>v.r==0 && v.g==0 && v.b==0),"valid plane has no reconstruction loss");
            // Change only receiver normals: the stored guide plane stays correct,
            // isolating the normal gate rather than a coincident plane rejection.
            normals=Texture(Enumerable.Repeat(new Color(.5f,.9f,.8f,1),width*height).ToArray());Globals(cb);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var loss=Read(camera.targetTexture);
            Check(loss.Where((v,i)=>eye[i]>=5 && eye[i]<=100 && i%width>=5 && i%width<width-5 && i/width>=5 && i/width<height/2-4).All(v=>v.r==0 && v.g>.999f && v.b==0),"normal mismatch is green reconstruction loss");
            o.View=ReflectionView.CoverageStages;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(camera.targetTexture).Where((v,i)=>eye[i]>=5 && eye[i]<=100 && i%width>=5 && i%width<width-5 && i/width>=5 && i/width<height/2-4).All(v=>v.r>.999f && v.g>.999f && v.b==0),"normal rejection leaves raw/filtered support intact and removes final coverage");
            normals=Texture(ns);specular=Texture(ss.Select(v=>new Color(.4f,v.g,v.b,v.a)).ToArray());Globals(cb);
            o.View=ReflectionView.ReconstructionLoss;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(camera.targetTexture).Where((v,i)=>eye[i]>=5 && eye[i]<=100 && i%width>=5 && i%width<width-5 && i/width>=5 && i/width<height/2-4).All(v=>v.r==0 && v.g==0 && v.b==0),"uniform F0 change remains compatible across receiver samples");
            // Smoothness differs from the stored trace point, so material alone fails.
            specular=Texture(ss.Select(v=>new Color(v.r,v.g,v.b,.8f)).ToArray());Globals(cb);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(camera.targetTexture).Where((v,i)=>eye[i]>=5 && eye[i]<=100 && i%width>=5 && i%width<width-5 && i/width>=5 && i/width<height/2-4).All(v=>v.r==0 && v.g==0 && v.b>.999f),"material mismatch is blue reconstruction loss");
            specular=Texture(ss);Globals(cb);o.View=ReflectionView.Confidence;
            // Missing samples must reduce coverage rather than normalize surviving
            // samples into an opaque reflection or smear invalid RGB into the signal.
            var sparse=guides.Select((g,j)=>new Color(j%2==0?g.r:0,g.g,g.b,g.a)).ToArray();
            cb.Blit(Sized(sparse,size,size),p.TracePipeline.Hit);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);var partial=Read(camera.targetTexture);
            float maxError=0;
            for(int y=5;y<height/2-4;y++)for(int x=5;x<width-5;x++) {
                int i=y*width+x;if(eye[i]<5 || eye[i]>100)continue;
                float grid=(x+.5f)*size/width-.5f;int left=(int)Math.Floor(grid);float fraction=grid-left;
                float expected=left%2==0?1-fraction:fraction;
                maxError=Math.Max(maxError,Math.Abs(partial[i].r-expected));
            }
            Check(maxError<.001,"bilinear missing support reduces final confidence: max error="+maxError);
            // A depth discontinuity must still reject these injected reflections.
            cb.Blit(Solid(new Color(1,1,0,1)),p.TracePipeline.Hit);
            p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(camera.targetTexture).All(v=>v.r==0),"plane reconstruction rejects a different parallel surface");
            o.View=ReflectionView.ReconstructionLoss;p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
            Check(Read(camera.targetTexture).Where((v,i)=>eye[i]>=5 && eye[i]<=100 && i%width>=5 && i%width<width-5 && i/width>=5 && i/width<height/2-4).All(v=>v.r>.999f && v.g==0 && v.b==0),"parallel surface rejection is red reconstruction loss");
        }
        depths=oldDepth;normals=oldNormal;specular=oldSpec;
    }
}
