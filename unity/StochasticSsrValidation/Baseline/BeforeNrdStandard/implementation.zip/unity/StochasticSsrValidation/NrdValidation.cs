using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using BepInEx;
using FuckTheseFX.Source.StochasticSSR;
using HarmonyLib;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.PostProcessing;
using CustomAmbientResearch;

public static partial class StochasticSsrValidation
{
    [System.Runtime.InteropServices.DllImport("FTFXNrd",CallingConvention=System.Runtime.InteropServices.CallingConvention.Cdecl)]
    private static extern IntPtr FTFX_NrdQueue(IntPtr id,IntPtr signal,IntPtr normal,IntPtr receiver,IntPtr motion,IntPtr output,ref NrdSpecularBackend.Frame frame);
    public static void RunNrd() {
        try {
            AccessTools.Property(typeof(Paths),"BepInExConfigPath").SetValue(null,Path.GetFullPath("BepInEx-test.cfg"));
            AccessTools.Property(typeof(Paths),"ConfigPath").SetValue(null,Directory.GetCurrentDirectory());
            AccessTools.Property(typeof(Paths),"BepInExRootPath").SetValue(null,Path.GetFullPath("Capture-test"));
            NrdSpecularBackend.ValidationShader=AssetDatabase.LoadAssetAtPath<Shader>("Assets/NrdInputs.shader");
            NrdSpecularBackend.ValidationLibrary=Path.GetFullPath("Native/FTFXNrd.dll");
            Check(!ShaderUtil.GetShaderMessages(NrdSpecularBackend.ValidationShader).Any(m=>m.severity.ToString()=="Error"),"NRD gather shader compiles");
            compute=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/HiZ.compute");blend=AssetDatabase.LoadAssetAtPath<Shader>("Assets/Support.shader");reflection=AssetDatabase.LoadAssetAtPath<Shader>("Assets/Reflection.shader");
            noise=new Texture2D(128,128,TextureFormat.RG16,false,true){filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Repeat};noise.LoadRawTextureData(File.ReadAllBytes("Assets/AMD/BlueNoise.bytes"));noise.Apply();owned.Add(noise);
            game=AssetBundle.LoadFromFile(Path.Combine(File.ReadAllText("game-path.txt").Trim(),"EscapeFromTarkov_Data/StreamingAssets/Windows/shaders"));
            native=game.LoadAllAssets<Shader>().Single(s=>s.name=="Hidden/PostProcessing/ScreenSpaceReflections");gaussian=game.LoadAllAssets<ComputeShader>().First(c=>c.name.IndexOf("Gaussian",StringComparison.OrdinalIgnoreCase)>=0);
            var go=new GameObject("NRD isolated fixture");owned.Add(go);camera=go.AddComponent<Camera>();camera.enabled=false;camera.allowHDR=true;camera.renderingPath=RenderingPath.DeferredShading;camera.nearClipPlane=.1f;camera.farClipPlane=500;camera.fieldOfView=65;
            var factory=new PropertySheetFactory();var context=Context(factory);context.command.Dispose();factory.Release();
            Directory.CreateDirectory("NrdResults");Directory.CreateDirectory("Frozen");
            NrdSynthetic();NrdLifecycle();NrdCaptured();
            if(File.Exists("nrd-timing.txt"))NrdTiming();
            Check(!ShaderUtil.GetShaderMessages(NrdSpecularBackend.ValidationShader).Any(m=>m.severity.ToString()=="Error"),"executed NRD gather variants compile");
            Check(BuildPipeline.BuildAssetBundles("Output",new[]{new AssetBundleBuild{assetBundleName="nrdssr",assetNames=new[]{"Assets/NrdInputs.shader"}}},BuildAssetBundleOptions.ForceRebuildAssetBundle|BuildAssetBundleOptions.ChunkBasedCompression,BuildTarget.StandaloneWindows64)!=null,"isolated NRD adapter bundle builds");
            File.WriteAllLines("NrdResults/validation.txt",checks);
        }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);throw;}
        finally{foreach(var obj in owned)if(obj!=null)UnityEngine.Object.DestroyImmediate(obj);if(game!=null)game.Unload(true);}
    }
    private static Options NrdOptions() {
        var o=Options();o.Smoothness=0;o.Temporal=true;o.CoverageTemporal=true;o.CoverageFullSmoothness=.7f;o.CoverageEndSmoothness=.9f;o.HistoryFrames=16;
        o.CoverageFilter=true;o.CoverageFilterStrength=1;o.CoverageFilterFullSmoothness=.7f;o.CoverageFilterEndSmoothness=.95f;o.CoverageFilterSmoothStrength=.25f;
        o.ZeroSmoothnessProbe=true;o.ZeroSmoothnessProbeStrength=.3f;o.ZeroSmoothnessProbeClose=.1f;o.ZeroSmoothnessProbeFadeStart=5;o.ZeroSmoothnessProbeFadeEnd=15;
        o.Freeze=false;o.BypassHitNormal=true;o.Steps=350;o.ContinuationSamples=350;o.ContinuationPixels=500;o.ContinuationDepth=200;o.GlobalContinuedSky=true;o.Thickness=1;o.ThicknessConfidenceFloor=1;
        return o;
    }
    private static void NrdSynthetic() {
        width=384;height=216;Fixture();const int size=256;
        var rows=new List<string>{"case,backend,mean_r,mean_g,mean_b,mean_coverage,temporal_delta_rms,raw_mean_r,raw_mean_g,raw_mean_b,raw_mean_coverage,detail_peak_r,excluded_max"};
        var sequence=new List<string>{"case,backend,frame,mean_r,mean_g,mean_b,mean_coverage,raw_mean_r,raw_mean_g,raw_mean_b,raw_mean_coverage"};
        foreach(string kind in new[]{"stationary-sparse","moving-water-normals","weapon-foliage-boundaries","geometry-sky-transitions","camera-motion","camera-cut","fine-reflection-detail"}) {
            camera.transform.position=Vector3.zero;camera.ResetWorldToCameraMatrix();camera.ResetProjectionMatrix();camera.nonJitteredProjectionMatrix=camera.projectionMatrix;Fixture();
            var colours=new Color[size*size];var guides=new Color[colours.Length];var points=new Color[colours.Length];var records=new Color[colours.Length];
            var normalsPixels=new Color[width*height];var specPixels=new Color[normalsPixels.Length];var rawDepth=new Color[normalsPixels.Length];var motions=new Color[normalsPixels.Length];
            var rawTexture=Sized(colours,size,size);var guideTexture=Sized(guides,size,size);var pointTexture=Sized(points,size,size);var recordTexture=Sized(records,size,size);var motionTexture=Texture(motions);
            var ns=Texture(normalsPixels);var ss=Texture(specPixels);var ds=Texture(rawDepth);normals=ns;specular=ss;depths=ds;
            using(var cb=new CommandBuffer())using(var current=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))using(var nrd=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                current.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);nrd.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
                var a=NrdOptions();var b=a;b.NrdSpecular=true;
                bool boundary=kind=="weapon-foliage-boundaries";
                var priorView=camera.worldToCameraMatrix;var priorProjection=camera.projectionMatrix;
                var sum=new double[2,4];var rawSum=new double[4];var noiseSum=new double[2];var detail=new double[2];var excludedMax=new double[2];Color[][] previous={null,null};
                for(int frame=0;frame<64;frame++) {
                    if(kind=="camera-motion")camera.transform.position=new Vector3(frame*.02f,0,0);
                    if(kind=="camera-cut" && frame==32){camera.transform.position=new Vector3(3,0,0);current.ResetHistory();nrd.ResetHistory();}
                    var gpu=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);var inv=gpu.inverse;
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++) {
                        int i=y*width+x;bool excluded=boundary && ((x>width/3&&x<width/2&&y>height/3)||(x%37<2&&y<height/2));float z=excluded?1:4;
                        var clip=gpu*new Vector4(0,0,-z,1);rawDepth[i]=new Color(clip.z/clip.w,0,0,0);
                        float theta=kind=="moving-water-normals"?.1f*Mathf.Sin(frame*.21f+x*.03f):0;
                        normalsPixels[i]=new Color(.5f+.5f*Mathf.Sin(theta),.5f,.5f+.5f*Mathf.Cos(theta),1);
                        specPixels[i]=new Color(.2f,.15f,.1f,excluded?0:kind=="fine-reflection-detail"||kind=="moving-water-normals"?1:.65f);
                        motions[i]=new Color(kind=="camera-motion"?.003f:0,0,0,0);
                    }
                    ns.SetPixels(normalsPixels);ns.Apply();ss.SetPixels(specPixels);ss.Apply();ds.SetPixels(rawDepth);ds.Apply();motionTexture.SetPixels(motions);motionTexture.Apply();
                    for(int y=0;y<size;y++)for(int x=0;x<size;x++) {
                        int i=y*size+x,rx=Math.Min((int)((x+.5f)*width/size),width-1),ry=Math.Min((int)((y+.5f)*height/size),height-1),r=ry*width+rx;
                        float s=specPixels[r].a,z=s==0?1:4;float angle=kind=="moving-water-normals"?.1f*Mathf.Sin(frame*.21f+rx*.03f):0;
                        var normal=new Vector3(Mathf.Sin(angle),0,Mathf.Cos(angle));var oct=normal/(Mathf.Abs(normal.x)+Mathf.Abs(normal.y)+Mathf.Abs(normal.z));
                        uint hash=unchecked((uint)(i*747796405+frame*2891336453L+277803737));hash=(hash^(hash>>16))*2246822519u;
                        float c=s==0?0:kind=="fine-reflection-detail"?1:((hash&1023)<350?1:0);
                        int source=kind=="geometry-sky-transitions"&&x>size/2?2:1;
                        guides[i]=new Color(c,z,oct.x,oct.y);
                        var h=inv*new Vector4((rx+.5f)/width*2-1,(ry+.5f)/height*2-1,.5f,1);var receiver=new Vector3(h.x,h.y,h.z)*(z/-h.z);
                        var endpoint=receiver+Vector3.right;
                        var projected=gpu*new Vector4(endpoint.x,endpoint.y,endpoint.z,1);int hx=Mathf.Clamp((int)((projected.x/projected.w*.5f+.5f)*width),0,width-1);
                        points[i]=source==2?new Color(0,1,0,s):new Color(endpoint.x,endpoint.y,endpoint.z,s);
                        records[i]=new Color(hx,ry,c>0?0:9,c>0?source:0);
                        bool dot=kind=="fine-reflection-detail"&&Math.Abs(x-size/2)<=2&&Math.Abs(y-size/2)<=2;
                        colours[i]=kind=="camera-cut"&&frame>=32?new Color(.05f,.8f,.1f,1):dot?new Color(8,.04f,.02f,1):new Color(.8f,.4f,.2f,1);
                        if(kind=="camera-motion"&&Math.Abs((x+.5f)/size-(.3f+frame*.003f))<.03f)colours[i]=new Color(2,.1f,.05f,1);
                        if(kind=="moving-water-normals")colours[i]*=1+.25f*Mathf.Sin(frame*.2f);
                        colours[i].a=1;
                    }
                    rawTexture.SetPixels(colours);rawTexture.Apply();guideTexture.SetPixels(guides);guideTexture.Apply();pointTexture.SetPixels(points);pointTexture.Apply();recordTexture.SetPixels(records);recordTexture.Apply();
                    for(int candidate=0;candidate<2;candidate++) {
                        var p=candidate==0?current:nrd;var o=candidate==0?a:b;
                        // Frozen signals have explicit previous receiver transforms.
                        AccessTools.Field(typeof(ConfidenceSsrPipeline),"previousView").SetValue(p,priorView);
                        AccessTools.Field(typeof(ConfidenceSsrPipeline),"previousProjection").SetValue(p,priorProjection);
                        p.PrepareTraceHistory();Globals(cb);TodGlobals(cb,.2f);cb.SetGlobalTexture("_CameraMotionVectorsTexture",motionTexture);
                        p.TracePipeline.Trace(cb,camera,scene,o,depths,normals,specular);
                        cb.Blit(rawTexture,p.TracePipeline.Radiance);cb.Blit(guideTexture,p.TracePipeline.Hit);cb.Blit(pointTexture,p.TracePipeline.HitPoint);cb.Blit(recordTexture,p.TracePipeline.Record);
                        p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                        var result=Read(candidate==0?p.DepthGapFilled:p.Nrd.Output);
                        var measured=Read(p.Resolved);var frameMean=new double[8];
                        for(int i=0;i<result.Length;i++){for(int j=0;j<4;j++){frameMean[j]+=result[i][j];frameMean[j+4]+=measured[i][j];}}
                        sequence.Add(kind+","+(candidate==0?"FTFX":"REBLUR_SPECULAR")+","+frame+","+string.Join(",",frameMean.Select(v=>F(v/result.Length))));
                        Check(result.All(v=>Finite(v)&&v.a>=0&&v.a<=1.001f),"finite bounded "+kind+" "+candidate+" frame="+frame);
                        if(candidate==1)Check(p.Nrd!=null&&p.Nrd.Stats.Status==1&&p.Nrd.Stats.Failures==0,"upstream DXBC executed "+kind+" frame="+frame+" status="+p.Nrd.Stats.Status+" error="+p.Nrd.Error);
                        if(candidate==1&&frame==0){
                            var receiverData=Read(p.Nrd.Receiver);Debug.Log("NRD eligible="+receiverData.Count(v=>v.b>0)+" guide="+receiverData[size*size/2]);
                            for(int resource=0;resource<5;resource++){var texture=p.Nrd.DiagnosticTexture(resource);var r=AsyncGPUReadback.Request(texture,0,TextureFormat.RGBAFloat);r.WaitForCompletion();var data=r.GetData<Color>().ToArray();Debug.Log("NRD resource "+resource+" mean="+data.Average(v=>v.r)+","+data.Average(v=>v.a)+" max="+data.Max(v=>v.r));UnityEngine.Object.DestroyImmediate(texture);}
                            Check(receiverData.Any(v=>v.b>0),"NRD receives eligible receivers");
                            Check(Read(p.Nrd.Motion).All(v=>Math.Abs(v.r-(kind=="camera-motion"?-.003f:0))<1e-5&&v.g==0),"Unity UV motion maps to previous-current NRD UV without a resolution scale");
                            var roughness=Read(p.Nrd.Normal);Check(roughness.All(v=>Finite(v)&&v.a>=0&&v.a<=1),"finite world normal and linear roughness guides");
                            Check(receiverData.Where((v,i)=>records[i].a==0).All(v=>v.g==0),"unknown SSR misses retain zero unavailable hit distance");
                            if(kind=="geometry-sky-transitions")Check(receiverData.Where((v,i)=>records[i].a==2).All(v=>v.g==65504),"confirmed sky uses explicit infinite-distance surrogate, not coverage");
                        }
                        if(kind=="camera-cut"&&frame==32)Check(result.All(v=>v.a<=0||v.r<=v.g*.2f+.01f),"camera cut cannot retain old red illumination "+candidate);
                        if(frame>=32) {
                            for(int i=0;i<result.Length;i++) {
                                sum[candidate,0]+=result[i].r;sum[candidate,1]+=result[i].g;sum[candidate,2]+=result[i].b;sum[candidate,3]+=result[i].a;
                                if(previous[candidate]!=null){var d=result[i]-previous[candidate][i];noiseSum[candidate]+=d.r*d.r+d.g*d.g+d.b*d.b;}
                                if(guides[i].r==0&&points[i].a==0)excludedMax[candidate]=Math.Max(excludedMax[candidate],Math.Max(result[i].maxColorComponent,result[i].a));
                            }
                            detail[candidate]+=result.Max(v=>(double)v.r);
                            if(candidate==0)foreach(var v in Read(p.Resolved)){rawSum[0]+=v.r;rawSum[1]+=v.g;rawSum[2]+=v.b;rawSum[3]+=v.a;}
                        }
                        previous[candidate]=result;
                        if(frame==63){Save(candidate==0?p.DepthGapFilled:p.Nrd.Output,"nrd-"+kind+"-"+candidate);Save(camera.targetTexture,"nrd-composed-"+kind+"-"+candidate);}
                    }
                    priorView=camera.worldToCameraMatrix;priorProjection=camera.projectionMatrix;
                }
                for(int c=0;c<2;c++) {
                    double count=32.0*size*size;
                    rows.Add(kind+","+(c==0?"FTFX":"REBLUR_SPECULAR")+","+string.Join(",",Enumerable.Range(0,4).Select(j=>F(sum[c,j]/count)))+","+F(Math.Sqrt(noiseSum[c]/(count*3)))+","+string.Join(",",rawSum.Select(v=>F(v/count)))+","+F(detail[c]/32)+","+F(excludedMax[c]));
                }
                Check(sum[1,0]>0&&sum[1,3]>0,"NRD preserves nonzero reflection energy "+kind);
                if(kind=="fine-reflection-detail")Check(detail[1]/32>7.2&&Math.Abs(sum[1,0]/rawSum[0]-1)<.03,"small bright reflection peak and mean energy retained");
                if(kind=="stationary-sparse")Check(noiseSum[1]<noiseSum[0],"REBLUR reduces stationary stochastic coverage variation");
                Check(!boundary||excludedMax[1]==0,"probe-substituted weapon/foliage cannot become noisy GGX samples");
                var stats=nrd.Nrd.Stats;File.WriteAllText("NrdResults/resources-synthetic.txt","permanent="+stats.PermanentBytes+" transient="+stats.TransientBytes+" adapter_native="+stats.AdapterBytes+" dispatches="+stats.Dispatches+"\n");
                // Toggle back to FTFX and compare fresh output against an independent backend.
                b.NrdSpecular=false;nrd.ResetHistory();current.ResetHistory();
                Globals(cb);current.Render(cb,camera,scene,camera.targetTexture,a,depths,normals,specular);Execute(cb);var baseline=Read(camera.targetTexture);
                Globals(cb);nrd.Render(cb,camera,scene,camera.targetTexture,b,depths,normals,specular);Execute(cb);
                Check(nrd.Nrd==null&&Error(baseline,Read(camera.targetTexture))==0,"removing NRD restores current backend exactly "+kind);
            }
            File.WriteAllLines("NrdResults/synthetic.csv",rows);
            File.WriteAllLines("NrdResults/synthetic-sequence.csv",sequence);
        }
    }
    private static bool Finite(Color v)=>!(float.IsNaN(v.r)||float.IsInfinity(v.r)||float.IsNaN(v.g)||float.IsInfinity(v.g)||float.IsNaN(v.b)||float.IsInfinity(v.b)||float.IsNaN(v.a)||float.IsInfinity(v.a));
    private static void NrdLifecycle() {
        width=192;height=128;camera.ResetWorldToCameraMatrix();camera.ResetProjectionMatrix();camera.nearClipPlane=.1f;camera.farClipPlane=500;camera.fieldOfView=65;Fixture();camera.nonJitteredProjectionMatrix=camera.projectionMatrix;
        using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
            var rasterProjection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
            foreach(var uv in new[]{new Vector2(.1f,.2f),new Vector2(.8f,.9f),new Vector2(.5f,.5f)}) {
                var h=rasterProjection.inverse*new Vector4(uv.x*2-1,uv.y*2-1,.5f,1);var clip=NrdSpecularBackend.NrdProjection(rasterProjection)*h;
                Check(Math.Abs((clip.x/clip.w*.5f+.5f)-uv.x)<1e-6&&Math.Abs((.5f-clip.y/clip.w*.5f)-uv.y)<1e-6,"NRD/FTFX projection conventions address the same receiver texel "+uv);
            }
            var o=NrdOptions();o.NrdSpecular=true;o.Freeze=true;p.Ensure(width,height,128,RenderTextureFormat.ARGBHalf);
            for(int frame=0;frame<4;frame++){Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);}
            Check(p.Nrd.Stats.Pending==4,"multiple immutable native frames can queue before execution");Execute(cb);Read(p.Nrd.Output);
            Check(p.Nrd.Stats.Pending==0&&p.Nrd.Stats.Frames==4&&p.Nrd.Stats.Failures==0,"queued native frames execute in order without packet leaks");
            foreach(bool temporal in new[]{false,true}){o.Temporal=temporal;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);Check(Read(p.Nrd.Output).All(Finite),"NRD temporal toggle is finite "+temporal);}
            o.Temporal=true;o.NrdAntiFirefly=true;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);Check(p.Nrd.Stats.Failures==0,"optional NRD anti-firefly permutation executes");
            p.PrepareRaster(camera,2,width,height);Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
            var stable=camera.projectionMatrix;var raster=stable;raster.m02+=.002f;raster.m12-=.001f;camera.projectionMatrix=raster;camera.nonJitteredProjectionMatrix=stable;
            p.TracePipeline.Raster.FinalizeRaster(camera);AccessTools.Method(typeof(NrdSpecularBackend),"FinalizeRaster").Invoke(p.Nrd,new object[]{camera});Execute(cb);
            Check(p.TracePipeline.Raster.Current.Ready&&p.Nrd.Stats.Pending==0&&p.Nrd.Stats.Failures==0&&Read(p.Nrd.Output).All(Finite),"late DLSS/TAA raster state reaches native settings before execution");p.TracePipeline.Raster.Commit();camera.projectionMatrix=stable;
            string root=Path.GetFullPath("NrdResults/readback-"+DateTime.UtcNow.Ticks);Directory.CreateDirectory(root);var capture=(ContinuationCapture)AccessTools.Field(typeof(ConfidenceSsrPipeline),"continuationCapture").GetValue(p);
            string originalRoot=Paths.BepInExRootPath;AccessTools.Property(typeof(Paths),"BepInExRootPath").SetValue(null,root);
            try {
            o.CaptureContinuation=true;p.PrepareRaster(camera,0,width,height);Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
            p.TracePipeline.Raster.FinalizeRaster(camera);AccessTools.Method(typeof(NrdSpecularBackend),"FinalizeRaster").Invoke(p.Nrd,new object[]{camera});
            p.Ensure(width,height,192,RenderTextureFormat.ARGBHalf);p.ResetHistory();o.CaptureContinuation=false;
            p.PrepareRaster(camera,0,width,height);Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);p.TracePipeline.Raster.FinalizeRaster(camera);AccessTools.Method(typeof(NrdSpecularBackend),"FinalizeRaster").Invoke(p.Nrd,new object[]{camera});Execute(cb);
            AsyncGPUReadback.WaitAllRequests();Check(!capture.Pending&&Directory.GetFiles(root,"nrd-display.exr",SearchOption.AllDirectories).Length==1,"native readback survives queued resize and reset");
            Check(p.Nrd.Output.width==192&&Read(p.Nrd.Output).All(Finite)&&p.Nrd.Stats.Failures==0,"native pools recreate on trace resize");
            }finally{AccessTools.Property(typeof(Paths),"BepInExRootPath").SetValue(null,originalRoot);}
            o.CaptureContinuation=false;p.PrepareRaster(camera,0,width,height);Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);
            Check(p.Nrd.Stats.Pending==1&&p.Nrd.DiscardQueuedFrames()==1&&p.Nrd.Stats.Pending==0,"discarded command buffers release their native packets");cb.Clear();
            var nativeHandle=(IntPtr)AccessTools.Field(typeof(NrdSpecularBackend),"handle").GetValue(p.Nrd);var invalidFrame=new NrdSpecularBackend.Frame();
            Check(FTFX_NrdQueue(nativeHandle,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,ref invalidFrame)==IntPtr.Zero&&p.Nrd.Stats.Status<0,"missing native texture fails safely before pointer dereference");
            Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
            Check(p.Nrd==null&&p.Temporal!=null&&Read(camera.targetTexture).All(Finite),"native failure returns to current FTFX temporal backend");
            o.NrdSpecular=false;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
            o.NrdSpecular=true;Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular);Execute(cb);
            Check(p.Nrd!=null&&p.Nrd.Stats.Status==1&&p.Nrd.Stats.Failures==0,"off/on recovers the native backend after a failed resource handoff");
        }
    }
    private static string F(double v)=>v.ToString("G9",CultureInfo.InvariantCulture);
    private static Texture2D NrdReplay(string capture) {
        string folder=Path.Combine(File.ReadAllText("game-path.txt").Trim(),"BepInEx/FTFX-SSR-Captures",capture);
        var settings=File.ReadAllLines(Path.Combine(folder,"settings.txt"));var projection=ReplayMatrix(settings.First(v=>v.StartsWith("RasterProjection=")));
        scene=ReplayTexture(folder,"scene-source");normals=ReplayTexture(folder,"gbuffer2");specular=ReplayTexture(folder,"gbuffer1");materialOcclusion=ReplayTexture(folder,"gbuffer0");
        width=scene.width;height=scene.height;var eye=ReplayTexture(folder,"trace-depth");var pixels=eye.GetPixels();
        camera.nearClipPlane=projection.m23/(1+projection.m22);camera.farClipPlane=pixels.Max(v=>v.r);
        camera.fieldOfView=2*Mathf.Atan(1/projection.m11)*Mathf.Rad2Deg;camera.aspect=projection.m11/projection.m00;
        var cp=projection;cp.SetRow(2,projection.GetRow(3)-2*projection.GetRow(2));camera.projectionMatrix=cp;camera.nonJitteredProjectionMatrix=cp;camera.worldToCameraMatrix=ReplayMatrix(settings.First(v=>v.StartsWith("CameraToWorld="))).inverse;
        var raw=new Color[width*height];for(int y=0;y<height;y++)for(int x=0;x<width;x++){float z=pixels[y*eye.width+x].r;var clip=projection*new Vector4(0,0,-z,1);raw[y*width+x]=new Color(clip.z/clip.w,0,0,0);}
        depths=Texture(raw);camera.targetTexture=new RenderTexture(width,height,0,RenderTextureFormat.ARGBHalf);camera.targetTexture.Create();owned.Add(camera.targetTexture);return ReplayTexture(folder,"water");
    }
    private static void NrdCaptured() {
        var rows=new List<string>{"capture,backend,temporal_delta_rms,mean_r,mean_g,mean_b,coverage,raw_mean_r,raw_mean_g,raw_mean_b,raw_coverage"};
        foreach(string capture in new[]{"20261002-231147-581","20261003-032313-165","20261002-215552-280"}) {
            var mask=NrdReplay(capture);
            using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
            using(var cb=new CommandBuffer())using(var current=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))using(var nrd=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                current.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);nrd.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);
                cb.Blit(mask,WaterReflectionCapture.Get(camera,width,height));Execute(cb);var a=NrdOptions();a.WaterNormals=true;a.WaterTraceStrength=.85f;a.NormalStartDistance=50;a.NormalEndDistance=100;a.NormalRadius=4;var b=a;b.NrdSpecular=true;
                Color[][] previous={null,null};var sums=new double[2,4];var rawSums=new double[4];var differences=new double[2];
                Color[][] measuredParity=new Color[3][];
                for(int frame=0;frame<40;frame++)for(int c=0;c<2;c++) {
                    var p=c==0?current:nrd;Globals(cb);TodGlobals(cb,.2f);p.Render(cb,camera,scene,camera.targetTexture,c==0?a:b,depths,normals,specular);Execute(cb);
                    if(c==1)Check(p.Nrd!=null&&p.Nrd.Stats.Status==1&&p.Nrd.Stats.Failures==0,"captured native DXBC frame "+capture+" "+frame);
                    var output=Read(c==0?p.DepthGapFilled:p.Nrd.Output);
                    if(frame==39){var raw=new[]{Read(p.TracePipeline.Radiance),Read(p.TracePipeline.Record),Read(p.Resolved)};if(c==0)measuredParity=raw;else for(int k=0;k<raw.Length;k++)Check(Error(measuredParity[k],raw[k])==0,"native backend preserves exact current-frame trace and resolve "+capture+" resource="+k);}
                    Check(output.All(Finite),"finite captured output "+capture+" "+c+" "+frame);
                    if(frame>=16) {
                        for(int i=0;i<output.Length;i++) {
                            sums[c,0]+=output[i].r;sums[c,1]+=output[i].g;sums[c,2]+=output[i].b;sums[c,3]+=output[i].a;
                            if(previous[c]!=null){var delta=output[i]-previous[c][i];differences[c]+=delta.r*delta.r+delta.g*delta.g+delta.b*delta.b;}
                        }
                        if(c==0)foreach(var v in Read(p.Resolved)){rawSums[0]+=v.r;rawSums[1]+=v.g;rawSums[2]+=v.b;rawSums[3]+=v.a;}
                    }
                    previous[c]=output;
                    if(frame==39){Save(c==0?p.DepthGapFilled:p.Nrd.Output,"nrd-capture-"+capture+"-"+c);Save(camera.targetTexture,"nrd-capture-composed-"+capture+"-"+c);}
                    if(c==1&&frame==39) {
                        Check(p.Temporal==null&&p.History==null&&p.HistoryStats==null&&p.HistoryAnchor==null,"NRD replaces all custom GGX temporal/coverage history "+capture);
                        var stats=p.Nrd.Stats;File.WriteAllText("NrdResults/resources-"+capture+".txt","permanent="+stats.PermanentBytes+" transient="+stats.TransientBytes+" adapter_native="+stats.AdapterBytes+" adapter_unity="+(768L*768*(16+16+4+8))+" dispatches="+stats.Dispatches+"\n");
                    }
                }
                double count=24.0*768*768;
                for(int c=0;c<2;c++)rows.Add(capture+","+(c==0?"FTFX":"REBLUR_SPECULAR")+","+F(Math.Sqrt(differences[c]/(3*count)))+","+string.Join(",",Enumerable.Range(0,4).Select(j=>F(sums[c,j]/count)))+","+string.Join(",",rawSums.Select(v=>F(v/count))));
            }
            File.WriteAllLines("NrdResults/captured.csv",rows);
        }
        materialOcclusion=null;
    }
    private static void NrdTiming() {
        perStage=false;completionOutput=null;timer=new GpuTiming();timer.Initialize(Path.GetFullPath("Native/CustomAmbientGpu.dll"),GpuTiming.StageCapacity);
        var rows=new List<string>{"dataset,trial,sample,backend,total_ssr_gpu_ms"};
        var cpuRows=new List<string>{"dataset,trial,sample,backend,managed_render_record_us"};
        var nativeRows=new List<string>{"dataset,trial,batch_last_sample,native_queue_us,native_event_submission_us"};
        try {
            foreach(string dataset in new[]{"synthetic-floor-wall","20261002-231147-581","20261003-032313-165"}) {
                Texture2D mask=null;
                if(dataset.StartsWith("synthetic")){width=2560;height=1440;camera.ResetWorldToCameraMatrix();camera.ResetProjectionMatrix();camera.nearClipPlane=.1f;camera.farClipPlane=500;camera.fieldOfView=65;Fixture();}
                else mask=NrdReplay(dataset);
                camera.nonJitteredProjectionMatrix=camera.projectionMatrix;
                using(var water=new WaterReflectionCapture(AssetDatabase.LoadAssetAtPath<Shader>("Assets/WaterCapture.shader"),false){Requested=()=>true,IsMainCamera=c=>c==camera})
                using(var cb=new CommandBuffer())using(var current=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian))using(var nrd=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                    current.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);nrd.Ensure(width,height,768,RenderTextureFormat.ARGBHalf);cb.Blit(mask!=null?mask:Texture2D.blackTexture,WaterReflectionCapture.Get(camera,width,height));Execute(cb);
                    var a=NrdOptions();var b=a;b.NrdSpecular=true;
                    for(int trial=0;trial<3;trial++) {
                        current.ResetHistory();nrd.ResetHistory();
                        for(int warm=0;warm<24;warm++){Globals(cb);TodGlobals(cb,.2f);current.Render(cb,camera,scene,camera.targetTexture,a,depths,normals,specular);Globals(cb);TodGlobals(cb,.2f);nrd.Render(cb,camera,scene,camera.targetTexture,b,depths,normals,specular);}
                        Execute(cb);GpuBarrier();
                        Check(nrd.Nrd.Stats.Failures==0,"native warmup complete before total SSR timings "+dataset);
                        for(int first=0;first<32;first+=4) {
                            for(int sample=first;sample<first+4;sample++)foreach(int c in (sample+trial)%2==0?new[]{0,1}:new[]{1,0}) {
                                Globals(cb);TodGlobals(cb,.2f);var ticket=timer.Reserve(trial*1000+sample,c+1,camera.GetInstanceID(),0);Check(ticket!=IntPtr.Zero,"NRD total SSR query reservation");
                                timer.Event(cb,1,ticket);var cpu=System.Diagnostics.Stopwatch.StartNew();(c==0?current:nrd).Render(cb,camera,scene,camera.targetTexture,c==0?a:b,depths,normals,specular);cpu.Stop();timer.Event(cb,2,ticket);
                                cpuRows.Add(dataset+","+trial+","+sample+","+(c==0?"FTFX":"REBLUR_SPECULAR")+","+F(cpu.Elapsed.TotalMilliseconds*1000));
                            }
                            Execute(cb);GpuBarrier();timer.Immediate(3);GpuBarrier();timer.Immediate(4);GpuBarrier();
                            var buffer=new GpuTiming.Row[512];var result=new List<GpuTiming.Row>();int count;while((count=timer.Read(buffer))>0)result.AddRange(buffer.Take(count));
                            Check(result.Count==8&&result.All(r=>r.Flags==0)&&timer.Pending==0&&timer.Dropped==0,"complete non-disjoint total SSR timestamps");
                            foreach(var row in result)rows.Add(dataset+","+trial+","+(row.Frame%1000)+","+(row.Window==1?"FTFX":"REBLUR_SPECULAR")+","+F(row.Ms));
                            var nativeStats=nrd.Nrd.Stats;nativeRows.Add(dataset+","+trial+","+(first+3)+","+F(nativeStats.QueueUs)+","+F(nativeStats.EventUs));
                            File.WriteAllLines("NrdResults/gpu.csv",rows);
                            File.WriteAllLines("NrdResults/cpu.csv",cpuRows);File.WriteAllLines("NrdResults/native-cpu.csv",nativeRows);
                        }
                    }
                }
            }
            File.WriteAllText("NrdResults/timing-method.txt",SystemInfo.graphicsDeviceName+"; root-only D3D11 GPU timestamps around complete Render: full camera depth/normal preparation, unchanged R768 full-density 350/350 GGX tracing, fallback, resolve, adapter MRT gather, native packing, both REBLUR specular streams and their histories, native unpack, reconstruction and composition. Alternating A/B order, 3 trials, 24 paired warmups, 32 samples; first 8 samples excluded by analysis. No capture/readbacks/allocations inside steady-state GPU intervals. Native/managed CPU recording and resource-view creation are not GPU timing. External game GPU load may affect absolute timings. Static replay + synthetic TOD, not live gameplay.\n");
        }finally{timer.Dispose();timer=null;}
    }
}
