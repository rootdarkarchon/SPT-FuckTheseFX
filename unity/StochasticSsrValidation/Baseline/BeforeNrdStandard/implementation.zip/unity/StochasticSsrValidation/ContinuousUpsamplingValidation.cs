using System;
using System.Linq;
using HarmonyLib;
using FuckTheseFX.Source.StochasticSSR;
using UnityEngine;
using UnityEngine.Rendering;

public static partial class StochasticSsrValidation
{
    // Exercise the production compositor independently of ray noise. The input
    // contains measured geometry, measured sky, source-filled colour and exits.
    // A display footprint may contain all four without changing donor authority.
    private static void ContinuousUpsamplingContracts()
    {
        int savedW=width,savedH=height,startOwned=owned.Count;
        var savedDepth=depths;var savedNormal=normals;var savedSpec=specular;var savedScene=scene;var savedTarget=camera.targetTexture;
        try {
            width=2560;height=1440;Fixture();
            var projection=GL.GetGPUProjectionMatrix(camera.projectionMatrix,false);
            var clip=projection*new Vector4(0,0,-5,1);
            depths=Texture(Enumerable.Repeat(new Color(clip.z/clip.w,0,0,0),width*height).ToArray());
            normals=Texture(Enumerable.Repeat(new Color(.5f,.5f,1,1),width*height).ToArray());
            specular=Texture(Enumerable.Repeat(new Color(.04f,.04f,.04f,1),width*height).ToArray());
            using(var cb=new CommandBuffer())using(var p=new ConfidenceSsrPipeline(compute,blend,reflection,noise,native,gaussian)) {
                const int size=256;p.Ensure(width,height,size,RenderTextureFormat.ARGBHalf);
                var o=Options();Globals(cb);p.Render(cb,camera,scene,camera.targetTexture,o,depths,normals,specular,true);Execute(cb);
                cb.Blit(Solid(new Color(1,5,0,0)),p.TracePipeline.Hit);
                cb.Blit(Solid(new Color(0,0,-5,1)),p.TracePipeline.HitPoint);
                cb.Blit(Solid(new Color(0,0,-1,1)),p.TracePipeline.Sample);
                cb.Blit(Solid(Color.clear),p.TracePipeline.TraceInfo);
                Execute(cb);
                var properties=(MaterialPropertyBlock)AccessTools.Field(typeof(ConfidenceSsrPipeline),"properties").GetValue(p);
                var draw=AccessTools.Method(typeof(ConfidenceSsrPipeline),"Draw");
                Func<int,Color[]> compose=view=>{
                    properties.SetVector("_Options",new Vector4(0,8,.5f,view));
                    draw.Invoke(p,new object[]{cb,(RenderTargetIdentifier)scene,(RenderTargetIdentifier)camera.targetTexture,ConfidenceSsrPipeline.Pass.Compose});
                    Execute(cb);return Read(camera.targetTexture);
                };
                Color[] previous=null;double maximumError=0,maximumJump=0,maximumFrameChange=0;
                for(int phase=0;phase<4;phase++) {
                    var records=new Color[size*size];var measured=new Color[records.Length];var display=new Color[records.Length];
                    var expected=new Color[records.Length];
                    for(int j=0;j<records.Length;j++) {
                        int kind=(j%size+j/size+phase)%4;
                        // Move the geometry/sky/fill/exit pattern by a trace cell
                        // and verify every frame against continuous interpolation.
                        float r=.2f+.1f*Mathf.Sin(j%size*.7f+phase*.1f);
                        float b=.3f+.1f*Mathf.Cos(j/size*.7f+phase*.1f);
                        float c=.7f+.1f*Mathf.Sin((j%size+j/size)*.5f+phase*.1f);
                        records[j]=new Color(0,0,kind==2?9:kind==3?6:0,kind<2?kind+1:0);
                        display[j]=new Color(r*c,.2f*c,b*c,c);
                        measured[j]=kind==2?Color.clear:display[j];
                        expected[j]=display[j];
                        // Protected exits retain their measured (zero) signal.
                        if(kind==3)measured[j]=display[j]=expected[j]=Color.clear;
                    }
                    cb.Blit(Sized(records,size,size),p.TracePipeline.Record);Execute(cb);
                    properties.SetTexture("_Signal",Sized(display,size,size));
                    properties.SetTexture("_UnfilledSignal",Sized(measured,size,size));
                    var confidence=compose(8);var colour=compose(9);
                    var output=new Color[width*height];double error=0,jump=0,frameChange=0;
                    for(int y=16;y<height-16;y++)for(int x=16;x<width-16;x++) {
                        int i=y*width+x;float gx=(x+.5f)*size/width-.5f,gy=(y+.5f)*size/height-.5f;
                        int qx=(int)Math.Floor(gx),qy=(int)Math.Floor(gy);float fx=gx-qx,fy=gy-qy;
                        var e=Color.LerpUnclamped(Color.LerpUnclamped(expected[qy*size+qx],expected[qy*size+qx+1],fx),Color.LerpUnclamped(expected[(qy+1)*size+qx],expected[(qy+1)*size+qx+1],fx),fy);
                        var actual=new Color(colour[i].r*confidence[i].r,colour[i].g*confidence[i].r,colour[i].b*confidence[i].r,confidence[i].r);output[i]=actual;
                        error=Math.Max(error,Vector4.Distance(actual,e));
                        if(x>16)jump=Math.Max(jump,Math.Abs(actual.a-output[i-1].a));
                        if(previous!=null)frameChange=Math.Max(frameChange,Math.Abs(actual.a-previous[i].a));
                    }
                    Check(error<.003,"256 SSR premultiplied class/miss interpolation matches continuous display coverage, phase "+phase+": "+error);
                    Check(jump<.081,"256 SSR has no nearest-owner jumps at horizontal cell boundaries, phase "+phase+": "+jump);
                    maximumError=Math.Max(maximumError,error);maximumJump=Math.Max(maximumJump,jump);maximumFrameChange=Math.Max(maximumFrameChange,frameChange);previous=output;
                }
                // A stable measured footprint with only class labels changing
                // must remain stable in the compositor, including sky transitions.
                var stable=Enumerable.Range(0,size*size).Select(j=>new Color(j%2==0?.15f:.45f,.2f,j%2==0?.5f:.1f,1)).ToArray();
                properties.SetTexture("_Signal",Sized(stable,size,size));properties.SetTexture("_UnfilledSignal",Sized(stable,size,size));
                foreach(float smooth in new[]{1f,.8f}) {
                    specular=Texture(Enumerable.Repeat(new Color(.04f,.04f,.04f,smooth),width*height).ToArray());Globals(cb);
                    cb.Blit(Solid(new Color(0,0,-5,smooth)),p.TracePipeline.HitPoint);Execute(cb);
                    Color[] first=null;
                    for(int phase=0;phase<2;phase++) {
                        cb.Blit(Sized(Enumerable.Range(0,size*size).Select(j=>new Color(0,0,0,1+(j%size+j/size+phase)%2)).ToArray(),size,size),p.TracePipeline.Record);Execute(cb);
                        var result=compose(9);if(first==null)first=result;else Check(Error(first,result)<.001,"moving geometry/sky classification does not flicker a stable display footprint, smoothness "+smooth);
                    }
                }
                // Water/dry ownership remains a real full-resolution boundary,
                // even on an otherwise identical plane and inside a trace cell.
                int edge=width/2+3;
                properties.SetTexture("_WaterCoverage",Texture(Enumerable.Range(0,width*height).Select(j=>j%width<edge?new Color(5,1,0,0):Color.clear).ToArray()));
                properties.SetFloat("_WaterAvailable",1);
                cb.Blit(Solid(new Color(0,0,0,1)),p.TracePipeline.Record);Execute(cb);
                var split=Sized(Enumerable.Range(0,size*size).Select(j=>(int)((j%size+.5f)*width/size)<edge?new Color(.8f,0,0,1):new Color(0,0,.2f,1)).ToArray(),size,size);
                properties.SetTexture("_Signal",split);properties.SetTexture("_UnfilledSignal",Texture2D.blackTexture);
                var boundary=compose(9);
                Check(Enumerable.Range(0,width*height).Where(j=>Math.Abs(j%width-edge)<12).All(j=>j%width<edge?boundary[j].r>0 && boundary[j].b==0:boundary[j].r==0 && boundary[j].b>0),"source-filled upsampling preserves sub-cell water/dry ownership");
                properties.SetFloat("_WaterAvailable",0);
                // The active fill stage cannot promote a protected screen exit.
                cb.Blit(Solid(new Color(0,0,6,0)),p.TracePipeline.Record);Execute(cb);
                p.Reconstruct(cb,camera,scene,camera.targetTexture,o);Execute(cb);
                Check(compose(8).All(v=>v.r==0),"active fill and upsampling cannot promote protected screen exits");
                Debug.Log("Continuous upsampling: max interpolation error="+maximumError+", max horizontal coverage step="+maximumJump+", moving-pattern max frame change="+maximumFrameChange);
            }
        } finally {
            width=savedW;height=savedH;depths=savedDepth;normals=savedNormal;specular=savedSpec;scene=savedScene;camera.targetTexture=savedTarget;camera.aspect=(float)width/height;
            for(int i=owned.Count-1;i>=startOwned;i--){if(owned[i]!=null)UnityEngine.Object.DestroyImmediate(owned[i]);owned.RemoveAt(i);}
        }
    }
}
