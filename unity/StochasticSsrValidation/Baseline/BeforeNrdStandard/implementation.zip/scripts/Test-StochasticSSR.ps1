param([string]$SptInstallPath='D:\Tarkov-SPT-4.1', [string]$Unity='C:\Program Files\Unity 2022.3.43f1\Editor\Unity.exe', [switch]$Profile, [switch]$HistoryTiming, [switch]$CurrentSsrTiming, [switch]$SmoothnessSweep, [switch]$ReceiverRangeWork, [switch]$ReducedRateFeasibility, [switch]$ContinuationProfile, [switch]$ContinuationReplay, [switch]$BlockContinuationProfile, [switch]$BlockContinuationReplay, [switch]$SkyRecoveryReplay, [string]$ReplayPython='python', [string]$ResearchRepo='A:\dev\source\SPTAOReplacer')
$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
$project=Join-Path $repo 'obj\StochasticSsrValidation'
foreach($folder in @('Assets/Editor','Assets/Plugins','Packages','ProjectSettings','Output','Baseline')) { New-Item -ItemType Directory -Force (Join-Path $project $folder)|Out-Null }
if($HistoryTiming){$Profile=$true;Set-Content (Join-Path $project 'history-timing.txt') 'Independent ownership and packing trials'}else{Remove-Item -LiteralPath (Join-Path $project 'history-timing.txt') -Force -ErrorAction SilentlyContinue}
if($ReceiverRangeWork){$CurrentSsrTiming=$true;Set-Content (Join-Path $project 'receiver-range-work.txt') 'Deterministic receiver-range diagnostics, no GPU timing'}else{Remove-Item -LiteralPath (Join-Path $project 'receiver-range-work.txt') -Force -ErrorAction SilentlyContinue}
if($SmoothnessSweep){$CurrentSsrTiming=$true;Set-Content (Join-Path $project 'smoothness-sweep.txt') 'R1024 receiver-only sweep'}else{Remove-Item -LiteralPath (Join-Path $project 'smoothness-sweep.txt') -Force -ErrorAction SilentlyContinue}
if($CurrentSsrTiming){$Profile=$true;Set-Content (Join-Path $project 'current-ssr-timing.txt') 'Current full-rate R1024/R768; native cutoff 0';Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/CurrentSsrTiming.cs') (Join-Path $project 'Assets/Editor') -Force}else{Remove-Item -LiteralPath (Join-Path $project 'current-ssr-timing.txt') -Force -ErrorAction SilentlyContinue;Remove-Item -LiteralPath (Join-Path $project 'Assets/Editor/CurrentSsrTiming.cs') -Force -ErrorAction SilentlyContinue}
if($ReducedRateFeasibility){$Profile=$true;Set-Content (Join-Path $project 'reduced-rate-feasibility.txt') 'Quality only; no timestamps'}else{Remove-Item -LiteralPath (Join-Path $project 'reduced-rate-feasibility.txt') -Force -ErrorAction SilentlyContinue}
if($ReducedRateFeasibility){
 Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/ReducedRateFeasibility.cs') (Join-Path $project 'Assets/Editor') -Force
 Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Experiments/CheckerboardReconstruction.compute') (Join-Path $project 'Assets') -Force
}else{Remove-Item -LiteralPath (Join-Path $project 'Assets/Editor/ReducedRateFeasibility.cs') -Force -ErrorAction SilentlyContinue}
if($BlockContinuationReplay){$BlockContinuationProfile=$true;Set-Content (Join-Path $project 'block-continuation-replay-only.txt') 'Functional only'}else{Remove-Item -LiteralPath (Join-Path $project 'block-continuation-replay-only.txt') -Force -ErrorAction SilentlyContinue}
if($BlockContinuationProfile){$Profile=$true;Set-Content (Join-Path $project 'block-continuation-profile.txt') 'Isolated bounded gather continuation'}else{Remove-Item -LiteralPath (Join-Path $project 'block-continuation-profile.txt') -Force -ErrorAction SilentlyContinue}
if($ContinuationProfile -or $ContinuationReplay){$Profile=$true;Set-Content (Join-Path $project 'continuation-profile.txt') 'A/B/A current-code candidates'}else{Remove-Item -LiteralPath (Join-Path $project 'continuation-profile.txt') -Force -ErrorAction SilentlyContinue}
if($ContinuationReplay){Set-Content (Join-Path $project 'continuation-replay-only.txt') 'Functional replay only; no GPU timings'}else{Remove-Item -LiteralPath (Join-Path $project 'continuation-replay-only.txt') -Force -ErrorAction SilentlyContinue}
Remove-Item -LiteralPath (Join-Path $project 'Assets/Editor/FidelityDenoiser.cs') -Force -ErrorAction SilentlyContinue
# The isolated NRD suite adds profiling dependencies that the regular suite
# does not import. Its source is restored by Test-NrdSSR.ps1 when requested.
Remove-Item -LiteralPath (Join-Path $project 'Assets/Editor/NrdValidation.cs') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $project 'Assets/Editor/AlphaDepthAudit.cs') -Force -ErrorAction SilentlyContinue
if($Profile) {
    New-Item -ItemType Directory -Force (Join-Path $project 'Native') | Out-Null
    Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/HistoryGpuProfile.cs') (Join-Path $project 'Assets/Editor') -Force
    Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/GpuProfile.cs') (Join-Path $project 'Assets/Editor/GpuProfile.cs') -Force
    Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/ContinuationGpuProfile.cs') (Join-Path $project 'Assets/Editor') -Force
    Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/BlockContinuationProfile.cs') (Join-Path $project 'Assets/Editor') -Force
    New-Item -ItemType Directory -Force (Join-Path $project 'Assets/BeforeBlockContinuation') | Out-Null
    Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforeBlockContinuation/Shaders/*') (Join-Path $project 'Assets/BeforeBlockContinuation') -Recurse -Force
    foreach($name in @('BlockContinuation.compute','BlockBaselineWork.compute')){Copy-Item (Join-Path $repo "unity/StochasticSsrValidation/Experiments/$name") (Join-Path $project "Assets/$name") -Force}
    Copy-Item (Join-Path $ResearchRepo 'unity/CustomAmbientResearch/GpuTiming.cs') (Join-Path $project 'Assets/Editor/GpuTiming.cs') -Force
    Copy-Item (Join-Path $SptInstallPath 'BepInEx/plugins/CustomAmbientResearch/CustomAmbientGpu.dll') (Join-Path $project 'Native/CustomAmbientGpu.dll') -Force
} else {
    foreach($name in @('HistoryGpuProfile.cs','GpuProfile.cs','ContinuationGpuProfile.cs','BlockContinuationProfile.cs','GpuTiming.cs')) { Remove-Item -LiteralPath (Join-Path $project "Assets/Editor/$name") -Force -ErrorAction SilentlyContinue }
}

foreach($name in @('AmdDenoiserValidation.cs','HitReuseValidation.cs','GapFillValidation.cs','DepthGapFillValidation.cs','WaterNormalValidation.cs','CompletedContinuationSkyValidation.cs','AspectRatioValidation.cs','ContinuationValidation.cs','DepthIntersectionValidation.cs','AmdReflectionDenoiser.cs')) {Remove-Item -LiteralPath (Join-Path $project "Assets/Editor/$name") -Force -ErrorAction SilentlyContinue}
foreach($name in @('AmdReflectionDenoiser.compute','AmdReflectionDenoiser.hlsl','AmdReflectionCommon.hlsl','HitReuse.hlsl','HiZBeforeNormals.compute')) {Remove-Item -LiteralPath (Join-Path $project "Assets/$name") -Force -ErrorAction SilentlyContinue}
New-Item -ItemType Directory -Force (Join-Path $project 'Assets/BeforeCleanup') | Out-Null
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforeCleanup/Shaders/*') (Join-Path $project 'Assets/BeforeCleanup') -Recurse -Force
foreach($name in @('SsrPipeline.cs','ConfidenceSsrPipeline.cs')) {Copy-Item (Join-Path $repo "unity/StochasticSsrValidation/Baseline/BeforeCleanup/Source/$name") (Join-Path $project "Assets/Editor/BeforeCleanup-$name") -Force}
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/CleanupValidation.cs') (Join-Path $project 'Assets/Editor/CleanupValidation.cs') -Force
New-Item -ItemType Directory -Force (Join-Path $project 'Assets/BeforePerformance') | Out-Null
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforePerformance/Shaders/*') (Join-Path $project 'Assets/BeforePerformance') -Recurse -Force
foreach($source in Get-ChildItem (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforePerformance/Source') -Filter '*.cs') {
    Copy-Item $source.FullName (Join-Path $project ('Assets/Editor/BeforePerformance-'+$source.Name)) -Force
}
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/PerformanceValidation.cs') (Join-Path $project 'Assets/Editor/PerformanceValidation.cs') -Force
New-Item -ItemType Directory -Force (Join-Path $project 'Assets/BeforeTraceOptimization') | Out-Null
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforeTraceOptimization/Shaders/*') (Join-Path $project 'Assets/BeforeTraceOptimization') -Recurse -Force
foreach($source in Get-ChildItem (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforeTraceOptimization/Source') -Filter '*.cs') {
    Copy-Item $source.FullName (Join-Path $project ('Assets/Editor/BeforeTraceOptimization-'+$source.Name)) -Force
}
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/TraceOptimizationValidation.cs') (Join-Path $project 'Assets/Editor/TraceOptimizationValidation.cs') -Force

New-Item -ItemType Directory -Force (Join-Path $project 'Assets/BeforeContinuationOptimization') | Out-Null
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforeContinuationOptimization/Shaders/*') (Join-Path $project 'Assets/BeforeContinuationOptimization') -Recurse -Force
foreach($source in Get-ChildItem (Join-Path $repo 'unity/StochasticSsrValidation/Baseline/BeforeContinuationOptimization/Source') -Filter '*.cs') {
    Copy-Item $source.FullName (Join-Path $project ('Assets/Editor/BeforeContinuationOptimization-'+$source.Name)) -Force
}
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/ContinuationOptimizationValidation.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Experiments/ReceiverProjection.shader') (Join-Path $project 'Assets/ReceiverProjection.shader') -Force
foreach($baseline in @('BeforeHistoryOwnership','BeforeHistoryPacking')) {
    New-Item -ItemType Directory -Force (Join-Path $project "Assets/$baseline") | Out-Null
    Copy-Item (Join-Path $repo "unity/StochasticSsrValidation/Baseline/$baseline/Shaders/*") (Join-Path $project "Assets/$baseline") -Force
    Copy-Item (Join-Path $repo "unity/StochasticSsrValidation/Baseline/$baseline/Source/ConfidenceSsrPipeline.cs") (Join-Path $project "Assets/Editor/$baseline-ConfidenceSsrPipeline.cs") -Force
}
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/HistoryOwnershipValidation.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/HistoryPackingValidation.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'Source/StochasticSSR/*.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'ConfigurationManagerAttributes.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/JitterValidation.cs') (Join-Path $project 'Assets/Editor/JitterValidation.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/NativeReconstructionValidation.cs') (Join-Path $project 'Assets/Editor/NativeReconstructionValidation.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/Validation.cs') (Join-Path $project 'Assets/Editor/Validation.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/SkyRecoveryValidation.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/TemporalStabilityValidation.cs') (Join-Path $project 'Assets/Editor/TemporalStabilityValidation.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/ContinuousUpsamplingValidation.cs') (Join-Path $project 'Assets/Editor/ContinuousUpsamplingValidation.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/RemovalAndUpsampling.cs') (Join-Path $project 'Assets/Editor/RemovalAndUpsampling.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/GenericNormalValidation.cs') (Join-Path $project 'Assets/Editor/GenericNormalValidation.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/WaterCoverageValidation.cs') (Join-Path $project 'Assets/Editor/WaterCoverageValidation.cs') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/AmbientCaptureValidation.cs') (Join-Path $project 'Assets/Editor/AmbientCaptureValidation.cs') -Force
Copy-Item (Join-Path $repo 'unity/Assets/CustomAmbient.shader') (Join-Path $project 'Assets/CustomAmbient.shader') -Force
New-Item -ItemType Directory -Force (Join-Path $project 'Assets/XeGTAO') | Out-Null
Copy-Item (Join-Path $repo 'unity/Assets/XeGTAO/BentNormals.hlsl') (Join-Path $project 'Assets/XeGTAO/BentNormals.hlsl') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/JitterFixture.shader') (Join-Path $project 'Assets/JitterFixture.shader') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/WaterCaptureFixture.shader') (Join-Path $project 'Assets/WaterCaptureFixture.shader') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/TodAudit.shader') (Join-Path $project 'Assets/TodAudit.shader') -Force
foreach($name in @('HiZ.compute','Support.shader','Reflection.shader','TodReflection.hlsl','WaterCapture.shader','ReuseBrdf.hlsl','RasterState.hlsl')) { Copy-Item (Join-Path $repo "unity/StochasticSSR/$name") (Join-Path $project 'Assets') -Force }
Copy-Item (Join-Path $repo 'unity/StochasticSSR/AMD') (Join-Path $project 'Assets') -Recurse -Force
Copy-Item (Join-Path $SptInstallPath 'EscapeFromTarkov_Data/Managed/Unity.Postprocessing.Runtime.dll') (Join-Path $project 'Assets/Plugins') -Force
foreach($name in @('BepInEx.dll','0Harmony.dll','Mono.Cecil.dll','Mono.Cecil.Mdb.dll','Mono.Cecil.Pdb.dll','Mono.Cecil.Rocks.dll','MonoMod.Utils.dll','MonoMod.RuntimeDetour.dll')) {
    Copy-Item (Join-Path $SptInstallPath "BepInEx/core/$name") (Join-Path $project 'Assets/Plugins') -Force
}
Set-Content (Join-Path $project 'Packages/manifest.json') '{"dependencies":{"com.unity.modules.assetbundle":"1.0.0","com.unity.modules.imgui":"1.0.0"}}'
Set-Content (Join-Path $project 'ProjectSettings/ProjectVersion.txt') 'm_EditorVersion: 2022.3.43f1'
Set-Content (Join-Path $project 'game-path.txt') $SptInstallPath
if($SkyRecoveryReplay) {
    & $ReplayPython (Join-Path $repo 'scripts/Prepare-SsrSkyReplay.py') --captures (Join-Path $SptInstallPath 'BepInEx/FTFX-SSR-Captures') --output (Join-Path $project 'SkyReplayRaw')
    if($LASTEXITCODE -ne 0) {throw 'Lossless sky capture preparation failed; requires Python with numpy and OpenEXR'}
    Set-Content (Join-Path $project 'sky-recovery-replay.txt') 'Lossless captured inputs; frozen phase 0; 50/100/200m; no GPU timing.'
} else {Remove-Item -LiteralPath (Join-Path $project 'sky-recovery-replay.txt') -Force -ErrorAction SilentlyContinue}
# Historical regression baselines retain their tracing/history. Adapt only
# their cosmetic display fill in these generated copies, so parity comparisons
# use the new receiver-fallback policy on both sides. Archived sources stay intact.
foreach($baseline in @('BeforeCleanup','BeforePerformance','BeforeTraceOptimization','BeforeContinuationOptimization','BeforeBlockContinuation')) {
    $baselinePath=Join-Path $project "Assets/$baseline/Reflection.shader"
    $baselineText=Get-Content -LiteralPath $baselinePath -Raw
    if($baselineText -match 'float4 FillDepthGap\(int2 p,float4 current\) \{') {
        $baselineText=$baselineText.Replace('float4 FillDepthGap(int2 p,float4 current) {','float4 FillDepthGap(int2 p,float4 current) { return current; // Validation-only receiver-fallback policy')
    } else {
        $baselineText=$baselineText.Replace('float4 DepthGapFill(V i):SV_Target {','float4 DepthGapFill(V i):SV_Target { return _Signal.Load(int3(TracePixel(i),0)); // Validation-only receiver-fallback policy')
    }
    [IO.File]::WriteAllText($baselinePath,$baselineText)
}
$started=[DateTime]::UtcNow
$log=Join-Path $project 'validation.log'
$process=Start-Process $Unity -ArgumentList @('-batchmode','-quit','-force-d3d11','-projectPath',('"'+$project+'"'),'-executeMethod','StochasticSsrValidation.Run','-logFile',('"'+$log+'"')) -WindowStyle Hidden -PassThru
if(-not $process.WaitForExit(600000)) { $process.Kill();throw "SSR release validation timeout: $log" }
$process.Refresh()
if($process.ExitCode -ne 0) { throw "SSR release validation failed ($($process.ExitCode)): $log" }
$result=Get-Item (Join-Path $project 'validation.txt')
if($result.LastWriteTimeUtc -lt $started) { throw 'Stale SSR release validation result' }
Copy-Item (Join-Path $project 'Output/stochasticssr') (Join-Path $repo 'Assets/stochasticssr') -Force
Get-Content $result.FullName
