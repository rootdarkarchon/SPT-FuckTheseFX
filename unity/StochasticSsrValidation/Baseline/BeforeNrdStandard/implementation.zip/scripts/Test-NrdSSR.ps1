param([switch]$Benchmark,[switch]$SkipDefaultRegression,[string]$Unity='C:\Program Files\Unity 2022.3.43f1\Editor\Unity.exe')
$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
$project=Join-Path $repo 'obj/StochasticSsrValidation'
if(-not $SkipDefaultRegression){& (Join-Path $PSScriptRoot 'Test-StochasticSSR.ps1') -Profile *> (Join-Path $repo 'obj/NRD/default-regression.txt')}
Copy-Item (Join-Path $repo 'Source/StochasticSSR/*.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSsrValidation/NrdValidation.cs') (Join-Path $project 'Assets/Editor') -Force
Copy-Item (Join-Path $repo 'unity/StochasticSSR/NrdInputs.shader') (Join-Path $project 'Assets') -Force
Copy-Item (Join-Path $repo 'obj/NRD/bridge/Release/FTFXNrd.dll') (Join-Path $project 'Native/FTFXNrd.dll') -Force
if($Benchmark){Set-Content (Join-Path $project 'nrd-timing.txt') 'Independent full-density R768 total SSR'}else{Remove-Item -LiteralPath (Join-Path $project 'nrd-timing.txt') -Force -ErrorAction SilentlyContinue}
$log=Join-Path $project 'nrd-validation.log'
$started=[DateTime]::UtcNow
$process=Start-Process $Unity -ArgumentList @('-batchmode','-quit','-force-d3d11','-projectPath',('"'+$project+'"'),'-executeMethod','StochasticSsrValidation.RunNrd','-logFile',('"'+$log+'"')) -WindowStyle Hidden -PassThru
if(-not $process.WaitForExit(600000)){$process.Kill();throw "NRD validation timeout: $log"}
$process.Refresh();if($process.ExitCode -ne 0){throw "NRD validation failed ($($process.ExitCode)): $log"}
$result=Get-Item (Join-Path $project 'NrdResults/validation.txt');if($result.LastWriteTimeUtc -lt $started){throw 'Stale NRD validation receipt'}
Copy-Item (Join-Path $project 'Output/nrdssr') (Join-Path $repo 'Assets/nrdssr') -Force
Write-Output "NRD validation passed: $($result.FullName)"
